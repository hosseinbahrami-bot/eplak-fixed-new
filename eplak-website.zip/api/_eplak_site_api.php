<?php
/* ============================================================================
   لایه‌ی واسطِ سایتِ معرفیِ ای‌پلاک — توابعِ مشترک
   ----------------------------------------------------------------------------
   این پوشه (public_html/api) بخشی از سامانه نیست و هیچ چیزی را تغییر نمی‌دهد؛
   فقط از سامانه «می‌خواند» تا سایتِ معرفیِ روت داده‌ی زنده نشان دهد. سامانه،
   پنل و API اپ دقیقاً در public_html/eplak-fixed/ دست‌نخورده می‌مانند و
   .htaccessِ داخلِ همان پوشه هم سرِ جایش است.

   قراردادِ پاسخ (تا صفحه‌ی سایت هرگز سفید نشود):
     • سامانه در دسترس بود      → ۲۰۰ + آرایه‌ی JSON (می‌تواند خالی باشد)
     • سامانه/دیتابیس در دسترس
       نبود یا خطا داد           → ۵۰۳ + []   ⇒ قالب به داده‌ی داخلیِ خودش
                                              برمی‌گردد و سایت بالا می‌ماند
     • درخواستِ OPTIONS          → ۲۰۴
   همه‌ی پاسخ‌ها: Content-Type: application/json; charset=utf-8 · CORS: * ·
   Cache-Control: no-store · فقط JSON (حتی در خطا هیچ HTML چاپ نمی‌شود).

   این فایل فقط SELECT می‌کند؛ هیچ نوشتاری روی دیتابیس انجام نمی‌دهد و هیچ
   نشستی (session) نمی‌سازد. نحو، سازگار با PHP 7.4 میزبان است (بدونِ PHP 8).
   ========================================================================== */

/* مسیرِ پوشه‌ی سامانه.
   پیش‌فرض: پوشه‌ی «eplak-fixed» کنارِ همین پوشه‌ی api (یعنی در public_html).
   اگر جای سامانه روی میزبان چیز دیگری است، یا ثابتِ EPLAK_ROOT را پیش از
   بارگذاری تعریف کنید یا متغیرِ محیطی EPLAK_SITE_APP_BASE را بگذارید. */
function eplak_site_app_dir()
{
    static $dir = null;
    if ($dir !== null) {
        return $dir;
    }
    if (defined('EPLAK_ROOT')) {
        $dir = rtrim((string) EPLAK_ROOT, '/');
        return $dir;
    }
    $env = getenv('EPLAK_SITE_APP_BASE');
    if (is_string($env) && trim($env) !== '') {
        $dir = rtrim(trim($env), '/');
        return $dir;
    }
    $dir = rtrim(str_replace('\\', '/', dirname(__DIR__)), '/') . '/eplak-fixed';
    return $dir;
}

/* پیشوندِ نشانیِ مطلقِ فایل‌های آپلودشده در سامانه (مثلاً /eplak-fixed) */
function eplak_site_url_base()
{
    $env = getenv('EPLAK_SITE_URL_BASE');
    if (is_string($env) && trim($env) !== '') {
        return rtrim(trim($env), '/');
    }
    $name = basename(eplak_site_app_dir());
    return $name === '' ? '/eplak-fixed' : '/' . $name;
}

function eplak_site_cors()
{
    if (headers_sent()) {
        return;
    }
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Accept');
    header('Access-Control-Max-Age: 600');
    header('Cache-Control: no-store');
}

/* تنها خروجیِ ممکن: JSON. حتی در خطا HTML چاپ نمی‌شود. */
function eplak_site_json($data, $status = 200)
{
    if (!is_array($data)) {
        $data = [];
    }
    if (!headers_sent()) {
        http_response_code((int) $status);
        header('Content-Type: application/json; charset=utf-8');
        eplak_site_cors();
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

/* نشانیِ رسانه: همان معنای eplakMediaUrl() سامانه، اما «مطلق نسبت به روتِ
   سایت» تا تصویرهای خبرها از صفحه‌ی روت هم درست بارگذاری شوند.
   آدرسِ کامل (http/https///) و data: دست‌نخورده برمی‌گردند. */
function eplak_site_media_url($path)
{
    $path = trim((string) $path);
    if ($path === '') {
        return '';
    }
    if (preg_match('#^(https?:)?//#i', $path) || stripos($path, 'data:') === 0) {
        return $path;
    }
    return eplak_site_url_base() . '/' . ltrim($path, '/');
}

/* تاریخِ دیتابیس («Y-m-d H:i:s» با ساعتِ تهران) → ISO با اختلافِ +03:30.
   چون bootstrap خودِ سامانه منطقه‌ی زمانیِ نمایش را روی تهران می‌گذارد،
   همان زمانِ ذخیره‌شده بدونِ جابه‌جایی به +03:30 نسبت داده می‌شود. */
function eplak_site_iso($value)
{
    $value = trim((string) $value);
    if ($value === '') {
        $value = date('Y-m-d H:i:s');
    }
    $ts = strtotime($value);
    if ($ts === false) {
        return $value;
    }
    return date('Y-m-d\TH:i:s', $ts) . '+03:30';
}

function eplak_site_fa_digits($value)
{
    return strtr((string) $value, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
}

/* چکیده‌ی متن: بدونِ برچسب و به‌اندازه‌ی خواسته‌شده، بر مرزِ واژه */
function eplak_site_excerpt($text, $length = 180)
{
    $text = trim(preg_replace('/\s+/u', ' ', strip_tags((string) $text)));
    if ($text === '') {
        return '';
    }
    if (!function_exists('mb_strlen')) {
        return strlen($text) <= $length ? $text : rtrim(substr($text, 0, $length)) . '…';
    }
    if (mb_strlen($text, 'UTF-8') <= $length) {
        return $text;
    }
    $cut = mb_substr($text, 0, $length, 'UTF-8');
    $space = mb_strrpos($cut, ' ', 0, 'UTF-8');
    if ($space !== false && $space > $length * 0.6) {
        $cut = mb_substr($cut, 0, $space, 'UTF-8');
    }
    return rtrim($cut) . '…';
}

/* زمانِ مطالعه: ~۲۰۰ واژه در دقیقه، حداقل یک دقیقه — فارسی مثلِ خودِ قالب */
function eplak_site_read_time($text)
{
    $text = trim(strip_tags((string) $text));
    $words = $text === '' ? 0 : count(preg_split('/\s+/u', $text));
    $minutes = (int) ceil($words / 200);
    if ($minutes < 1) {
        $minutes = 1;
    }
    return eplak_site_fa_digits($minutes) . ' دقیقه مطالعه';
}

/* مهارِ پارامترِ limit: مقدارِ خراب یا ناموجود → پیش‌فرض؛ بیشتر از سقف → سقف */
function eplak_site_limit($default, $max)
{
    $raw = isset($_GET['limit']) ? $_GET['limit'] : '';
    if (!is_numeric($raw)) {
        return (int) $default;
    }
    $n = (int) $raw;
    if ($n <= 0) {
        return (int) $default;
    }
    if ($max > 0 && $n > $max) {
        return (int) $max;
    }
    return $n;
}

/* راه‌اندازی: OPTIONS را همان‌جا پاسخ می‌دهد، سامانه را بارگذاری می‌کند و
   PDO برمی‌گرداند. خروجی null یعنی «سامانه در دسترس نیست» ⇒ ۵۰۳ + []. */
function eplak_site_boot($needPlaces = false)
{
    $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper((string) $_SERVER['REQUEST_METHOD']) : 'GET';
    if ($method === 'OPTIONS') {
        if (!headers_sent()) {
            http_response_code(204);
            eplak_site_cors();
        }
        exit;
    }

    $app = eplak_site_app_dir();
    $bootstrap = $app . '/shared/bootstrap.php';
    $functions = $app . '/admin/includes/functions.php';
    if (!is_file($bootstrap) || !is_file($functions)) {
        error_log('[eplak-site] پوشه‌ی سامانه پیدا نشد: ' . $app);
        return null;
    }

    /* اگر فایل‌های سامانه چیزی چاپ کنند (فاصله/BOM)، پاسخِ ما JSON نماند؛
       پس خروجیِ بارگذاری دور ریخته می‌شود. */
    $buffering = false;
    if (!headers_sent()) {
        ob_start();
        $buffering = true;
    }

    try {
        require_once $bootstrap;
        require_once $functions;
        if ($needPlaces) {
            $places = $app . '/shared/places_store.php';
            if (!is_file($places)) {
                throw new RuntimeException('shared/places_store.php پیدا نشد');
            }
            require_once $places;
        }
        $pdo = eplakGetPdo();
    } catch (Throwable $e) {
        if ($buffering) {
            ob_end_clean();
        }
        error_log('[eplak-site] ' . $e->getMessage());
        return null;
    }

    if ($buffering) {
        ob_end_clean();
    }
    return $pdo;
}
