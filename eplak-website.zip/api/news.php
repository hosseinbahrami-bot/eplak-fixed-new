<?php
/* سایتِ معرفی ← خبرها و اطلاعیه‌ها
   از همان تابعِ پنل (getAllNews) می‌خواند؛ یعنی هر خبری که در
   «پنل → اخبار و اطلاعیه‌ها» ثبت یا ویرایش شود، همین‌جا زنده نشان داده
   می‌شود. ستون‌های دیتابیس به شکلِ موردِ انتظارِ قالب نگاشت می‌شوند:
     title → title · summary|body → excerpt · badge → category
     (اگر badge خالی بود: نوع «tip» → «دانستنی»، وگرنه «اخبار»)
     updated_at → published_at (+03:30) · body → read_time فارسی
     image_url → نشانیِ مطلق نسبت به روتِ سایت
   پارامترها: limit (پیش‌فرض ۱۲، بیشینه ۵۰) · type=news|tip (اختیاری) */
require_once __DIR__ . '/_eplak_site_api.php';

$pdo = eplak_site_boot();
if ($pdo === null || !function_exists('getAllNews')) {
    eplak_site_json([], 503);
    exit;
}

$type = isset($_GET['type']) ? (string) $_GET['type'] : '';
if ($type !== 'news' && $type !== 'tip') {
    $type = '';
}

$report = null;
$rows = getAllNews($pdo, $type, $report);
if (!is_array($rows)) {
    $rows = [];
}
if (is_array($report) && isset($report['ok']) && !$report['ok']) {
    /* جدول خبرها نبود یا دیتابیس خطا داد ⇒ سایت با داده‌ی داخلی بالا می‌آید */
    eplak_site_json([], 503);
    exit;
}

$limit = eplak_site_limit(12, 50);
$out = [];
foreach ($rows as $row) {
    if (count($out) >= $limit) {
        break;
    }
    if (!is_array($row)) {
        continue;
    }
    $title = trim((string) (isset($row['title']) ? $row['title'] : ''));
    if ($title === '') {
        continue;
    }
    $rowType = (string) (isset($row['type']) ? $row['type'] : 'news');
    $badge = trim((string) (isset($row['badge']) ? $row['badge'] : ''));
    $summary = trim((string) (isset($row['summary']) ? $row['summary'] : ''));
    $body = (string) (isset($row['body']) ? $row['body'] : '');

    $out[] = [
        'id'           => (int) (isset($row['id']) ? $row['id'] : (count($out) + 1)),
        'title'        => $title,
        'excerpt'      => $summary !== '' ? $summary : eplak_site_excerpt($body, 180),
        'category'     => $badge !== '' ? $badge : ($rowType === 'tip' ? 'دانستنی' : 'اخبار'),
        'published_at' => eplak_site_iso(isset($row['updated_at']) ? $row['updated_at'] : ''),
        'read_time'    => eplak_site_read_time($body !== '' ? $body : $summary),
        'image_url'    => eplak_site_media_url(isset($row['image_url']) ? $row['image_url'] : ''),
        'featured'     => count($out) === 0,   /* نخستین خبر = خبرِ ویژه‌ی صفحه */
    ];
}

eplak_site_json($out);
