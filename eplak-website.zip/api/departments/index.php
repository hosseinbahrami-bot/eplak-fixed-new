<?php
/* مسیرِ جایگزین برای میزبانِ بدونِ mod_rewrite:
     /api/departments/   ← همان /api/departments.php
   چون بعضی میزبان‌ها اجازه‌ی بازنویسیِ نشانی ندارند، سایت هر دو مسیر را
   امتحان می‌کند؛ محتوای هر دو یکی است. (واحدها و معاونت‌ها) */
require dirname(__DIR__) . '/departments.php';
