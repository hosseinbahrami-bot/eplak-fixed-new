<?php
/* سایتِ معرفی ← نقشه‌ی شهر، «همان نقشه‌ی اپ با تمام مشخصات».
   از eplakPlacesAdminList() سامانه استفاده می‌کند تا فهرستِ یکپارچه
   (پیش‌فرضِ builtin + اصلاح‌شده در پنل + افزوده‌شده در پنل) دقیقاً همان‌طور که
   پنل و اپ می‌بینند به دست بیاید؛ مکان‌های پنهان‌شده رد می‌شوند.

   علاوه بر فیلدهایی که قالب می‌فهمد (name/description/category/address/
   latitude/longitude/hours)، «همه‌ی» مشخصاتِ اپ هم فرستاده می‌شود تا لایه‌ی
   تکمیلِ جزئیات بتواند نشان دهد: نام و نشانی و توضیحِ انگلیسی، شماره‌ی تماس،
   «موقعیتِ تقریبی» و لینکِ مسیریابیِ «نشان» (همان فرمتِ core/places.js اپ). */
require_once __DIR__ . '/_eplak_site_api.php';

$pdo = eplak_site_boot(true);
if ($pdo === null || !function_exists('eplakPlacesAdminList')) {
    eplak_site_json([], 503);
    exit;
}

$list = eplakPlacesAdminList($pdo);
if (!is_array($list)) {
    $list = [];
}

/* دسته‌ها: کلیدِ انگلیسیِ دیتابیس (health/mosque/…) به «نامِ فارسی و رنگِ
   خودِ اپ» نگاشت می‌شود — از همان جدولی که اپ می‌خواند
   (core/places-data.js ← eplakPlacesBuiltin()['categories']). پس هم برچسبِ
   فیلترهای نقشه فارسی می‌شود و هم رنگِ نشان‌ها با اپ یکی است. */
$cats = [];
if (function_exists('eplakPlacesBuiltin')) {
    $builtin = eplakPlacesBuiltin();
    foreach ((array) (isset($builtin['categories']) ? $builtin['categories'] : []) as $cat) {
        if (is_array($cat) && isset($cat['id'])) {
            $cats[(string) $cat['id']] = $cat;
        }
    }
}

$limit = (int) (isset($_GET['limit']) ? $_GET['limit'] : 0);          /* ۰ = همه */
$featuredTop = (int) (isset($_GET['featured']) ? $_GET['featured'] : 8);
$onlyFeatured = ((isset($_GET['featured_only']) ? $_GET['featured_only'] : '') === '1');

/** شش رقم اعشار، دقیقاً مثلِ fmt() در core/places.js اپ */
function eplak_site_coord($value)
{
    return number_format((float) $value, 6, '.', '');
}

$out = [];
foreach ($list as $item) {
    if (!is_array($item) || !empty($item['hidden'])) {
        continue;
    }
    $lat = isset($item['lat']) ? $item['lat'] : null;
    $lng = isset($item['lng']) ? $item['lng'] : null;
    if ($lat === null || $lng === null) {
        continue;
    }
    $name = trim((string) (isset($item['name_fa']) ? $item['name_fa'] : ''));
    if ($name === '') {
        continue;
    }
    if ($limit > 0 && count($out) >= $limit) {
        break;
    }

    $index = count($out) + 1;
    $featured = $index <= $featuredTop;
    if ($onlyFeatured && !$featured) {
        continue;
    }

    $lat6 = eplak_site_coord($lat);
    $lng6 = eplak_site_coord($lng);
    $phone = trim((string) (isset($item['tel']) ? $item['tel'] : ''));

    $catKey = (string) (isset($item['cat']) ? $item['cat'] : '');
    $cat = isset($cats[$catKey]) ? $cats[$catKey] : null;
    $catFa = $cat !== null && isset($cat['fa']) && trim((string) $cat['fa']) !== ''
        ? trim((string) $cat['fa'])
        : $catKey;                                   /* دسته‌ی ناشناخته: همان کلید */

    $out[] = [
        /* — فیلدهایی که قالبِ سایت می‌خواند — */
        'id'              => $index,
        'name'            => $name,
        'description'     => (string) (isset($item['note_fa']) ? $item['note_fa'] : ''),
        'category'        => $catFa,          /* فارسی، مثلِ خودِ اپ */
        'category_key'    => $catKey,
        'category_en'     => $cat !== null ? (string) (isset($cat['en']) ? $cat['en'] : '') : '',
        'category_color'  => $cat !== null ? (string) (isset($cat['color']) ? $cat['color'] : '') : '',
        'category_ink'    => $cat !== null ? (string) (isset($cat['ink']) ? $cat['ink'] : '#ffffff') : '#ffffff',
        'address'         => (string) (isset($item['addr_fa']) ? $item['addr_fa'] : ''),
        'latitude'        => (float) $lat,
        'longitude'       => (float) $lng,
        'hours'           => null,
        'featured'        => $featured,
        'active'          => true,
        'sort_order'      => $index,
        'created_at'      => eplak_site_iso(isset($item['updated_at']) ? $item['updated_at'] : ''),
        /* — بقیه‌ی «مشخصات» همان‌طور که در اپ هست — */
        'key'             => (string) (isset($item['key']) ? $item['key'] : ''),
        'source'          => (string) (isset($item['source']) ? $item['source'] : ''),
        'name_en'         => (string) (isset($item['name_en']) ? $item['name_en'] : ''),
        'description_en'  => (string) (isset($item['note_en']) ? $item['note_en'] : ''),
        'address_en'      => (string) (isset($item['addr_en']) ? $item['addr_en'] : ''),
        'phone'           => $phone,
        'approximate'     => (int) (isset($item['approx']) ? $item['approx'] : 0) === 1,
        'routing'         => [
            /* همان قالبِ neshanLinks() در core/places.js اپ (نسخه‌ی وب/بدون مبدأ) */
            'neshan'      => 'https://nshn.ir/?lat=' . $lat6 . '&lng=' . $lng6,
            'osm'         => 'https://www.openstreetmap.org/directions?to=' . $lat . ',' . $lng,
            'coordinates' => $lat6 . ',' . $lng6,
        ],
    ];
}

eplak_site_json($out);
