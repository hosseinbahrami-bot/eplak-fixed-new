<?php
/* توابع داده‌ای مشترک پنل مدیریت.
   فایل‌های کمکی سراسری (فایل‌های پیوست و اعلان پس‌زمینه) هم از همین‌جا بارگذاری
   می‌شوند تا همه‌ی صفحه‌های پنل به آن‌ها دسترسی داشته باشند. */
require_once dirname(__DIR__, 2) . '/shared/media.php';
require_once dirname(__DIR__, 2) . '/shared/webpush.php';

function getDashboardStats(PDO $pdo): array {
    $reportsCount = $pdo->query('SELECT COUNT(*) as count FROM reports')->fetch();
    $usersCount = $pdo->query('SELECT COUNT(*) as count FROM users')->fetch();
    $ticketsCount = $pdo->query('SELECT COUNT(*) as count FROM tickets WHERE 1=1' . eplakNonSupportTicketsWhere($pdo))->fetch();
    $pendingReportsCount = $pdo->query("SELECT COUNT(*) as count FROM reports WHERE status = 'pending'")->fetch();
    $doneReportsCount = $pdo->query("SELECT COUNT(*) as count FROM reports WHERE status = 'done'")->fetch();
    $pendingTicketsCount = $pdo->query("SELECT COUNT(*) as count FROM tickets WHERE status = 'pending'" . eplakNonSupportTicketsWhere($pdo))->fetch();

    $newsCount = 0;
    try {
        $newsCount = (int) $pdo->query('SELECT COUNT(*) FROM news')->fetchColumn();
    } catch (Throwable $e) {
        $newsCount = 0;
    }

    $reportsWithMedia = 0;
    try {
        /* فقط گزارش‌های واقعی — ردیف‌های «در انتظار اتصال» (report_id صفر) شمرده نمی‌شوند */
        $reportsWithMedia = (int) $pdo->query('SELECT COUNT(DISTINCT report_id) FROM report_media WHERE report_id > 0')->fetchColumn();
    } catch (Throwable $e) {
        $reportsWithMedia = 0;
    }

    return [
        'reports_count' => (int)$reportsCount['count'],
        'users_count' => (int)$usersCount['count'],
        'tickets_count' => (int)$ticketsCount['count'],
        'pending_reports_count' => (int)$pendingReportsCount['count'],
        'done_reports_count' => (int)$doneReportsCount['count'],
        'pending_tickets_count' => (int)$pendingTicketsCount['count'],
        'news_count' => $newsCount,
        'reports_with_media' => $reportsWithMedia,
        'push_subscribers' => eplakPushCount($pdo),
    ];
}

function getLatestReports(PDO $pdo, int $limit = 5): array {
    $stmt = $pdo->prepare('SELECT *, CONCAT("EP-1403-", LPAD(id + 1000, 4, "0")) AS code FROM reports ORDER BY created_at DESC LIMIT :limit');
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function getLatestTickets(PDO $pdo, int $limit = 5): array {
    $stmt = $pdo->prepare('SELECT *, CONCAT("TC-", LPAD(id + 1000, 4, "0")) AS code FROM tickets WHERE 1=1' . eplakNonSupportTicketsWhere($pdo) . ' ORDER BY created_at DESC LIMIT :limit');
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function getLatestUsers(PDO $pdo, int $limit = 5): array {
    $stmt = $pdo->prepare('SELECT * FROM users ORDER BY created_at DESC LIMIT :limit');
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function getAllDepartments(PDO $pdo, bool $onlyActive = false): array {
    $sql = 'SELECT * FROM departments';
    if ($onlyActive) {
        $sql .= ' WHERE is_active = 1';
    }
    $sql .= ' ORDER BY parent_id IS NULL DESC, sort_order ASC, name ASC';
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll();
}

function getSubDepartments(PDO $pdo, int $parentId): array {
    $stmt = $pdo->prepare('SELECT * FROM departments WHERE parent_id = :parent_id ORDER BY sort_order ASC, name ASC');
    $stmt->execute([':parent_id' => $parentId]);
    return $stmt->fetchAll();
}

function getDepartmentTree(PDO $pdo): array {
    $rows = getAllDepartments($pdo);
    $index = [];
    foreach ($rows as $row) {
        $row['children'] = [];
        $index[(int)$row['id']] = $row;
    }

    foreach ($rows as $row) {
        $parentId = (int)($row['parent_id'] ?? 0);
        if ($parentId > 0 && isset($index[$parentId])) {
            $index[$parentId]['children'][] = &$index[(int)$row['id']];
        }
    }

    $tree = [];
    foreach ($index as $row) {
        if ((int)($row['parent_id'] ?? 0) === 0) {
            $tree[] = $row;
        }
    }

    return $tree;
}

function getDepartmentById(PDO $pdo, int $id): ?array {
    $stmt = $pdo->prepare('SELECT * FROM departments WHERE id = :id LIMIT 1');
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $department = $stmt->fetch();
    return $department ?: null;
}

function createDepartment(PDO $pdo, array $data): int {
    $name = trim((string)($data['name'] ?? ''));
    if ($name === '') {
        return 0;
    }

    $parentId = isset($data['parent_id']) && $data['parent_id'] !== '' && $data['parent_id'] !== null ? (int)$data['parent_id'] : null;
    $sortOrder = isset($data['sort_order']) ? (int)$data['sort_order'] : 0;
    $slug = trim((string)($data['slug'] ?? '')) ?: null;
    $code = trim((string)($data['code'] ?? '')) ?: null;

    $stmt = $pdo->prepare('INSERT INTO departments (name, slug, code, parent_id, sort_order, is_active, description, icon, color) VALUES (:name, :slug, :code, :parent_id, :sort_order, :is_active, :description, :icon, :color)');
    $stmt->execute([
        ':name' => $name,
        ':slug' => $slug,
        ':code' => $code,
        ':parent_id' => $parentId,
        ':sort_order' => $sortOrder,
        ':is_active' => (int)($data['is_active'] ?? 1),
        ':description' => trim((string)($data['description'] ?? '')),
        ':icon' => trim((string)($data['icon'] ?? 'fa-building')) ?: null,
        ':color' => trim((string)($data['color'] ?? '#0f766e')) ?: '#0f766e',
    ]);

    return (int)$pdo->lastInsertId();
}

function updateDepartment(PDO $pdo, int $id, array $data): void {
    $name = trim((string)($data['name'] ?? ''));
    if ($name === '') {
        return;
    }

    $parentId = isset($data['parent_id']) && $data['parent_id'] !== '' && $data['parent_id'] !== null ? (int)$data['parent_id'] : null;
    $sortOrder = isset($data['sort_order']) ? (int)$data['sort_order'] : 0;
    $slug = trim((string)($data['slug'] ?? '')) ?: null;
    $code = trim((string)($data['code'] ?? '')) ?: null;

    $stmt = $pdo->prepare('UPDATE departments SET name = :name, slug = :slug, code = :code, parent_id = :parent_id, sort_order = :sort_order, is_active = :is_active, description = :description, icon = :icon, color = :color WHERE id = :id');
    $stmt->execute([
        ':name' => $name,
        ':slug' => $slug,
        ':code' => $code,
        ':parent_id' => $parentId,
        ':sort_order' => $sortOrder,
        ':is_active' => (int)($data['is_active'] ?? 1),
        ':description' => trim((string)($data['description'] ?? '')),
        ':icon' => trim((string)($data['icon'] ?? 'fa-building')) ?: null,
        ':color' => trim((string)($data['color'] ?? '#0f766e')) ?: '#0f766e',
        ':id' => $id,
    ]);
}

function deleteDepartment(PDO $pdo, int $id): void {
    foreach (getSubDepartments($pdo, $id) as $child) {
        deleteDepartment($pdo, (int)$child['id']);
    }
    $stmt = $pdo->prepare('DELETE FROM departments WHERE id = :id');
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

function getAllReports(PDO $pdo): array {
    $stmt = $pdo->query('SELECT *, CONCAT("EP-1403-", LPAD(id + 1000, 4, "0")) AS code FROM reports ORDER BY created_at DESC');
    return $stmt->fetchAll();
}

/* وضعیت‌های معتبر (کلیدهای انگلیسی و برچسب‌های فارسی) */
function eplakStatusKeys(): array {
    return ['pending', 'in_progress', 'review', 'done'];
}

function eplakStatusRawValues(): array {
    /* مقادیر خامِ وضعیت که ممکن است در دیتابیس هاست باشند — هم کلیدهای
       انگلیسی، هم برچسب‌های فارسیِ تازه، هم برچسب‌های قدیمی که از قبل
       ذخیره شده‌اند (گزارش‌های قدیمی همیشه درست خوانده شوند). */
    return [
        'pending', 'in_progress', 'review', 'done',
        'در انتظار', 'در انتظار بررسی', 'در حال انتظار',
        'در حال بررسی', 'در حال پیگیری', 'در حال رسیدگی',
        'انجام شده', 'انجام‌شده', 'انجام شد', 'تکمیل شده',
    ];
}

/* تشخیص وضعیت یک ردیف گزارش.
   در برخی ردیف‌های قدیمی، مقدار وضعیت و واحد اداری جابه‌جا ذخیره شده است؛
   این تابع هر دو ستون را بررسی می‌کند و هرکدام شبیه وضعیت بود همان را برمی‌گرداند. */
function reportStatusOf(array $row): string {
    $valid = eplakStatusRawValues();
    foreach (['status', 'department'] as $col) {
        $v = trim((string)($row[$col] ?? ''));
        if ($v === '') {
            continue;
        }
        if (in_array($v, $valid, true)) {
            return normalizeStatusValue($v);
        }
    }
    return 'pending';
}

/** گزارش‌ها بر اساس واحد اداری (برای نمودار ستونی) */
function getReportsByDepartment(PDO $pdo, int $limit = 8): array
{
    $rows = $pdo->query('SELECT department, COUNT(*) AS cnt FROM reports GROUP BY department ORDER BY cnt DESC, department ASC')
                ->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $name = trim((string)$r['department']);
        $out[] = ['label' => $name !== '' ? $name : 'واحد نامشخص', 'count' => (int)$r['cnt']];
    }
    if (count($out) > $limit) {
        $top = array_slice($out, 0, $limit);
        $restCount = 0;
        foreach (array_slice($out, $limit) as $r) { $restCount += $r['count']; }
        $top[] = ['label' => 'سایر', 'count' => $restCount];
        $out = $top;
    }
    return $out;
}

/**
 * شمارشِ گزارش‌ها در «سطل‌های ماهِ شمسی».
 * @param iterable $rows ردیف‌هایی با کلید created_at (یا رشته‌ی تاریخ)
 * @return array<string,int> کلیدِ شمسی ('1405-08') ⇒ تعداد
 */
function eplakJalaliMonthCounts($rows): array
{
    $counts = [];
    foreach ($rows as $row) {
        $raw = is_array($row) ? ($row['created_at'] ?? '') : $row;
        $key = eplakJalaliMonthKey($raw);
        if ($key === '') {
            continue;                       /* تاریخِ خالی/خراب شمرده نمی‌شود */
        }
        $counts[$key] = (int) ($counts[$key] ?? 0) + 1;
    }
    return $counts;
}

/**
 * شکلِ خروجیِ «روندِ ماهانه» — یک قالب برای هر دو مسیر (مدیر کل و مدیرِ حوزه)
 * تا نمودارِ داشبورد یک منبع داشته باشد:
 *   ['key'=>'1405-08', 'label'=>'آبان', 'full'=>'آبان ۱۴۰۵', 'year'=>1405,
 *    'month'=>8, 'count'=>4]
 */
function eplakMonthlyShape(array $window, array $counts): array
{
    $out = [];
    foreach ($window as $w) {
        $out[] = [
            'key'   => (string) $w['key'],
            'label' => (string) $w['label'],
            'full'  => (string) $w['full'],
            'year'  => (int) $w['jy'],
            'month' => (int) $w['jm'],
            'count' => (int) ($counts[$w['key']] ?? 0),
        ];
    }
    return $out;
}

/**
 * روندِ ماهانهٔ گزارش‌ها — ماه‌های بدون گزارش هم با صفر نمایش داده می‌شوند.
 *
 * ⚠ سطل‌ها و برچسب‌ها «شمسی»‌اند (۱۴۰۵/۰۸ = آبان)، نه میلادی. دو دلیل:
 *   ۱) نسخه‌ی قبلی برچسب را از آرایه‌ی «ژانویه … دسامبر» می‌گرفت و سطل‌ها را با
 *      DATE_FORMAT('%Y-%m') میلادی می‌ساخت ⇒ نمودارِ داشبورد برایِ مدیر
 *      «۰ژوئن ۰ژوئیه ۰اوت ۰سپتامبر ۰اکتبر ۴نوامبر» نشان می‌داد.
 *   ۲) ترجمه‌ی نام‌ها به‌تنهایی کافی نبود: هر ماهِ شمسی با دو ماهِ میلادی
 *      هم‌پوشانی دارد، پس خودِ گروه‌بندی هم باید شمسی شود وگرنه شمارِ هر ستون
 *      غلط می‌ماند.
 * گروه‌بندی در PHP انجام می‌شود (نه در SQL) تا روی MySQL و SQLite یکسان باشد؛
 * DATE_FORMAT هم که مخصوصِ MySQL بود کاملاً کنار رفت.
 */
function getReportsMonthly(PDO $pdo, int $months = 6): array
{
    $todayDb = function_exists('eplakDbNowString') ? eplakDbNowString($pdo) : null;
    $window  = eplakJalaliMonthWindow($months, $todayDb);
    if (!$window) {
        return [];
    }
    $from = (string) $window[0]['gfrom'];
    $to   = (string) $window[count($window) - 1]['gto'];

    try {
        if ($from !== '' && $to !== '') {
            /* فقط ردیف‌های داخلِ بازه خوانده می‌شوند (کوئری سبک می‌ماند) */
            $st = $pdo->prepare('SELECT created_at FROM reports
                                 WHERE created_at IS NOT NULL AND created_at >= ? AND created_at <= ?');
            $st->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
        } else {
            $st = $pdo->query("SELECT created_at FROM reports
                               WHERE created_at IS NOT NULL AND created_at > '0001-01-01'");
        }
        $counts = eplakJalaliMonthCounts($st->fetchAll(PDO::FETCH_ASSOC));
    } catch (Throwable $e) {
        $counts = [];                       /* جدول نیست ⇒ نمودارِ صفر، نه خطا */
    }
    return eplakMonthlyShape($window, $counts);
}

/* آمار وضعیت گزارش‌ها برای نمودار */
function getReportsStatusStats(PDO $pdo): array {
    $rows = $pdo->query('SELECT status, department FROM reports')->fetchAll();
    $stats = ['pending' => 0, 'in_progress' => 0, 'done' => 0];
    $total = 0;
    foreach ($rows as $r) {
        $key = reportStatusOf($r);
        if (!isset($stats[$key])) {
            $stats[$key] = 0;
        }
        $stats[$key]++;
        $total++;
    }
    return ['total' => $total, 'counts' => $stats];
}

function normalizeStatusValue(string $status): string {
    $status = trim($status);
    /* کلیدهای انگلیسی + همه‌ی برچسب‌های فارسی (تازه و قدیمی) تا داده‌های
       ذخیره‌شده‌ی قبلی هم درست شناسایی شوند. */
    $map = [
        'pending' => 'pending',
        'در انتظار' => 'pending',
        'در انتظار بررسی' => 'pending',
        'در حال انتظار' => 'pending',
        'in_progress' => 'in_progress',
        'review' => 'in_progress',
        'در حال بررسی' => 'in_progress',
        'در حال پیگیری' => 'in_progress',
        'در حال رسیدگی' => 'in_progress',
        'done' => 'done',
        'انجام شده' => 'done',
        'انجام‌شده' => 'done',
        'انجام شد' => 'done',
        'تکمیل شده' => 'done',
    ];

    return $map[$status] ?? 'pending';
}

function statusLabel(string $status): string {
    $status = normalizeStatusValue($status);
    /* همان چهار مرحله‌ای که شهروند در اپ می‌بیند */
    $labels = [
        'pending' => 'در حال انتظار',
        'in_progress' => 'در حال رسیدگی',
        'done' => 'انجام شد',
    ];

    return $labels[$status] ?? 'در حال انتظار';
}

function statusClass(string $status): string {
    $status = normalizeStatusValue($status);
    $classes = [
        'pending' => 'status-pending',
        'in_progress' => 'status-progress',
        'done' => 'status-done',
    ];

    return $classes[$status] ?? 'status-pending';
}

function getAllUsers(PDO $pdo): array {
    $stmt = $pdo->query('SELECT u.*, COUNT(r.id) AS report_count FROM users u LEFT JOIN reports r ON u.phone = r.user_phone GROUP BY u.id ORDER BY u.created_at DESC');
    return $stmt->fetchAll();
}

function getUserByPhone(PDO $pdo, string $phone): ?array {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE phone = :phone LIMIT 1');
    $stmt->execute([':phone' => $phone]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function getUserById(PDO $pdo, int $id): ?array {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch();
    return $user ?: null;
}

function createUser(PDO $pdo, array $data): int {
    $stmt = $pdo->prepare('INSERT INTO users (phone, name, address, nid) VALUES (:phone, :name, :address, :nid)');
    $stmt->execute([
        ':phone' => trim((string)($data['phone'] ?? '')),
        ':name' => trim((string)($data['name'] ?? '')),
        ':address' => trim((string)($data['address'] ?? '')),
        ':nid' => trim((string)($data['nid'] ?? '')),
    ]);

    return (int)$pdo->lastInsertId();
}

function updateUser(PDO $pdo, int $id, array $data): void {
    $stmt = $pdo->prepare('UPDATE users SET phone = :phone, name = :name, address = :address, nid = :nid WHERE id = :id');
    $stmt->execute([
        ':phone' => trim((string)($data['phone'] ?? '')),
        ':name' => trim((string)($data['name'] ?? '')),
        ':address' => trim((string)($data['address'] ?? '')),
        ':nid' => trim((string)($data['nid'] ?? '')),
        ':id' => $id,
    ]);
}

function createReport(PDO $pdo, array $data): int {
    $stmt = $pdo->prepare('INSERT INTO reports (user_phone, title, description, category, department, sub_department, location, status) VALUES (:user_phone, :title, :description, :category, :department, :sub_department, :location, :status)');
    $stmt->execute([
        ':user_phone' => trim((string)($data['user_phone'] ?? '')),
        ':title' => trim((string)($data['title'] ?? '')),
        ':description' => trim((string)($data['description'] ?? '')),
        ':category' => trim((string)($data['category'] ?? 'سایر')),
        ':department' => trim((string)($data['department'] ?? '')),
        ':sub_department' => trim((string)($data['sub_department'] ?? '')),
        ':location' => trim((string)($data['location'] ?? '')),
        ':status' => normalizeStatusValue((string)($data['status'] ?? 'pending')),
    ]);

    return (int)$pdo->lastInsertId();
}

/** کد پیگیری نمایشی گزارش (همان که شهروند در اپ می‌بیند)
    تعریف اصلی در shared/bootstrap.php است تا اپ، پنل و متن اعلان «یک» کد بدهند. */
function reportCodeFor(int $id): string {
    return function_exists('eplakReportCode')
        ? eplakReportCode($id)
        : 'EP-1403-' . str_pad((string) ($id + 1000), 4, '0', STR_PAD_LEFT);
}

/**
 * ویرایش کامل گزارش (صفحه‌ی «ویرایش»).
 *
 * اگر در این ویرایش «وضعیت» عوض شده باشد، دقیقاً مثل ثبت پاسخ:
 *   ۱) یک گام «تغییر وضعیت» در روند رسیدگی ثبت می‌شود،
 *   ۲) اعلان شخصی برای شهروند ساخته می‌شود (فهرست اعلان‌های اپ)،
 *   ۳) اعلان سیستمی به گوشی‌های ثبت‌شده‌ی او فرستاده می‌شود.
 * (پیش از این، تغییر وضعیت از صفحه‌ی ویرایش کاملاً بی‌صدا بود.)
 *
 * خروجی: نتیجه‌ی اعلان (eplakNotifyUser)؛ آرایه‌ی خالی یعنی اعلانی لازم نبود.
 */
function updateReport(PDO $pdo, int $id, array $data): array {
    $before = getReportById($pdo, $id);
    $newStatus = normalizeStatusValue((string)($data['status'] ?? 'pending'));
    $stmt = $pdo->prepare('UPDATE reports SET user_phone = :user_phone, title = :title, description = :description, category = :category, department = :department, sub_department = :sub_department, location = :location, status = :status WHERE id = :id');
    $stmt->execute([
        ':user_phone' => trim((string)($data['user_phone'] ?? '')),
        ':title' => trim((string)($data['title'] ?? '')),
        ':description' => trim((string)($data['description'] ?? '')),
        ':category' => trim((string)($data['category'] ?? 'سایر')),
        ':department' => trim((string)($data['department'] ?? '')),
        ':sub_department' => trim((string)($data['sub_department'] ?? '')),
        ':location' => trim((string)($data['location'] ?? '')),
        ':status' => $newStatus,
        ':id' => $id,
    ]);

    $previousStatus = is_array($before) ? normalizeStatusValue((string) ($before['status'] ?? '')) : '';
    $statusChanged  = is_array($before) && $previousStatus !== $newStatus;

    /* روند رسیدگی: تغییرات مهم ویرایش، به زبان شهروند ثبت می‌شود */
    try {
        require_once dirname(__DIR__, 2) . '/shared/media.php';
        eplakReportTimelineBootstrap($pdo, $id, is_array($before) ? $before : []);
        if (is_array($before)) {
            eplakReportEventEdit($pdo, $id, $before, $data);
        }
        if ($statusChanged) {
            eplakReportEventStatus($pdo, $id, $newStatus, '');
        }
    } catch (Throwable $e) {
        /* بی‌اهمیت */
    }

    /* اعلان به شهروند: فقط وقتی وضعیت واقعاً عوض شده باشد */
    $notify = [];
    if ($statusChanged) {
        try {
            $rep   = getReportById($pdo, $id);
            $phone = trim((string) ($rep['user_phone'] ?? ''));
            if ($phone !== '') {
                require_once dirname(__DIR__, 2) . '/shared/notify_events.php';
                $notify = eplakNotifyReply($pdo, $phone, 'گزارش', reportCodeFor($id), $newStatus, '', true);
            }
        } catch (Throwable $e) {
            error_log('[eplak-admin:report.edit-notify] ' . $e->getMessage());
        }
    }
    return $notify;
}

function getReportById(PDO $pdo, int $id): ?array {
    $stmt = $pdo->prepare('SELECT * FROM reports WHERE id = :id');
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $report = $stmt->fetch();
    return $report ?: null;
}

/**
 * ثبت پاسخ/وضعیت گزارش و خبر دادن به شهروند.
 *
 * «تغییر» یعنی یکی از این دو:
 *   • وضعیت با وضعیت ذخیره‌شده فرق دارد،
 *   • متن پاسخ، غیرخالی و با پاسخ ذخیره‌شده فرق دارد.
 * (فهرست گزارش‌ها هنگام تغییر سریع وضعیت، «پاسخ ذخیره‌شده» را بدون تغییر می‌فرستد؛
 *  آن را پاسخ تازه حساب نمی‌کنیم تا در اعلان و روند رسیدگی تکرار نشود.)
 *
 * خروجی: نتیجه‌ی اعلان (eplakNotifyUser: ok/id/pushed/push[...]) برای نمایش به
 * مدیر؛ آرایه‌ی خالی یعنی تغییری نبود و اعلانی ساخته نشد.
 */
function saveReportReply(PDO $pdo, int $id, string $reply, string $status): array {
    $normStatus = normalizeStatusValue($status);

    /* وضعیت و پاسخ پیشین برای تشخیص «تغییر واقعی» */
    $previous = getReportById($pdo, $id);
    $previousStatus = $previous ? normalizeStatusValue((string) ($previous['status'] ?? '')) : '';
    /* مقایسه‌ی پاسخ بدون حساسیت به نوع خط جدید (مرورگر CRLF می‌فرستد، ذخیره‌شده‌ی قدیمی
       ممکن است LF باشد؛ نباید این تفاوت، پاسخ قدیمی را «تازه» نشان دهد) */
    $normText = static fn($t): string => trim(str_replace(["\r\n", "\r"], "\n", (string) $t));
    $previousReply = $previous ? $normText($previous['reply'] ?? '') : '';

    $statusChanged = $previousStatus !== $normStatus;
    $replyIsNew    = $normText($reply) !== '' && $normText($reply) !== $previousReply;

    $stmt = $pdo->prepare('UPDATE reports SET reply = :reply, status = :status WHERE id = :id');
    $stmt->bindValue(':reply', $reply);
    $stmt->bindValue(':status', $normStatus);
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    /* ── روند رسیدگی: همان گام‌هایی که شهروند در اپ می‌بیند ─────────────
       گام شروع برای گزارش‌های قدیمی هم ساخته می‌شود و گام تغییر وضعیت
       تنها وقتی ثبت می‌شود که وضعیت واقعاً عوض شده یا پاسخ تازه‌ای آمده
       باشد؛ پس با هر بار ذخیره، روند شلوغ نمی‌شود. */
    try {
        require_once dirname(__DIR__, 2) . '/shared/media.php';
        eplakReportTimelineBootstrap($pdo, $id, is_array($previous) ? $previous : []);
        if ($statusChanged || $replyIsNew) {
            eplakReportEventStatus($pdo, $id, $normStatus, $replyIsNew ? $reply : '');
        }
    } catch (Throwable $e) {
        /* روند رسیدگی هرگز نباید ذخیره‌ی وضعیت را متوقف کند */
    }

    /* ── ارسال خودکار اعلان به شهروند (اگر پاسخ یا وضعیت تازه‌ای آمده) ────
       از همان تابع مشترک تیکت‌ها استفاده می‌کنیم تا اعلان گزارش و تیکت یک
       شکل باشند و هم در فهرست اعلان‌های اپ ثبت شوند و هم (اگر اپ بسته باشد)
       از مسیر فایربیس به گوشی برسند. */
    $notify = [];
    try {
        $rep = getReportById($pdo, $id);
        $phone = trim((string) ($rep['user_phone'] ?? ''));
        if ($phone !== '' && ($statusChanged || $replyIsNew)) {
            require_once dirname(__DIR__, 2) . '/shared/notify_events.php';
            $notify = eplakNotifyReply(
                $pdo, $phone, 'گزارش', reportCodeFor($id), $normStatus,
                $replyIsNew ? $reply : '',
                $statusChanged
            );
        }
    } catch (Throwable $e) {
        /* بدون توقف عملیات اصلی؛ ولی علت در لاگ هاست می‌ماند */
        error_log('[eplak-admin:report.notify] ' . $e->getMessage());
    }
    return $notify;
}

function deleteReportReply(PDO $pdo, int $id): void {
    $stmt = $pdo->prepare('UPDATE reports SET reply = NULL, status = :status WHERE id = :id');
    $stmt->bindValue(':status', 'pending');
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

function getReportsByUser(PDO $pdo, string $userPhone): array {
    $stmt = $pdo->prepare('SELECT *, CONCAT("EP-1403-", LPAD(id + 1000, 4, "0")) AS code FROM reports WHERE user_phone = :user_phone ORDER BY created_at DESC');
    $stmt->bindValue(':user_phone', $userPhone);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * شرطِ «فقط تیکت‌های واقعی» برای کوئری‌های جدول tickets.
 * تیکت‌ها و چت‌های پشتیبانی کاملاً جدا هستند: چت‌ها (channel='support') فقط در
 * «پشتیبانی آنلاین» (admin/support.php) دیده می‌شوند و هرگز در فهرستِ تیکت‌ها
 * (و آمارِ تیکت‌ها) نمی‌آیند. اگر ستونِ channel هنوز روی دیتابیس نیست، هیچ
 * فیلتری اضافه نمی‌شود تا کوئری نشکند.
 */
function eplakNonSupportTicketsWhere(PDO $pdo): string
{
    if (function_exists('eplakTableHasColumn') && eplakTableHasColumn($pdo, 'tickets', 'channel')) {
        return " AND COALESCE(channel, '') <> 'support'";
    }
    return '';
}

function getTickets(PDO $pdo, string $statusFilter = 'all', string $search = ''): array {
    $query = 'SELECT * FROM tickets WHERE 1=1' . eplakNonSupportTicketsWhere($pdo);
    $params = [];

    if ($statusFilter !== 'all') {
        $query .= ' AND status = :status';
        $params[':status'] = normalizeStatusValue($statusFilter);
    }

    if ($search !== '') {
        $query .= ' AND (title LIKE :search OR user_phone LIKE :search)';
        $params[':search'] = '%' . $search . '%';
    }

    $query .= ' ORDER BY created_at DESC';

    $stmt = $pdo->prepare($query);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->execute();
    return $stmt->fetchAll();
}

function getAllTickets(PDO $pdo): array {
    return getTickets($pdo);
}

function getTicketsByUser(PDO $pdo, string $userPhone): array {
    $stmt = $pdo->prepare('SELECT *, CONCAT("TC-", LPAD(id + 1000, 4, "0")) AS code FROM tickets WHERE user_phone = :user_phone ORDER BY created_at DESC');
    $stmt->execute([':user_phone' => $userPhone]);
    return $stmt->fetchAll();
}

function createTicket(PDO $pdo, array $data): int {
    $stmt = $pdo->prepare('INSERT INTO tickets (user_phone, title, description, status, reply, category, department, priority) VALUES (:user_phone, :title, :description, :status, :reply, :category, :department, :priority)');
    $stmt->execute([
        ':user_phone' => trim((string)($data['user_phone'] ?? $data['phone'] ?? '')),
        ':title' => trim((string)($data['title'] ?? '')),
        ':description' => trim((string)($data['description'] ?? '')),
        ':status' => normalizeStatusValue((string)($data['status'] ?? 'pending')),
        ':reply' => (string)($data['reply'] ?? ''),
        ':category' => trim((string)($data['category'] ?? '')),
        ':department' => trim((string)($data['department'] ?? '')),
        ':priority' => trim((string)($data['priority'] ?? 'medium')),
    ]);
    return (int)$pdo->lastInsertId();
}

function updateTicket(PDO $pdo, int $id, array $data): void {
    $stmt = $pdo->prepare('UPDATE tickets SET user_phone = :user_phone, title = :title, description = :description, status = :status, reply = :reply, category = :category, department = :department, priority = :priority WHERE id = :id');
    $stmt->execute([
        ':user_phone' => trim((string)($data['user_phone'] ?? '')),
        ':title' => trim((string)($data['title'] ?? '')),
        ':description' => trim((string)($data['description'] ?? '')),
        ':status' => normalizeStatusValue((string)($data['status'] ?? 'pending')),
        ':reply' => (string)($data['reply'] ?? ''),
        ':category' => trim((string)($data['category'] ?? '')),
        ':department' => trim((string)($data['department'] ?? '')),
        ':priority' => trim((string)($data['priority'] ?? 'medium')),
        ':id' => $id,
    ]);
}

function getTicketById(PDO $pdo, int $id): ?array {
    $stmt = $pdo->prepare('SELECT * FROM tickets WHERE id = :id');
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $ticket = $stmt->fetch();
    return $ticket ?: null;
}

function saveTicketReply(PDO $pdo, int $id, string $reply, string $status): void {
    $normStatus = normalizeStatusValue($status);
    $before = getTicketById($pdo, $id);
    $beforeStatus = $before ? normalizeStatusValue((string) ($before['status'] ?? '')) : '';

    $stmt = $pdo->prepare('UPDATE tickets SET reply = :reply, status = :status WHERE id = :id');
    $stmt->bindValue(':reply', $reply);
    $stmt->bindValue(':status', $normStatus);
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    /* ── اعلان به کاربر ─────────────────────────────────────────────────
       پیش از این، پاسخ‌دادن به تیکت در پنل هیچ اعلانی نمی‌ساخت (نه در فهرست
       اعلان‌های اپ، نه روی گوشی)؛ کاربر بی‌خبر می‌ماند. حالا مثل گزارش‌ها،
       اعلان ساخته و به گوشی فرستاده می‌شود. */
    try {
        require_once dirname(__DIR__, 2) . '/shared/notify_events.php';
        $phone = (string) ($before['user_phone'] ?? '');
        if ($phone !== '' && ($beforeStatus !== $normStatus || trim($reply) !== '')) {
            $code = 'TK-' . str_pad((string) $id, 4, '0', STR_PAD_LEFT);
            eplakNotifyReply($pdo, $phone, 'تیکت', $code, $normStatus, $reply);
        }
    } catch (Throwable $e) {
        error_log('[eplak-admin:ticket.notify] ' . $e->getMessage());
    }
}

function deleteTicketReply(PDO $pdo, int $id): void {
    $stmt = $pdo->prepare('UPDATE tickets SET reply = NULL, status = :status WHERE id = :id');
    $stmt->bindValue(':status', 'pending');
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

function saveTicketDetails(PDO $pdo, int $id, string $title, string $description, string $userPhone, string $reply, string $status, string $category = '', string $department = '', string $priority = 'medium'): void {
    /* وضعیت/پاسخ قبلی برای تشخیص «تغییر واقعی» و ساخت اعلان */
    $before = getTicketById($pdo, $id);
    $beforeStatus = $before ? normalizeStatusValue((string) ($before['status'] ?? '')) : '';
    $beforeReply = $before ? trim((string) ($before['reply'] ?? '')) : '';

    updateTicket($pdo, $id, [
        'title' => $title,
        'description' => $description,
        'user_phone' => $userPhone,
        'reply' => $reply,
        'status' => $status,
        'category' => $category,
        'department' => $department,
        'priority' => $priority,
    ]);

    /* اعلان به کاربر (همان قاعده‌ی saveTicketReply) — این تابع از صفحه‌ی
       جزئیات و صفحه‌ی ویرایش تیکت صدا زده می‌شود. */
    try {
        require_once dirname(__DIR__, 2) . '/shared/notify_events.php';
        $normStatus = normalizeStatusValue($status);
        $phone = trim($userPhone) !== '' ? trim($userPhone) : (string) ($before['user_phone'] ?? '');
        $changed = ($beforeStatus !== $normStatus) || (trim($reply) !== $beforeReply);
        if ($phone !== '' && $changed && (trim($reply) !== '' || $beforeStatus !== $normStatus)) {
            $code = 'TK-' . str_pad((string) $id, 4, '0', STR_PAD_LEFT);
            eplakNotifyReply($pdo, $phone, 'تیکت', $code, $normStatus, $reply);
        }
    } catch (Throwable $e) {
        error_log('[eplak-admin:ticket.notify-details] ' . $e->getMessage());
    }
}

function deleteReport(PDO $pdo, int $id): void {
    $stmt = $pdo->prepare('DELETE FROM reports WHERE id = :id');
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

function deleteUser(PDO $pdo, int $id): void {
    $stmt = $pdo->prepare('DELETE FROM users WHERE id = :id');
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

function deleteTicket(PDO $pdo, int $id): void {
    /* پیام‌ها و پیوست‌هایِ این تیکت هم پاک می‌شوند (اگر جدولِ پیام باشد).
       تیکتِ واقعی هرگز channel='support' ندارد؛ حذفِ چت‌ها از admin/support.php است. */
    $paths = [];
    try {
        $stm = $pdo->prepare("SELECT media_path FROM ticket_messages WHERE ticket_id = :id AND media_path IS NOT NULL AND media_path <> ''");
        $stm->bindValue(':id', $id, PDO::PARAM_INT);
        $stm->execute();
        foreach ($stm->fetchAll(PDO::FETCH_COLUMN) as $rel) {
            $rel = trim((string) $rel);
            if ($rel === '') {
                continue;
            }
            $full = realpath(dirname(__DIR__, 2) . '/uploads/' . ltrim($rel, '/'));
            if ($full !== false && is_file($full)) {
                $paths[] = $full;
            }
        }
    } catch (Throwable $e) {
        /* نبودِ جدولِ پیام نباید جلوی حذفِ تیکت را بگیرد */
    }
    try {
        $pdo->prepare('DELETE FROM ticket_messages WHERE ticket_id = :id')
            ->execute([':id' => $id]);
    } catch (Throwable $e) {
    }
    $stmt = $pdo->prepare('DELETE FROM tickets WHERE id = :id');
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    foreach ($paths as $full) {
        @unlink($full);
    }
}

/* ============================================================
   اخبار و دانستنی‌ها
   ============================================================ */

/* ============================================================
   اخبار و دانستنی‌ها (CRUD سازگار با دیتابیس قدیمی)
   ------------------------------------------------------------
   ریشه‌ی باگ «اخبار و اطلاعیه‌ها در اپ و پنل خالی است»:
   این توابع پیش از این «همیشه» ستون badge (و گاهی summary/image_url) را
   می‌خواستند. روی دیتابیس قدیمیِ هاست آن ستون‌ها نبودند، پس:
     • افزودن/ویرایش مطلب در پنل همیشه با «Unknown column 'badge'» شکست می‌خورد
     • api/news.php خطای ۵۰۰ می‌داد و اپ هیچ خبری نشان نمی‌داد
   حالا ساختار جدول «همان لحظه» بررسی/ترمیم می‌شود (eplakNewsSchema) و همه‌ی
   SQLها فقط با ستون‌های موجود ساخته می‌شوند؛ موارد سازگار‌شده در $report
   برمی‌گردند تا پنل صادقانه بگوید چه چیزی ذخیره نشد.
   ============================================================ */

/** مقدارهای آماده‌ی درج/به‌روزرسانی (متن‌ها در صورت نیاز بدون ایموجی چهاربایتی) */
function eplakNewsFieldValues(PDO $pdo, array $data): array {
    $emoji = eplakNewsSupportsEmoji($pdo);
    $clean = static function ($value) use ($emoji) {
        $value = trim((string) ($value ?? ''));
        if ($value === '') {
            return null;
        }
        return $emoji ? $value : (eplakStripAstralChars($value) ?: $value);
    };

    $title = trim((string) ($data['title'] ?? ''));
    if (!$emoji && $title !== '') {
        $title = eplakStripAstralChars($title) ?: $title;
    }

    return [
        'type'       => ((string) ($data['type'] ?? 'news')) === 'tip' ? 'tip' : 'news',
        'title'      => $title,
        'summary'    => $clean($data['summary'] ?? ''),
        'body'       => $clean($data['body'] ?? ''),
        'icon'       => $clean($data['icon'] ?? ''),
        'badge'      => $clean($data['badge'] ?? ''),
        'image_url'  => $clean($data['image_url'] ?? ''),
        'published'  => !empty($data['published']) ? 1 : 0,
        'sort_order' => (int) ($data['sort_order'] ?? 0),
    ];
}

/** ستون‌هایی که «واقعاً» در جدول news وجود دارند (به ترتیب خواسته‌شده) */
function eplakNewsWritableColumns(PDO $pdo, array $values): array {
    $columns = eplakNewsAvailableColumns($pdo, array_keys($values));
    /* title و body ستون‌های حیاتی‌اند؛ بدون آن‌ها درج معنا ندارد */
    if (!in_array('title', $columns, true) || !in_array('body', $columns, true)) {
        return [];
    }
    return $columns;
}

/** چه چیزهایی به‌خاطر دیتابیس قدیمی از دست رفت (برای نمایش در پنل) */
function eplakNewsDegradedNotes(PDO $pdo, array $values): array {
    $notes = [];
    foreach (array_keys($values) as $column) {
        if ($column === 'title' || $column === 'body') {
            continue;
        }
        if (!eplakNewsHasColumn($pdo, $column)) {
            $notes[] = 'no_' . $column;
        }
    }
    if (!eplakNewsSupportsEmoji($pdo)) {
        $notes[] = 'no_emoji';
    }
    return array_values(array_unique($notes));
}

/** ساخت INSERT با ستون‌های موجود و اجرای آن؛ شناسه‌ی ردیف برمی‌گردد (۰ = ناموفق) */
function eplakNewsInsertRow(PDO $pdo, array $values, array $columns): int {
    if (!$columns) {
        return 0;
    }
    $placeholders = [];
    $params = [];
    foreach ($columns as $column) {
        $placeholders[] = ':' . $column;
        $params[':' . $column] = $values[$column] ?? null;
    }
    $stmt = $pdo->prepare(
        'INSERT INTO news (' . implode(', ', $columns) . ') VALUES (' . implode(', ', $placeholders) . ')'
    );
    $stmt->execute($params);
    return (int) $pdo->lastInsertId();
}

function getAllNews(PDO $pdo, string $type = '', ?array &$report = null): array {
    $rep = ['ok' => true, 'rows' => 0, 'degraded' => [], 'error' => ''];
    $schema = eplakNewsSchema($pdo);
    if (!$schema['table']) {
        $rep['ok'] = false;
        $rep['error'] = 'جدول news در دیتابیس وجود ندارد';
        $rep['degraded'] = $schema['failed'];
        $report = $rep;
        return [];
    }

    /* sort_order هم ممکن است در دیتابیس قدیمی نباشد */
    $order = eplakNewsHasColumn($pdo, 'sort_order') ? 'sort_order ASC, id DESC' : 'id DESC';
    if ($type === '') {
        $order = eplakNewsHasColumn($pdo, 'sort_order') ? 'type ASC, sort_order ASC, id DESC' : 'type ASC, id DESC';
    }

    $fetch = static function (PDO $pdo, string $type, string $order): array {
        if ($type === 'news' || $type === 'tip') {
            $stmt = $pdo->prepare('SELECT * FROM news WHERE type = :type ORDER BY ' . $order);
            $stmt->execute([':type' => $type]);
            return $stmt->fetchAll();
        }
        return $pdo->query('SELECT * FROM news ORDER BY ' . $order)->fetchAll();
    };

    try {
        $rows = $fetch($pdo, $type, $order);
    } catch (\Throwable $e) {
        /* یک‌بار ترمیمِ اجباری و تلاش دوباره؛ وگرنه فهرست خالی برمی‌گردد نه صفحه‌ی سفید */
        try {
            eplakNewsSchema($pdo, true);
            $order = eplakNewsHasColumn($pdo, 'sort_order') ? 'sort_order ASC, id DESC' : 'id DESC';
            $rows = $fetch($pdo, $type, $order);
            $rep['degraded'][] = 'repaired_on_read';
        } catch (\Throwable $e2) {
            $rep['ok'] = false;
            $rep['error'] = $e2->getMessage();
            $report = $rep;
            return [];
        }
    }

    $rep['rows'] = count($rows);
    $rep['degraded'] = array_merge($rep['degraded'], $schema['failed']);
    $report = $rep;
    return $rows;
}

function getNewsById(PDO $pdo, int $id): ?array {
    try {
        eplakNewsSchema($pdo);
        $stmt = $pdo->prepare('SELECT * FROM news WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    } catch (\Throwable $e) {
        return null;
    }
}

/**
 * افزودن مطلب جدید.
 * $report (اختیاری): ['ok', 'id', 'degraded' => [...], 'error'] — پنل با آن
 * صادقانه می‌گوید چه فیلدی به‌خاطر دیتابیس قدیمی ذخیره نشد.
 */
function createNews(PDO $pdo, array $data, ?array &$report = null): int {
    $rep = ['ok' => false, 'id' => 0, 'degraded' => [], 'error' => ''];
    $schema = eplakNewsSchema($pdo);
    if (!$schema['table']) {
        $rep['error'] = 'جدول news در دیتابیس وجود ندارد و ساخته نشد';
        $rep['degraded'] = $schema['failed'];
        $report = $rep;
        return 0;
    }

    $values  = eplakNewsFieldValues($pdo, $data);
    $columns = eplakNewsWritableColumns($pdo, $values);
    if (!$columns) {
        $rep['error'] = 'ستون‌های title/body در جدول news در دسترس نیستند';
        $rep['degraded'] = $schema['failed'];
        $report = $rep;
        return 0;
    }
    $rep['degraded'] = eplakNewsDegradedNotes($pdo, $values);

    try {
        $rep['id'] = eplakNewsInsertRow($pdo, $values, $columns);
        $rep['ok'] = $rep['id'] > 0;
    } catch (\Throwable $e) {
        /* تلاش دوم: ستون‌های غیرحیاتی کنار گذاشته می‌شوند */
        try {
            eplakNewsSchema($pdo, true);
            $columns = eplakNewsWritableColumns($pdo, $values);
            $rep['id'] = eplakNewsInsertRow($pdo, $values, $columns);
            $rep['ok'] = $rep['id'] > 0;
            if ($rep['ok']) {
                $rep['degraded'][] = 'retry_after_repair';
            }
        } catch (\Throwable $e2) {
            try {
                $basic = array_values(array_intersect($columns, ['type', 'title', 'summary', 'body']));
                $rep['id'] = eplakNewsInsertRow($pdo, $values, $basic);
                $rep['ok'] = $rep['id'] > 0;
                if ($rep['ok']) {
                    $rep['degraded'][] = 'saved_minimal';
                }
            } catch (\Throwable $e3) {
                $rep['ok'] = false;
                $rep['error'] = $e3->getMessage();
            }
        }
    }

    /* گزارش همیشه به فراخوان برمی‌گردد؛ فراخوان‌ها پیش از صدا زدن $report = null می‌گذارند
       و شرط «!== null» باعث می‌شد گزارش هرگز نرسد (ذخیره‌ی موفق، ناموفق دیده می‌شد). */
    $report = $rep;
    return (int) $rep['id'];
}

/** ویرایش مطلب — سازگار با ستون‌های موجود (بدون «Unknown column») */
function updateNews(PDO $pdo, int $id, array $data, ?array &$report = null): bool {
    $rep = ['ok' => false, 'degraded' => [], 'error' => ''];
    $schema = eplakNewsSchema($pdo);
    $values  = eplakNewsFieldValues($pdo, $data);
    $columns = eplakNewsWritableColumns($pdo, $values);
    if (!$schema['table'] || !$columns) {
        $rep['error'] = 'جدول یا ستون‌های لازم در دیتابیس در دسترس نیست';
        $rep['degraded'] = $schema['failed'];
        $report = $rep;
        return false;
    }
    $rep['degraded'] = eplakNewsDegradedNotes($pdo, $values);

    $run = static function (PDO $pdo, int $id, array $values, array $columns): void {
        $set = [];
        $params = [':id' => $id];
        foreach ($columns as $column) {
            $set[] = $column . ' = :' . $column;
            $params[':' . $column] = $values[$column] ?? null;
        }
        $stmt = $pdo->prepare('UPDATE news SET ' . implode(', ', $set) . ' WHERE id = :id');
        $stmt->execute($params);
    };

    try {
        $run($pdo, $id, $values, $columns);
        $rep['ok'] = true;
    } catch (\Throwable $e) {
        try {
            eplakNewsSchema($pdo, true);
            $columns = eplakNewsWritableColumns($pdo, $values);
            $run($pdo, $id, $values, $columns);
            $rep['ok'] = true;
            $rep['degraded'][] = 'retry_after_repair';
        } catch (\Throwable $e2) {
            try {
                $basic = array_values(array_intersect($columns, ['type', 'title', 'summary', 'body']));
                $run($pdo, $id, $values, $basic);
                $rep['ok'] = true;
                $rep['degraded'][] = 'saved_minimal';
            } catch (\Throwable $e3) {
                $rep['error'] = $e3->getMessage();
            }
        }
    }

    $report = $rep;
    return (bool) $rep['ok'];
}

function deleteNews(PDO $pdo, int $id): bool {
    try {
        eplakNewsSchema($pdo);
        $stmt = $pdo->prepare('DELETE FROM news WHERE id = :id');
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return true;
    } catch (\Throwable $e) {
        return false;
    }
}

function toggleNewsPublished(PDO $pdo, int $id): bool {
    /* پیاده‌سازی سازگار با هر دو درایور (MySQL و SQLite) — تابع IF() در SQLite
       وجود ندارد و قبلاً این عملیات در حالت توسعه خطا می‌داد. */
    try {
        eplakNewsSchema($pdo);
        if (!eplakNewsHasColumn($pdo, 'published')) {
            return false;
        }
        $select = $pdo->prepare('SELECT published FROM news WHERE id = :id');
        $select->bindValue(':id', $id, PDO::PARAM_INT);
        $select->execute();
        $current = $select->fetchColumn();
        if ($current === false) {
            return false;
        }
        $newValue = ((int) $current) === 1 ? 0 : 1;
        $stmt = $pdo->prepare('UPDATE news SET published = :published WHERE id = :id');
        $stmt->bindValue(':published', $newValue, PDO::PARAM_INT);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return true;
    } catch (\Throwable $e) {
        return false;
    }
}

/** وضعیت خلاصه‌ی جدول اخبار برای نمایش در پنل (تعداد + سلامت ساختار) */
function eplakNewsAdminStatus(PDO $pdo): array {
    $schema = eplakNewsSchema($pdo);
    $out = [
        'table'    => (bool) $schema['table'],
        'emoji'    => (bool) $schema['emoji'],
        'badge'    => !empty($schema['columns']['badge']),
        'image'    => !empty($schema['columns']['image_url']),
        'repaired' => $schema['repaired'],
        'failed'   => $schema['failed'],
        'all'      => 0,
        'news'     => 0,
        'tip'      => 0,
        'published' => 0,
        'error'    => '',
    ];
    try {
        $out['all']  = (int) $pdo->query('SELECT COUNT(*) FROM news')->fetchColumn();
        if (eplakNewsHasColumn($pdo, 'type')) {
            $stmt = $pdo->query("SELECT COUNT(*) FROM news WHERE type = 'news'");
            $out['news'] = (int) $stmt->fetchColumn();
            $stmt = $pdo->query("SELECT COUNT(*) FROM news WHERE type = 'tip'");
            $out['tip'] = (int) $stmt->fetchColumn();
        }
        if (eplakNewsHasColumn($pdo, 'published')) {
            $out['published'] = (int) $pdo->query('SELECT COUNT(*) FROM news WHERE published = 1')->fetchColumn();
        } else {
            $out['published'] = $out['all'];
        }
    } catch (\Throwable $e) {
        $out['error'] = $e->getMessage();
    }
    return $out;
}

/* ============================================================
   اعلان‌ها (ارسال تکی و گروهی)
   ============================================================ */

/**
 * ارسال اعلان به کاربران.
 * $targetType: 'all' = همه کاربران | 'selected' = شماره‌های مشخص‌شده
 * $report (اختیاری): گزارش کاملِ «چه شد» برای نمایش در پنل — شمار گیرندگان،
 *   شناسه‌ی ارسال، موارد «سازگار‌شده» (دیتابیس قدیمی) و خطاها.
 * returns: تعداد گیرندگان
 *
 * نکته‌ی مهم (ریشه‌ی باگ «اعلان پنل روی اپ نمی‌آید»):
 * پیش از این، INSERT اینجا «همیشه» ستون send_id را می‌خواست. روی دیتابیس
 * قدیمیِ هاست (backend/eplak-db.sql) آن ستون وجود ندارد، پس کل ارسال با خطای
 *   SQLSTATE[42S22]: Column not found: 1054 Unknown column 'send_id' in 'INSERT INTO'
 * واگر می‌شد و هیچ اعلانی ساخته نمی‌شد. حالا اول ستون «ترمیم» می‌شود و اگر
 * ترمیم ممکن نبود (کاربر دیتابیس اجازه‌ی ALTER ندارد) بدون همان ستون ذخیره
 * می‌شود؛ یعنی اعلان در هر حالتی به اپ کاربر می‌رسد.
 */
function sendNotification(PDO $pdo, string $title, string $body, string $targetType, array $phones, ?string $createdBy = null, ?array &$report = null): int {
    /* موتور اعلان پس‌زمینه (مرورگر) و اعلان اپ اندروید (فایربیس) */
    require_once __DIR__ . '/../../shared/webpush.php';
    require_once __DIR__ . '/../../shared/fcm.php';
    require_once __DIR__ . '/../../shared/bootstrap.php';

    $report = [
        'recipients' => 0, 'rows' => 0, 'send_id' => 0,
        'degraded' => [], 'failed' => [], 'errors' => [],
    ];

    /* ── بررسی/ترمیم ساختار جدول اعلان‌ها «پیش از» تراکنش ─────────────────
       (در MySQL دستور ALTER تراکنش را می‌شکند؛ پس بیرون از آن انجام می‌شود) */
    $schema    = eplakNotificationsSchema($pdo);
    $hasSendId = !empty($schema['send_id']);
    $hasFk     = !empty($schema['fk']);
    if (!$hasSendId) {
        $report['degraded'][] = 'no_send_id';
    }
    if ($hasFk) {
        $report['degraded'][] = 'foreign_key';
    }
    if (empty($schema['emoji'])) {
        $report['degraded'][] = 'no_emoji';
    }
    $report['failed'] = array_values($schema['failed'] ?? []);

    /* شماره‌ها یکدست می‌شوند (۰۹۱۲… / +۹۸۹۱۲… / ۹۱۲… / رقم فارسی → یک کلید)؛
       وگرنه اعلان «انتخابی» زیر شماره‌ای دیگر ذخیره می‌شد و اپ آن را نمی‌دید. */
    $clean = [];
    foreach ($phones as $one) {
        $key = eplakPhoneKey((string) $one);
        if ($key !== '' && $key !== 'all') {
            $clean[$key] = true;
        }
    }
    if ($targetType === 'all') {
        try {
            foreach ($pdo->query('SELECT phone FROM users')->fetchAll(PDO::FETCH_COLUMN) ?: [] as $one) {
                $key = eplakPhoneKey((string) $one);
                if ($key !== '') {
                    $clean[$key] = true;
                }
            }
        } catch (Throwable $e) {
            /* جدول users خوانده نشد؛ همان فهرست داده‌شده کافی است */
        }
    }
    $phones = array_keys($clean);

    /* چه ردیف‌هایی ساخته شود؟
       • send_id داریم  → برای هر کاربر یک ردیف شخصی + یک ردیف عمومی 'all'
         (اپ ردیف عمومی را وقتی نسخه‌ی شخصیِ همان ارسال را دارد نشان نمی‌دهد).
       • send_id نداریم → فقط یک ردیف عمومی 'all'؛ وگرنه کاربر «دو بار» همان
         اعلان را می‌دید (یکی شخصی و یکی عمومی) و راهی برای تشخیص نبود.
       ردیف عمومی همیشه «تلاش» می‌شود؛ اگر کلید خارجی قدیمیِ دیتابیس اجازه
       نداد، پایین‌تر برای هر کاربر ردیف شخصی ساخته می‌شود تا اعلان گم نشود. */
    $plan = [];
    if ($targetType === 'all') {
        if ($hasSendId) {
            foreach ($phones as $one) {
                $plan[] = $one;
            }
        }
        $plan[] = 'all';
    } else {
        foreach ($phones as $one) {
            $plan[] = $one;
        }
    }

    if (!$plan) {
        return 0;
    }

    /* تعداد گیرندگان = تعداد ردیف‌هایی که نوشته می‌شود (شامل ردیف عمومی 'all'
       برای مهمان‌ها) — همان معنایی که پیش از این هم برگردانده می‌شد. */
    $recipients = max(count($plan), 1);
    $report['recipients'] = $recipients;

    /* کلید خارجیِ قدیمیِ دیتابیس، ردیف عمومی 'all' را رد می‌کرد (مهمان‌ها هیچ
       اعلان پنلی نمی‌دیدند). برای مدت همین تراکنش خاموش می‌شود و در finally
       برمی‌گردد. اگر ممکن نباشد، پایین‌تر ردیف شخصیِ هر کاربر ساخته می‌شود. */
    $fkRelaxed = $hasFk && $targetType === 'all' && function_exists('eplakFkRelaxBegin')
        ? eplakFkRelaxBegin($pdo)
        : false;
    if ($fkRelaxed) {
        $report['degraded'][] = 'fk_bypassed_for_broadcast';
    }

    $pdo->beginTransaction();
    try {
        $sendId = 0;
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO notification_sends (title, body, target_type, recipients_count, created_by)
                 VALUES (:title, :body, :target, :count, :by)'
            );
            $stmt->execute([
                ':title' => eplakNotificationsSupportsEmoji($pdo) ? $title : eplakStripAstralChars($title),
                ':body'  => eplakNotificationsSupportsEmoji($pdo) ? $body : eplakStripAstralChars($body),
                ':target' => $targetType === 'all' ? 'all' : 'selected',
                ':count' => $recipients,
                ':by'    => $createdBy,
            ]);
            $sendId = (int) $pdo->lastInsertId();
        } catch (Throwable $e) {
            /* جدول notification_sends ساخته نشده (دیتابیس خیلی قدیمی) —
               اعلان‌ها را بدون «شناسه‌ی ارسال» ثبت می‌کنیم تا پیام گم نشود. */
            $hasSendId = false;
            $report['degraded'][] = 'no_notification_sends';
            $report['errors'][] = $e->getMessage();
        }
        $report['send_id'] = $sendId;

        $rows = 0;
        $broadcastBlocked = false;
        $linkedSendId = $hasSendId && $sendId > 0 ? $sendId : null;
        foreach ($plan as $target) {
            $res = eplakNotificationInsert($pdo, (string) $target, $title, $body, $linkedSendId);
            if (!empty($res['ok'])) {
                $rows++;
                if ((string) $target === 'all') {
                    $report['broadcast_row'] = (int) $res['id'];
                }
            } elseif ((string) $target === 'all') {
                /* ردیف عمومی ذخیره نشد (کلید خارجیِ دیتابیس قدیمی و دسترسی
                   بسته) — پایین‌تر به‌جایش ردیف شخصیِ هر کاربر ساخته می‌شود. */
                $broadcastBlocked = true;
                $report['degraded'][] = 'broadcast_row_blocked';
            } else {
                $report['errors'][] = (string) $res['error'];
            }
        }

        if ($broadcastBlocked && $targetType === 'all' && $phones) {
            foreach ($phones as $one) {
                if (in_array($one, $plan, true)) {
                    continue;   /* قبلاً تلاش شد */
                }
                $res = eplakNotificationInsert($pdo, (string) $one, $title, $body, $linkedSendId);
                if (!empty($res['ok'])) {
                    $rows++;
                } else {
                    $report['errors'][] = (string) $res['error'];
                }
            }
        }
        if ($rows === 0) {
            $pdo->rollBack();
            $why = implode(' | ', array_slice(array_filter($report['errors']), 0, 2));
            throw new RuntimeException(
                'هیچ اعلانی ذخیره نشد. '
                . ($why !== '' ? 'علت: ' . $why . '. ' : '')
                . 'اگر علت «Unknown column \'send_id\'» است و خودِ کد نتوانست ستون را اضافه کند، '
                . 'این دستور را یک‌بار در phpMyAdmin اجرا کنید: '
                . 'ALTER TABLE `notifications` ADD COLUMN `send_id` INT NULL;'
            );
        }
        /* شمارش واقعیِ گیرندگان (ممکن است با برنامه‌ی اولیه فرق کند: مثلاً ردیف
           عمومی به‌خاطر کلید خارجی ذخیره نشد و به‌جایش ردیف شخصی ساخته شد) */
        if ($sendId > 0 && $rows !== $recipients) {
            try {
                $fix = $pdo->prepare('UPDATE notification_sends SET recipients_count = :c WHERE id = :id');
                $fix->execute([':c' => $rows, ':id' => $sendId]);
            } catch (Throwable $e) {
                /* ستون/جدول قدیمی؛ شمارش نمایشی مهم‌تر از خود اعلان نیست */
            }
        }
        $recipients = $rows;
        $report['recipients'] = $rows;

        $pdo->commit();
        $report['rows'] = $rows;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    } finally {
        if (function_exists('eplakFkRelaxEnd')) {
            eplakFkRelaxEnd($pdo, $fkRelaxed);
        }
    }

    /* ── اعلان پس‌زمینه (Web Push) ────────────────────────────────────────
       اعلان‌های بالا فقط داخل برنامه دیده می‌شوند؛ این بخش همان پیام را به‌صورت
       نوتیفیکیشن سیستمی گوشی می‌فرستد تا در حالت «قفل بودن صفحه» و «بسته بودن
       برنامه» هم به شهروند برسد. هر خطایی این‌جا فقط ثبت می‌شود و ارسال اعلان
       داخل‌برنامه‌ای را خراب نمی‌کند. */
    try {
        $subscriptions = $targetType === 'all'
            ? eplakPushSubscriptions($pdo, [], true)
            : eplakPushSubscriptions($pdo, $phones, false);

        $pushSummary = eplakWebPushSend(
            $pdo,
            $subscriptions,
            $title,
            $body,
            ['url' => 'index.html', 'tag' => 'eplak-send-' . $sendId, 'id' => $sendId]
        );

        try {
            $upd = $pdo->prepare('UPDATE notification_sends SET push_sent = :sent, push_failed = :failed WHERE id = :id');
            $upd->execute([
                ':sent'   => (int) $pushSummary['sent'],
                ':failed' => (int) $pushSummary['failed'],
                ':id'     => $sendId,
            ]);
        } catch (Throwable $e) {
            /* ستون‌های شمارش پوش در نسخه‌های قدیمی دیتابیس ممکن است نباشند */
        }
        $report['push_sent']   = (int) $pushSummary['sent'];
        $report['push_failed'] = (int) $pushSummary['failed'];
    } catch (Throwable $e) {
        error_log('[eplak-push] dispatch failed: ' . $e->getMessage());
    }

    /* ── اعلان گوشی برای اپ اندروید (فایربیس/FCM) ──────────────────────────
       اندروید در WebView اجازه‌ی Web Push نمی‌دهد؛ این مسیر اعلان را در حالت
       «بسته بودن کامل اپ» هم به گوشی می‌رساند. */
    try {
        $devices = $targetType === 'all'
            ? eplakFcmTokens($pdo, [], true)
            : eplakFcmTokens($pdo, $phones, false);

        if ($devices) {
            $fcmSummary = eplakFcmSend(
                $pdo,
                $devices,
                $title,
                $body,
                ['url' => 'index.html', 'tag' => 'eplak-send-' . $sendId, 'id' => $sendId]
            );

            try {
                $upd = $pdo->prepare('UPDATE notification_sends SET fcm_sent = :sent, fcm_failed = :failed WHERE id = :id');
                $upd->execute([
                    ':sent'   => (int) $fcmSummary['sent'],
                    ':failed' => (int) $fcmSummary['failed'],
                    ':id'     => $sendId,
                ]);
            } catch (Throwable $e) {
                /* ستون‌های شمارش فایربیس در دیتابیس‌های قدیمی ممکن است نباشند */
            }
            $report['fcm_devices'] = count($devices);
            $report['fcm_sent']    = (int) $fcmSummary['sent'];
            $report['fcm_failed']  = (int) $fcmSummary['failed'];
            $report['fcm_outcome'] = (string) ($fcmSummary['outcome'] ?? '');
            $report['fcm_hint']    = (string) ($fcmSummary['hint'] ?? '');
        } else {
            $report['fcm_devices'] = 0;
            $report['fcm_outcome'] = 'no_device';
        }
    } catch (Throwable $e) {
        error_log('[eplak-fcm] dispatch failed: ' . $e->getMessage());
    }

    return $recipients;
}

function getNotificationSends(PDO $pdo, int $limit = 50): array {
    $stmt = $pdo->prepare('SELECT * FROM notification_sends ORDER BY id DESC LIMIT ' . (int)$limit);
    $stmt->execute();
    return $stmt->fetchAll();
}

function getNotificationSendById(PDO $pdo, int $id): ?array {
    $stmt = $pdo->prepare('SELECT * FROM notification_sends WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * گیرندگان یک «ارسال گروهی».
 *
 * مسیر اصلی با ستون send_id کار می‌کند. روی دیتابیس قدیمیِ هاست که آن ستون
 * وجود ندارد (و کد نتوانست اضافه‌اش کند)، ردیف‌های همان ارسال را از روی
 * عنوان/متن پیدا می‌کنیم تا صفحه‌ی «گیرندگان» خالی نماند.
 */
function getNotificationRecipients(PDO $pdo, int $sendId): array {
    if (eplakTableHasColumn($pdo, 'notifications', 'send_id')) {
        try {
            $stmt = $pdo->prepare('SELECT * FROM notifications WHERE send_id = :id ORDER BY id ASC');
            $stmt->execute([':id' => $sendId]);
            return $stmt->fetchAll();
        } catch (Throwable $e) {
            /* ستون هست ولی کوئری خطا داد → مسیر جایگزین پایین */
        }
    }
    $send = getNotificationSendById($pdo, $sendId);
    if (!$send) {
        return [];
    }
    try {
        $stmt = $pdo->prepare('SELECT * FROM notifications WHERE title = :title AND body = :body ORDER BY id ASC');
        $stmt->execute([':title' => (string) $send['title'], ':body' => (string) $send['body']]);
        return $stmt->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
}

/* ============================================================
   فایل‌های پیوست گزارش‌ها (عکس و فیلم) — نمایش در پنل مدیریت
   ============================================================ */

/** فهرست فایل‌های یک گزارش */
function getReportMedia(PDO $pdo, int $reportId): array {
    return eplakMediaForReport($pdo, $reportId);
}

/** تعداد فایل‌های هر گزارش: [report_id => ['image'=>n,'video'=>n,'total'=>n]] */
function getReportMediaCounts(PDO $pdo, array $reportIds = []): array {
    return eplakMediaCounts($pdo, $reportIds);
}

/** آدرس نمایش فایل از داخل صفحه‌های پوشه‌ی admin (یک پله بالاتر از ریشه‌ی اپ) */
function adminMediaUrl(string $path): string {
    $path = trim($path);
    if ($path === '') {
        return '';
    }
    if (preg_match('#^(https?:)?//#i', $path) || strpos($path, '../') === 0) {
        return $path;
    }
    return '../' . ltrim($path, '/');
}

/** حجم خوانا برای نمایش در پنل */
function formatBytesFa(int $bytes): string {
    if ($bytes <= 0) {
        return '—';
    }
    $units = ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت'];
    $index = 0;
    $value = (float) $bytes;
    while ($value >= 1024 && $index < count($units) - 1) {
        $value /= 1024;
        $index++;
    }
    $text = $index === 0 ? (string) (int) $value : number_format($value, 1, '.', '');
    return $text . ' ' . $units[$index];
}

/* ============================================================
   حساب مدیر: تغییر نام کاربری و رمز عبور
   ============================================================ */

function getAdminById(PDO $pdo, int $id): ?array {
    try {
        $stmt = $pdo->prepare('SELECT * FROM admin_users WHERE id = :id LIMIT 1');
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $admin = $stmt->fetch();
        return $admin ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

function getAdminByUsername(PDO $pdo, string $username): ?array {
    try {
        $stmt = $pdo->prepare('SELECT * FROM admin_users WHERE username = :username LIMIT 1');
        $stmt->execute([':username' => $username]);
        $admin = $stmt->fetch();
        return $admin ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

/** آیا نام کاربری برای مدیر دیگری رزرو شده است؟ */
function adminUsernameTaken(PDO $pdo, string $username, int $exceptId = 0): bool {
    $stmt = $pdo->prepare('SELECT id FROM admin_users WHERE username = :username AND id <> :id LIMIT 1');
    $stmt->bindValue(':username', $username);
    $stmt->bindValue(':id', $exceptId, PDO::PARAM_INT);
    $stmt->execute();
    return (bool) $stmt->fetchColumn();
}

/** تغییر نام کاربری مدیر (خروجی: پیام خطا یا رشته‌ی خالی در صورت موفقیت) */
function updateAdminUsername(PDO $pdo, int $id, string $username): string {
    $username = trim($username);
    if ($username === '') {
        return 'نام کاربری نمی‌تواند خالی باشد.';
    }
    if (mb_strlen($username) < 3) {
        return 'نام کاربری باید حداقل ۳ کاراکتر باشد.';
    }
    if (mb_strlen($username) > 60) {
        return 'نام کاربری بیش از حد بلند است (حداکثر ۶۰ کاراکتر).';
    }
    if (!preg_match('/^[A-Za-z0-9._\-@\x{0600}-\x{06FF}]+$/u', $username)) {
        return 'نام کاربری فقط می‌تواند شامل حروف فارسی/انگلیسی، عدد و علامت‌های . _ - @ باشد.';
    }
    if (adminUsernameTaken($pdo, $username, $id)) {
        return 'این نام کاربری قبلاً استفاده شده است.';
    }

    $stmt = $pdo->prepare('UPDATE admin_users SET username = :username WHERE id = :id');
    $stmt->execute([':username' => $username, ':id' => $id]);
    return '';
}

/** تغییر رمز عبور مدیر — بررسی رمز فعلی، سنجش قدرت و ذخیره‌ی هش امن */
function updateAdminPassword(PDO $pdo, int $id, string $currentPassword, string $newPassword, string $confirmPassword): string {
    if ($currentPassword === '' || $newPassword === '') {
        return 'رمز عبور فعلی و رمز جدید الزامی هستند.';
    }
    if ($newPassword !== $confirmPassword) {
        return 'رمز جدید و تکرار آن یکسان نیستند.';
    }
    if (mb_strlen($newPassword) < 8) {
        return 'رمز جدید باید حداقل ۸ کاراکتر باشد.';
    }
    if (!preg_match('/[A-Za-z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword)) {
        return 'رمز جدید باید ترکیبی از حرف و عدد باشد.';
    }

    $admin = getAdminById($pdo, $id);
    if (!$admin) {
        return 'حساب مدیر یافت نشد.';
    }
    if (!password_verify($currentPassword, (string) $admin['password_hash'])) {
        return 'رمز عبور فعلی صحیح نیست.';
    }
    if (password_verify($newPassword, (string) $admin['password_hash'])) {
        return 'رمز جدید باید با رمز قبلی متفاوت باشد.';
    }

    $stmt = $pdo->prepare('UPDATE admin_users SET password_hash = :hash WHERE id = :id');
    $stmt->execute([':hash' => password_hash($newPassword, PASSWORD_DEFAULT), ':id' => $id]);
    return '';
}

/** تعداد اعلان‌های ارسال‌شده و آمار پوش برای صفحه‌ی تنظیمات */
function getPushStats(PDO $pdo): array {
    $stats = [
        'subscribers'  => eplakPushCount($pdo),
        'subscribers_all' => eplakPushCount($pdo, false),
        'last_sent'    => 0,
        'last_failed'  => 0,
        'last_send_title' => '',
        'last_send_at' => '',
    ];
    try {
        $row = $pdo->query('SELECT title, push_sent, push_failed, created_at FROM notification_sends ORDER BY id DESC LIMIT 1')->fetch();
        if ($row) {
            $stats['last_sent']       = (int) ($row['push_sent'] ?? 0);
            $stats['last_failed']     = (int) ($row['push_failed'] ?? 0);
            $stats['last_send_title'] = (string) ($row['title'] ?? '');
            $stats['last_send_at']    = (string) ($row['created_at'] ?? '');
        }
    } catch (Throwable $e) {
    }
    return $stats;
}

/** آخرین خطای ثبت‌شده‌ی اشتراک‌ها (برای عیب‌یابی در پنل) */
function getPushLastErrors(PDO $pdo, int $limit = 5): array {
    try {
        $stmt = $pdo->prepare(
            'SELECT user_phone, last_error, fail_count, updated_at FROM push_subscriptions
             WHERE last_error <> "" ORDER BY updated_at DESC LIMIT ' . (int) $limit
        );
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
}

/* ════════════════════════════════════════════════════════════════════════════
   داده‌های «حوزه‌محدود» برای مدیرانِ حوزه/معاونت (admin/includes/acl.php)
   ----------------------------------------------------------------------------
   چرا فیلتر در PHP و نه در SQL؟
     ۱) نامِ واحد در reports/tickets به‌صورت «متن» ذخیره می‌شود و در داده‌های
        قدیمی نیم‌فاصله/ی-ک/فاصله‌ی اضافی دارد؛ تطبیقِ دقیقِ آن در SQL برای هر دو
        درایور (MySQL و SQLite) یکسان درنمی‌آید، ولی eplakScopeKey() یک قانونِ
        واحد در PHP است و eplakScopeSqlExpr() دقیقاً همان قانون را با
        REPLACE/LOWER (که در هر دو دیتابیس هست) در SQL می‌سازد ⇒ فهرست‌ها و
        آمارِ زنده هیچ‌وقت با هم نمی‌جنگند.
     ۲) این صفحه‌ها هم‌اکنون هم «همه‌ی» ردیف‌ها را می‌خوانند (بدون صفحه‌بندی)،
        پس هزینه‌ی اضافه‌ای تحمیل نمی‌شود.
     ۳) تابع‌های موجود (getAllReports و …) دست‌نخورده می‌مانند ⇒ رفتار مدیر کل
        و آزمون‌های موجود دقیقاً مثل قبل است.
   ════════════════════════════════════════════════════════════════════════════ */

/** ردیف‌هایی که در دامنه‌ی مدیر هستند (کلیدها پیوسته می‌شوند) */
function eplakScopeFilterRows(array $rows, array $scope): array
{
    if (!empty($scope['is_super'])) {
        return $rows;
    }
    $out = [];
    foreach ($rows as $row) {
        if (is_array($row) && eplakScopeAllowsRow($row, $scope)) {
            $out[] = $row;
        }
    }
    return $out;
}

/**
 * ردیف‌های گزارش، بدونِ تابعِ مخصوصِ یک دیتابیس.
 * getAllReports از CONCAT/LPAD استفاده می‌کند که فقط در MySQL هست؛ اینجا ستونِ
 * «code» در خودِ PHP ساخته می‌شود تا همان داده هم روی MySQLِ هاست و هم روی
 * SQLite (آزمون‌ها/نصب‌های سبک) درست خوانده شود و قالبِ صفحه چیزی کم نداشته باشد.
 */
function eplakFetchReportsRows(PDO $pdo): array
{
    try {
        $rows = $pdo->query('SELECT * FROM reports ORDER BY created_at DESC')->fetchAll() ?: [];
    } catch (Throwable $e) {
        return [];
    }
    foreach ($rows as $index => $row) {
        if (!is_array($row)) {
            continue;
        }
        if (trim((string) ($row['code'] ?? '')) === '') {
            $rows[$index]['code'] = reportCodeFor((int) ($row['id'] ?? 0));
        }
    }
    return $rows;
}

/** کدِ نمایشی تیکت — دقیقاً همان قالبی که CONCAT/LPAD در MySQL می‌ساخت */
function eplakTicketCodeFor(int $id): string
{
    return 'TC-' . str_pad((string) ($id + 1000), 4, '0', STR_PAD_LEFT);
}

/** گزارش‌های در دامنه‌ی مدیر */
function getScopedReports(PDO $pdo, array $scope): array
{
    return eplakScopeFilterRows(eplakFetchReportsRows($pdo), $scope);
}

/** تیکت‌های در دامنه‌ی مدیر (با همان فیلتر وضعیت/جست‌وجوی صفحه) */
function getScopedTickets(PDO $pdo, array $scope, string $statusFilter = 'all', string $search = ''): array
{
    $rows = eplakScopeFilterRows(getTickets($pdo, $statusFilter, $search), $scope);
    foreach ($rows as $index => $row) {
        if (!is_array($row)) {
            continue;
        }
        if (trim((string) ($row['code'] ?? '')) === '') {
            $rows[$index]['code'] = eplakTicketCodeFor((int) ($row['id'] ?? 0));
        }
    }
    return $rows;
}

/** تازه‌ترین گزارش‌های در دامنه (برای داشبورد) */
function getScopedLatestReports(array $scopedReports, int $limit = 5): array
{
    return array_slice($scopedReports, 0, max(0, $limit));
}

/** تازه‌ترین تیکت‌های در دامنه (برای داشبورد) */
function getScopedLatestTickets(array $scopedTickets, int $limit = 5): array
{
    return array_slice($scopedTickets, 0, max(0, $limit));
}

/**
 * یک گزارش فقط اگر در دامنه‌ی مدیر باشد.
 * ⚠️ «پیدا نشد» و «خارج از حوزه» عمداً یکی برگردانده می‌شوند تا وجودِ گزارشِ
 *    حوزه‌ی دیگر برای مدیرِ حوزه افشا نشود (هیچ شماره/شناسه‌ای نشت نمی‌کند).
 */
function getScopedReportById(PDO $pdo, int $id, array $scope): ?array
{
    $row = getReportById($pdo, $id);
    if (!is_array($row)) {
        return null;
    }
    return eplakScopeAllowsRow($row, $scope) ? $row : null;
}

/** یک تیکت فقط اگر در دامنه‌ی مدیر باشد (همان قاعده‌ی عدم افشا).
 *  چتِ پشتیبانی (channel='support') تیکت نیست و این‌جا «پیدا نشد» برمی‌گردد تا
 *  در جزئیات/ویرایش/حذفِ تیکت باز نشود؛ جای چت‌ها «پشتیبانی آنلاین» است. */
function getScopedTicketById(PDO $pdo, int $id, array $scope): ?array
{
    $row = getTicketById($pdo, $id);
    if (!is_array($row)) {
        return null;
    }
    if (trim((string) ($row['channel'] ?? '')) === 'support') {
        return null;
    }
    return eplakScopeAllowsRow($row, $scope) ? $row : null;
}

/** آمار وضعیتِ گزارش‌های در دامنه (همان شکلِ خروجیِ getReportsStatusStats) */
function getScopedReportsStatusStats(array $scopedReports): array
{
    $stats = ['pending' => 0, 'in_progress' => 0, 'done' => 0];
    $total = 0;
    foreach ($scopedReports as $row) {
        $key = reportStatusOf(is_array($row) ? $row : []);
        if (!isset($stats[$key])) {
            $stats[$key] = 0;
        }
        $stats[$key]++;
        $total++;
    }
    return ['total' => $total, 'counts' => $stats];
}

/** نمودار «بر اساس واحد» فقط با ردیف‌های در دامنه (همان شکلِ getReportsByDepartment) */
function getScopedReportsByDepartment(array $scopedReports, int $limit = 8): array
{
    $buckets = [];
    foreach ($scopedReports as $row) {
        $name = trim((string) ($row['department'] ?? ''));
        if ($name === '') {
            $name = trim((string) ($row['sub_department'] ?? ''));
        }
        $key = $name !== '' ? $name : 'واحد نامشخص';
        $buckets[$key] = (int) ($buckets[$key] ?? 0) + 1;
    }
    arsort($buckets);
    $out = [];
    foreach ($buckets as $label => $count) {
        $out[] = ['label' => (string) $label, 'count' => $count];
    }
    if ($limit > 0 && count($out) > $limit) {
        $top = array_slice($out, 0, $limit);
        $rest = 0;
        foreach (array_slice($out, $limit) as $row) {
            $rest += (int) $row['count'];
        }
        $top[] = ['label' => 'سایر', 'count' => $rest];
        return $top;
    }
    return $out;
}

/**
 * روندِ ماهانه از ردیف‌های «در دامنه‌ی مدیرِ حوزه» — شکلِ خروجی و برچسب‌ها
 * دقیقاً همان getReportsMonthly است (شمسی)، فقط داده‌ها از ردیف‌های فیلترشده
 * می‌آیند نه از کلِ جدول.
 *
 * @param string|null $todayDb «اکنون» با ساعتِ خودِ دیتابیس تا سطلِ «این ماه»
 *        با ساعاتِ ثبت‌شده در دیتابیس هم‌مرز باشد (SQLite ساعتِ UTC می‌نویسد).
 */
function getScopedReportsMonthly(array $scopedReports, int $months = 6, ?string $todayDb = null): array
{
    $window = eplakJalaliMonthWindow($months, $todayDb);
    if (!$window) {
        return [];
    }
    return eplakMonthlyShape($window, eplakJalaliMonthCounts($scopedReports));
}

/**
 * آمار داشبوردِ حوزه‌محدود.
 * برای مدیر کل همان getDashboardStats است؛ برای مدیرِ حوزه، شمارش‌ها فقط از
 * ردیف‌های در دامنه می‌آیند و کارت‌هایی که به او مربوط نیستند null می‌شوند
 * (الگو آن‌ها را نشان نمی‌دهد) — نه صفر، تا «نداشتن دسترسی» با «صفر بودن»
 * اشتباه گرفته نشود.
 */
function getScopedDashboardStats(PDO $pdo, array $scope, array $scopedReports, array $scopedTickets): array
{
    if (!empty($scope['is_super'])) {
        return getDashboardStats($pdo);
    }

    $pendingReports = 0;
    $doneReports = 0;
    foreach ($scopedReports as $row) {
        $status = reportStatusOf(is_array($row) ? $row : []);
        if ($status === 'pending') {
            $pendingReports++;
        } elseif ($status === 'done') {
            $doneReports++;
        }
    }
    $pendingTickets = 0;
    foreach ($scopedTickets as $row) {
        if (normalizeStatusValue((string) ($row['status'] ?? '')) === 'pending') {
            $pendingTickets++;
        }
    }

    return [
        'reports_count'         => count($scopedReports),
        'tickets_count'         => count($scopedTickets),
        'pending_reports_count' => $pendingReports,
        'done_reports_count'    => $doneReports,
        'pending_tickets_count' => $pendingTickets,
        /* این‌ها به مدیرِ حوزه مربوط نیستند (تصمیم کارفرما) */
        'users_count'           => null,
        'news_count'            => null,
        'reports_with_media'    => null,
        'push_subscribers'      => null,
    ];
}

/* ============================================================
   مدیریت حساب‌های مدیر — صفحه‌ی admin/admins.php (فقط «مدیر کل»)
   ------------------------------------------------------------
   تصمیم کارفرما: مدیرِ هر حوزه/معاونت فقط «گزارش‌ها» و «تیکت‌ها»ی همان
   حوزه را می‌بیند (مشاهده + پاسخ + تغییر وضعیت) و به کاربران، واحدها،
   اخبار، اماکن، اعلان، خروجی و تنظیمات دسترسی ندارد.
   حوزه‌ها فقط از «واحدهای سطح اول» انتخاب می‌شوند (حوزه شهردار و معاونت‌ها)؛
   زیرمجموعه‌های هر واحد به‌صورت خودکار در دامنه‌ی همان مدیر قرار می‌گیرند
   (eplakAdminScopeNames در admin/includes/acl.php).
   ============================================================ */

/** واحدهای سطح اول (parent_id تهی/صفر) — همان‌هایی که می‌شود به یک مدیر سپرد */
function eplakTopLevelDepartments(PDO $pdo, bool $onlyActive = true): array
{
    $sql = 'SELECT id, name, slug, parent_id, is_active, description FROM departments
             WHERE (parent_id IS NULL OR parent_id = 0)';
    if ($onlyActive) {
        $sql .= ' AND is_active = 1';
    }
    $sql .= ' ORDER BY sort_order ASC, name ASC';
    try {
        $stmt = $pdo->query($sql);
        return $stmt->fetchAll() ?: [];
    } catch (Throwable $e) {
        /* ستون is_active/sort_order در دیتابیس خیلی قدیمی نباشد */
        try {
            $stmt = $pdo->query('SELECT id, name FROM departments WHERE (parent_id IS NULL OR parent_id = 0) ORDER BY name ASC');
            return $stmt->fetchAll() ?: [];
        } catch (Throwable $e2) {
            return [];
        }
    }
}

/** شناسه‌ی حوزه‌های سپرده‌شده به یک مدیر */
function eplakAdminDepartmentIds(PDO $pdo, int $adminId): array
{
    if ($adminId <= 0) {
        return [];
    }
    try {
        $stmt = $pdo->prepare('SELECT department_id FROM admin_departments WHERE admin_id = :id');
        $stmt->execute([':id' => $adminId]);
        $ids = [];
        foreach ($stmt->fetchAll() ?: [] as $row) {
            $id = (int) ($row['department_id'] ?? 0);
            if ($id > 0) {
                $ids[] = $id;
            }
        }
        return $ids;
    } catch (Throwable $e) {
        return [];
    }
}

/** فهرست حساب‌های مدیر + حوزه‌هایشان + آخرین ورود (بدون هش رمز!) */
function getAdminUsers(PDO $pdo): array
{
    $admins = [];
    try {
        $stmt = $pdo->query('SELECT id, username, full_name, role, is_active, last_login_at, created_at
                               FROM admin_users ORDER BY id ASC');
        $rows = $stmt->fetchAll() ?: [];
    } catch (Throwable $e) {
        /* ستون‌های تازه (full_name/is_active/last_login_at) روی دیتابیس قدیمی نباشد */
        try {
            $stmt = $pdo->query('SELECT id, username, role, created_at FROM admin_users ORDER BY id ASC');
            $rows = $stmt->fetchAll() ?: [];
        } catch (Throwable $e2) {
            return [];
        }
    }

    foreach ($rows as $row) {
        $id = (int) ($row['id'] ?? 0);
        $deptIds = eplakAdminDepartmentIds($pdo, $id);
        $deptNames = [];
        if ($deptIds) {
            $placeholders = implode(',', array_fill(0, count($deptIds), '?'));
            try {
                $q = $pdo->prepare("SELECT name FROM departments WHERE id IN ($placeholders) ORDER BY sort_order ASC, name ASC");
                $q->execute($deptIds);
                foreach ($q->fetchAll() ?: [] as $d) {
                    $name = trim((string) ($d['name'] ?? ''));
                    if ($name !== '') {
                        $deptNames[] = $name;
                    }
                }
            } catch (Throwable $e) {
            }
        }
        $admins[] = [
            'id'             => $id,
            'username'       => (string) ($row['username'] ?? ''),
            'full_name'      => trim((string) ($row['full_name'] ?? '')),
            'role'           => (string) ($row['role'] ?? 'admin'),
            'is_active'      => array_key_exists('is_active', $row) ? (int) $row['is_active'] : 1,
            'last_login_at'  => (string) ($row['last_login_at'] ?? ''),
            'created_at'     => (string) ($row['created_at'] ?? ''),
            'department_ids' => $deptIds,
            'departments'    => $deptNames,
            'messages'       => eplakDepartmentMessageCounts($pdo, $deptIds),
        ];
    }
    return $admins;
}

/** بازنویسی حوزه‌های یک مدیر (فقط واحدهای سطح اول پذیرفته می‌شوند) */
function eplakSetAdminDepartments(PDO $pdo, int $adminId, array $departmentIds): array
{
    $result = ['added' => 0, 'removed' => 0, 'error' => ''];
    if ($adminId <= 0) {
        $result['error'] = 'حساب مدیر پیدا نشد.';
        return $result;
    }

    /* فقط واحدهای سطحِ اولِ موجود در جدول واحدها — شناسه‌ی دلخواه پذیرفته نمی‌شود */
    $valid = [];
    foreach (eplakTopLevelDepartments($pdo, false) as $dept) {
        $valid[(int) ($dept['id'] ?? 0)] = true;
    }
    $wanted = [];
    foreach ($departmentIds as $id) {
        $id = (int) $id;
        if ($id > 0 && isset($valid[$id])) {
            $wanted[$id] = true;
        }
    }
    $wanted = array_keys($wanted);

    $current = eplakAdminDepartmentIds($pdo, $adminId);
    $toAdd = array_values(array_diff($wanted, $current));
    $toRemove = array_values(array_diff($current, $wanted));

    try {
        $now = function_exists('eplakDbNowString') ? eplakDbNowString($pdo) : date('Y-m-d H:i:s');
        foreach ($toAdd as $deptId) {
            $stmt = $pdo->prepare('INSERT INTO admin_departments (admin_id, department_id, created_at) VALUES (:a, :d, :t)');
            $stmt->execute([':a' => $adminId, ':d' => $deptId, ':t' => $now]);
            $result['added']++;
        }
        foreach ($toRemove as $deptId) {
            $stmt = $pdo->prepare('DELETE FROM admin_departments WHERE admin_id = :a AND department_id = :d');
            $stmt->execute([':a' => $adminId, ':d' => $deptId]);
            $result['removed']++;
        }
    } catch (Throwable $e) {
        $result['error'] = 'ذخیره‌ی حوزه‌ها ناموفق بود: ' . $e->getMessage();
    }
    return $result;
}

/** ساختن حساب مدیر تازه — رمز همان‌جا هش می‌شود و هرگز بازگردانده/نمایش داده نمی‌شود */
function eplakCreateAdminUser(PDO $pdo, string $username, string $password, string $fullName, string $role): array
{
    $out = ['id' => 0, 'error' => ''];
    $username = trim($username);
    $fullName = trim($fullName);
    $role = $role === 'super_admin' ? 'super_admin' : 'admin';

    if ($username === '') {
        $out['error'] = 'نام کاربری نمی‌تواند خالی باشد.';
        return $out;
    }
    if (mb_strlen($username) < 3) {
        $out['error'] = 'نام کاربری باید حداقل ۳ کاراکتر باشد.';
        return $out;
    }
    if (mb_strlen($username) > 60) {
        $out['error'] = 'نام کاربری بیش از حد بلند است (حداکثر ۶۰ کاراکتر).';
        return $out;
    }
    if (!preg_match('/^[A-Za-z0-9._\\-@\\x{0600}-\\x{06FF}]+$/u', $username)) {
        $out['error'] = 'نام کاربری فقط می‌تواند شامل حروف فارسی/انگلیسی، عدد و علامت‌های . _ - @ باشد.';
        return $out;
    }
    if (function_exists('adminUsernameTaken') && adminUsernameTaken($pdo, $username, 0)) {
        $out['error'] = 'این نام کاربری قبلاً استفاده شده است.';
        return $out;
    }
    if (mb_strlen($fullName) > 255) {
        $out['error'] = 'نام و نام خانوادگی بیش از حد بلند است.';
        return $out;
    }
    if (mb_strlen($password) < 8) {
        $out['error'] = 'رمز عبور باید حداقل ۸ کاراکتر باشد.';
        return $out;
    }
    if (!preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $out['error'] = 'رمز عبور باید ترکیبی از حرف و عدد باشد.';
        return $out;
    }

    try {
        $now = function_exists('eplakDbNowString') ? eplakDbNowString($pdo) : date('Y-m-d H:i:s');
        $stmt = $pdo->prepare('INSERT INTO admin_users (username, password_hash, role, full_name, is_active, last_login_at, created_at)
                               VALUES (:u, :p, :r, :f, 1, \'\', :t)');
        $stmt->execute([
            ':u' => $username,
            ':p' => password_hash($password, PASSWORD_DEFAULT),
            ':r' => $role,
            ':f' => $fullName,
            ':t' => $now,
        ]);
        $out['id'] = (int) $pdo->lastInsertId();
    } catch (Throwable $e) {
        /* دیتابیس قدیمی بدون ستون‌های تازه: تلاش با ستون‌های پایه */
        try {
            $stmt = $pdo->prepare('INSERT INTO admin_users (username, password_hash, role) VALUES (:u, :p, :r)');
            $stmt->execute([':u' => $username, ':p' => password_hash($password, PASSWORD_DEFAULT), ':r' => $role]);
            $out['id'] = (int) $pdo->lastInsertId();
            if ($fullName !== '' && $out['id'] > 0) {
                try {
                    $pdo->prepare('UPDATE admin_users SET full_name = :f WHERE id = :id')->execute([':f' => $fullName, ':id' => $out['id']]);
                } catch (Throwable $e2) {
                }
            }
        } catch (Throwable $e3) {
            $out['id'] = 0;
            $out['error'] = 'ساختن حساب ناموفق بود: ' . $e3->getMessage();
        }
    }
    return $out;
}

/** فعال/غیرفعال کردن حساب مدیر؛ خروجی: پیام خطا یا رشته‌ی خالی */
function eplakSetAdminActive(PDO $pdo, int $adminId, bool $active, int $currentAdminId = 0): string
{
    $admin = function_exists('getAdminById') ? getAdminById($pdo, $adminId) : null;
    if (!$admin) {
        return 'حساب مدیر یافت نشد.';
    }
    /* قفل‌نشدنِ پنل: مدیر نمی‌تواند حساب خودش را غیرفعال کند */
    if ($currentAdminId > 0 && $adminId === $currentAdminId && !$active) {
        return 'نمی‌توانید حساب خودتان را غیرفعال کنید.';
    }
    /* و نمی‌تواند آخرین «مدیر کل» فعال را از کار بیندازد */
    if (!$active && (string) ($admin['role'] ?? '') === 'super_admin' && eplakCountActiveSupers($pdo) <= 1) {
        return 'این حساب آخرین مدیر کلِ فعال است؛ غیرفعال کردنش پنل را بی‌مدیر می‌کند.';
    }
    try {
        $stmt = $pdo->prepare('UPDATE admin_users SET is_active = :a WHERE id = :id');
        $stmt->execute([':a' => $active ? 1 : 0, ':id' => $adminId]);
        return '';
    } catch (Throwable $e) {
        return 'تغییر وضعیت حساب ناموفق بود: ' . $e->getMessage();
    }
}

/** تغییر نقشِ یک مدیر (فقط super_admin/admin) با محافظِ قفل‌نشدن */
function eplakSetAdminRole(PDO $pdo, int $adminId, string $role, int $currentAdminId = 0): string
{
    $role = $role === 'super_admin' ? 'super_admin' : 'admin';
    $admin = function_exists('getAdminById') ? getAdminById($pdo, $adminId) : null;
    if (!$admin) {
        return 'حساب مدیر یافت نشد.';
    }
    if ($currentAdminId > 0 && $adminId === $currentAdminId && $role !== 'super_admin') {
        return 'نمی‌توانید دسترسی مدیر کلِ خودتان را بگیرید.';
    }
    if ($role !== 'super_admin' && (string) ($admin['role'] ?? '') === 'super_admin' && eplakCountActiveSupers($pdo) <= 1) {
        return 'این حساب آخرین مدیر کلِ فعال است.';
    }
    try {
        $pdo->prepare('UPDATE admin_users SET role = :r WHERE id = :id')->execute([':r' => $role, ':id' => $adminId]);
        return '';
    } catch (Throwable $e) {
        return 'تغییر نقش ناموفق بود: ' . $e->getMessage();
    }
}

/** حذف حساب مدیر؛ خروجی: پیام خطا یا رشته‌ی خالی */
function eplakDeleteAdminUser(PDO $pdo, int $adminId, int $currentAdminId = 0): string
{
    $admin = function_exists('getAdminById') ? getAdminById($pdo, $adminId) : null;
    if (!$admin) {
        return 'حساب مدیر یافت نشد.';
    }
    if ($currentAdminId > 0 && $adminId === $currentAdminId) {
        return 'نمی‌توانید حساب خودتان را حذف کنید.';
    }
    if ((string) ($admin['role'] ?? '') === 'super_admin' && eplakCountActiveSupers($pdo) <= 1) {
        return 'این حساب آخرین مدیر کلِ فعال است؛ حذفش پنل را بی‌مدیر می‌کند.';
    }
    try {
        $pdo->prepare('DELETE FROM admin_departments WHERE admin_id = :id')->execute([':id' => $adminId]);
    } catch (Throwable $e) {
        /* جدول admin_departments نباشد — حذف حساب ادامه پیدا می‌کند */
    }
    try {
        $pdo->prepare('DELETE FROM admin_users WHERE id = :id')->execute([':id' => $adminId]);
        return '';
    } catch (Throwable $e) {
        return 'حذف حساب ناموفق بود: ' . $e->getMessage();
    }
}

/** شمار «مدیران کلِ فعال» — برای جلوگیری از بی‌مدیر ماندن پنل */
function eplakCountActiveSupers(PDO $pdo): int
{
    try {
        return (int) $pdo->query("SELECT COUNT(*) FROM admin_users WHERE role = 'super_admin' AND is_active = 1")->fetchColumn();
    } catch (Throwable $e) {
        /* ستون is_active نباشد */
        try {
            return (int) $pdo->query("SELECT COUNT(*) FROM admin_users WHERE role = 'super_admin'")->fetchColumn();
        } catch (Throwable $e2) {
            return 0;
        }
    }
}

/**
 * تعداد پیام‌های یک حوزه (گزارش + تیکت) — برای نمایش کنار نام هر مدیر.
 * همان «کلیدِ حوزه» استفاده می‌شود که دامنه‌ی دسترسی می‌سازد، پس این عدد
 * دقیقاً همان چیزی است که آن مدیر در فهرست‌هایش می‌بیند.
 */
function eplakDepartmentMessageCounts(PDO $pdo, array $topLevelIds): array
{
    $out = ['reports' => 0, 'tickets' => 0, 'total' => 0];
    $ids = [];
    foreach ($topLevelIds as $id) {
        $id = (int) $id;
        if ($id > 0) {
            $ids[$id] = true;
        }
    }
    $ids = array_keys($ids);
    if (!$ids || !function_exists('eplakAdminScopeNames') || !function_exists('eplakScopeSql')) {
        return $out;
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    try {
        $stmt = $pdo->prepare("SELECT id, name FROM departments WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $depts = $stmt->fetchAll() ?: [];
    } catch (Throwable $e) {
        return $out;
    }
    if (!$depts) {
        return $out;
    }

    $names = eplakAdminScopeNames($pdo, $depts);
    $fakeScope = ['is_super' => false, 'names_key' => $names['key'] ?? []];
    foreach (['reports', 'tickets'] as $table) {
        $scopeSql = eplakScopeSql($fakeScope, $table);
        try {
            $q = $pdo->prepare('SELECT COUNT(*) FROM ' . $table . ' WHERE 1=1' . $scopeSql['sql']);
            $q->execute($scopeSql['params']);
            $out[$table] = (int) $q->fetchColumn();
        } catch (Throwable $e) {
            /* جدول نباشد ⇒ همان صفر */
        }
    }
    $out['total'] = $out['reports'] + $out['tickets'];
    return $out;
}
