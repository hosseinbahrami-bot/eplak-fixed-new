<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/includes/functions.php';

/* دسترسی: news — مدیرِ حوزه/معاونت به این صفحه نمی‌رسد (admin/includes/acl.php) */
eplakRequirePermission('news');


$message = '';
$messageType = 'danger';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    eplakRequireCsrf();
    $title = trim($_POST['title'] ?? '');
    $body  = trim($_POST['body'] ?? '');

    if ($title === '' || $body === '') {
        $message = '⚠️ عنوان و متن اصلی الزامی هستند.';
    } else {
        /* اگر تصویری از سیستم آپلود شده باشد، جای نشانی تصویر را می‌گیرد
           (پوشه‌ی uploads/news — بدون نیاز به آپلود دستی روی هاست) */
        $imageUrl = trim($_POST['image_url'] ?? '');
        if (!empty($_FILES['image_file']['name'])) {
            $upload = eplakMediaStoreSimpleFile($_FILES['image_file'], 'news');
            if ($upload['ok']) {
                $imageUrl = $upload['path'];
            } else {
                $message = '⚠️ ' . $upload['error'];
            }
        }

        if ($message === '') {
            /* ذخیره با «ستون‌های موجودِ» دیتابیس؛ گزارشِ چه‌چیزی سازگار شد
               برمی‌گردد تا صادقانه به مدیر بگوییم (مثلاً ایموجی حذف شد) */
            $saveReport = null;
            try {
                $newId = createNews($pdo, [
                    'type'      => ($_POST['type'] ?? 'news') === 'tip' ? 'tip' : 'news',
                    'title'     => $title,
                    'summary'   => trim($_POST['summary'] ?? '') ?: null,
                    'body'      => $body,
                    'icon'      => trim($_POST['icon'] ?? '') ?: null,
                    'badge'     => trim($_POST['badge'] ?? ''),
                    'image_url' => $imageUrl !== '' ? $imageUrl : null,
                    'published' => isset($_POST['published']) ? 1 : 0,
                    'sort_order' => (int)($_POST['sort_order'] ?? 0),
                ], $saveReport);
            } catch (Throwable $e) {
                $newId = 0;
                $saveReport = ['ok' => false, 'error' => $e->getMessage()];
            }

            if ($newId > 0 && !empty($saveReport['ok'])) {
                $query = ['success' => 1];
                if (!empty($saveReport['degraded'])) {
                    $query['degraded'] = implode(',', $saveReport['degraded']);
                }
                eplakRedirect('news.php?' . http_build_query($query));
            }

            $message = '⚠️ ذخیره‌ی مطلب ناموفق بود: '
                . (string) ($saveReport['error'] ?? 'خطای نامشخص')
                . ' — اگر دیتابیس قدیمی است، در صفحه‌ی «اخبار و دانستنی‌ها» دکمه‌ی'
                . ' «تعمیر خودکار جدول اخبار» را بزنید و دوباره تلاش کنید.';
        }
    }
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>افزودن مطلب جدید</title>
  <link rel="stylesheet" href="assets/style.css?v=10">
  <script src="assets/theme.js?v=7"></script>
  <script src="assets/persian-digits.js?v=6"></script>
  <link rel="stylesheet" href="assets/fontawesome/css/all.min.css">
</head>
<body>
  <div class="layout">
    <aside class="sidebar">
      <div class="brand">
        <img class="logo-light" src="assets/img/logo.png" alt="ای‌پلاک">
        <img class="logo-dark" src="assets/img/logo-light.png" alt="ای‌پلاک">
      </div>
      <nav data-testid="admin-sidebar">
<?php /* منوی آگاه از دسترسی — admin/includes/acl.php */ ?>
<?= eplakAdminSidebar('news') ?>      </nav>
    </aside>
    <main class="main">
      <header class="topbar">
        <div class="topbar-left">
          <h1>
            <i class="fas fa-plus-circle" style="color: var(--primary-500); margin-left: 12px;"></i>
            افزودن مطلب جدید
          </h1>
          <p>پس از ذخیره، مطلب بلافاصله در اپلیکیشن نمایش داده می‌شود</p>
        </div>
        <div class="topbar-right">
          <a href="news.php" class="btn btn-secondary">
            <i class="fas fa-arrow-right"></i> بازگشت
          </a>
        </div>
      </header>

      <?php if ($message): ?>
        <div class="alert alert-<?= htmlspecialchars($messageType) ?>" style="margin: 0 24px 16px;">
          <?= htmlspecialchars($message) ?>
        </div>
      <?php endif; ?>

      <section class="panel" style="margin: 0 24px 24px;">
        <h2><i class="fas fa-pen"></i> اطلاعات مطلب</h2>
        <form method="post" enctype="multipart/form-data" style="display:grid; gap:18px; margin-top:16px;">
<?= eplakCsrfField() ?>

          <div class="form-group">
            <label for="type">بخش</label>
            <select class="filter-select" id="type" name="type" style="width:100%;">
              <option value="news">📰 اخبار و اطلاعات</option>
              <option value="tip">🏛️ دانستنی‌های ورامین</option>
            </select>
          </div>

          <div class="form-group">
            <label for="title">عنوان <span style="color:var(--danger);">*</span></label>
            <input class="search-input" style="width:100%;" type="text" id="title" name="title" required
                   placeholder="مثال: آغاز عملیات روکش آسفالت معابر اصلی">
          </div>

          <div class="form-group">
            <label for="summary">خلاصه (در فهرست نمایش داده می‌شود)</label>
            <input class="search-input" style="width:100%;" type="text" id="summary" name="summary"
                   placeholder="یک جمله کوتاه درباره این مطلب">
          </div>

          <div class="form-group">
            <label for="body">متن کامل <span style="color:var(--danger);">*</span></label>
            <textarea id="body" name="body" required rows="8"
                      style="width:100%; padding:12px 14px; border:2px solid var(--dark-200); border-radius:12px;
                             font-family: var(--font-family); font-size:14px; line-height:1.9; resize:vertical;"
                      placeholder="متن کامل خبر یا دانستنی را اینجا بنویسید"></textarea>
          </div>

          <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:18px;">
            <div class="form-group">
              <label for="icon">آیکون (ایموجی)</label>
              <input class="search-input" style="width:100%;" type="text" id="icon" name="icon"
                     placeholder="📰" maxlength="8">
            </div>
            <div class="form-group">
              <label for="sort_order">ترتیب نمایش</label>
              <input class="search-input" style="width:100%;" type="number" id="sort_order" name="sort_order" value="0">
            </div>
          </div>

          <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:18px;">
            <div class="form-group">
              <label for="badge">نشان/زیرعنوان (اختیاری)</label>
              <input class="search-input" style="width:100%;" type="text" id="badge" name="badge" maxlength="120"
                     placeholder="مثال: ۷۲۲ ه.ق · دوره ایلخانی">
              <p class="help-text">برای دانستنی‌ها روی کارت و بالای تصویر جزئیات نمایش داده می‌شود.</p>
            </div>
            <div class="form-group">
              <label for="image_file">تصویر شاخص (اختیاری)</label>
              <input class="search-input" style="width:100%;" type="file" id="image_file" name="image_file"
                     accept="image/*">
              <p class="help-text">حداکثر ۱۲ مگابایت — تصویر روی کارت خبر/دانستنی نمایش داده می‌شود
                 (در اپ، هم روی کارت فهرست و هم بالای صفحه‌ی جزئیات).</p>
              <div id="imagePreviewBox" style="margin-top:10px; display:none;">
                <img id="imagePreview" alt="پیش‌نمایش تصویر مطلب"
                     style="max-width:240px; max-height:150px; border-radius:12px; border:2px solid var(--dark-200); object-fit:cover;">
                <p class="help-text" id="imagePreviewNote"></p>
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="image_url">یا نشانی تصویر (اختیاری)</label>
            <input class="search-input" style="width:100%;" type="text" id="image_url" name="image_url"
                   placeholder="https://example.com/image.jpg — یا assets/img/varamin-mosque.jpg" dir="ltr" style="text-align:left;">
            <p class="help-text">اگر فایلی از سیستم آپلود کنید، همین فیلد نادیده گرفته می‌شود.</p>
          </div>

          <div class="form-group">
            <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
              <input type="checkbox" name="published" id="published" checked style="width:18px; height:18px;">
              <span>بلافاصله در اپلیکیشن منتشر شود</span>
            </label>
          </div>

          <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button type="submit" class="btn btn-primary">
              <i class="fas fa-save"></i> ذخیره و انتشار
            </button>
            <a href="news.php" class="btn btn-secondary">انصراف</a>
          </div>
        </form>
      </section>
    </main>
  </div>

<script>
/* پیش‌نمایش زنده‌ی تصویر مطلب — همان چیزی که در اپ روی کارت خبر/دانستنی می‌آید */
(function () {
  var file = document.getElementById('image_file');
  var url  = document.getElementById('image_url');
  var box  = document.getElementById('imagePreviewBox');
  var img  = document.getElementById('imagePreview');
  var note = document.getElementById('imagePreviewNote');
  if (!box || !img) return;

  function resolve(value) {
    var v = String(value || '').trim();
    if (v === '') return '';
    if (/^(https?:)?\/\//i.test(v) || v.indexOf('data:') === 0) return v;
    /* مسیرهای نسبیِ هاست (uploads/news/…) از پوشه‌ی admin با ../ درست می‌شوند */
    return '../' + v.replace(/^\/+/, '');
  }
  function show(src, text) {
    if (!src) { box.style.display = 'none'; img.removeAttribute('src'); if (note) note.textContent = ''; return; }
    box.style.display = 'block';
    img.src = src;
    if (note) note.textContent = text || '';
  }
  if (file) file.addEventListener('change', function () {
    var f = file.files && file.files[0];
    if (!f) { show(resolve(url ? url.value : ''), ''); return; }
    if (f.size > 12 * 1024 * 1024) { show('', ''); if (note) note.textContent = '⚠️ حجم تصویر بیش از ۱۲ مگابایت است'; box.style.display = 'block'; return; }
    show(URL.createObjectURL(f), 'پیش‌نمایش «' + f.name + '» — همین تصویر در اپ روی کارت مطلب نمایش داده می‌شود.');
  });
  if (url) url.addEventListener('input', function () {
    if (file && file.files && file.files.length) return;
    show(resolve(url.value), url.value.trim() ? 'پیش‌نمایش نشانی تصویر' : '');
  });
  if (url && url.value.trim()) show(resolve(url.value), 'تصویر فعلی مطلب');
})();
</script>
</body>
</html>
