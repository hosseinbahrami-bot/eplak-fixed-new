<?php
/* admin/settings.php — تنظیمات پنل مدیریت
   • تغییر نام کاربری و رمز عبور مدیر
   • وضعیت و آزمایش «اعلان پس‌زمینه» (Web Push) برای رسیدن اعلان در حالت قفل/بسته بودن برنامه
   • وضعیت فنی سرور (ماژول‌های لازم، سقف حجم آپلود، مسیر فایل‌های پیوست)
*/
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/includes/functions.php';

/* دسترسی: settings — مدیرِ حوزه/معاونت به این صفحه نمی‌رسد (admin/includes/acl.php) */
eplakRequirePermission('settings');

require_once __DIR__ . '/../shared/fcm.php';
require_once __DIR__ . '/../shared/app_heartbeat.php';
require_once __DIR__ . '/../shared/notify_events.php';
/* پیامکِ «کد تایید»: تنها ارائه‌دهنده = ملی پیامک (کلید API + ترجمه‌ی کدهای پاسخ) */
require_once __DIR__ . '/../shared/payamak.php';

$adminId  = (int) ($_SESSION['admin_id'] ?? 0);
$admin    = getAdminById($pdo, $adminId);
$message  = '';
$messageType = 'danger';
$pushTestResult = null;
$smsTestResult = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    eplakRequireCsrf();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'update_username') {
        $error = updateAdminUsername($pdo, $adminId, (string) ($_POST['username'] ?? ''));
        if ($error === '') {
            $_SESSION['admin_username'] = trim((string) ($_POST['username'] ?? ''));
            $message = '✅ نام کاربری با موفقیت تغییر کرد. از این پس با نام کاربری جدید وارد شوید.';
            $messageType = 'success';
        } else {
            $message = '⚠️ ' . $error;
        }
    } elseif ($action === 'update_password') {
        $error = updateAdminPassword(
            $pdo,
            $adminId,
            (string) ($_POST['current_password'] ?? ''),
            (string) ($_POST['new_password'] ?? ''),
            (string) ($_POST['confirm_password'] ?? '')
        );
        if ($error === '') {
            /* شناسه‌ی نشست پس از تغییر رمز نو می‌شود (جلوگیری از تثبیت نشست) */
            session_regenerate_id(true);
            $message = '✅ رمز عبور با موفقیت تغییر کرد. از این پس با رمز جدید وارد می‌شوید.';
            $messageType = 'success';
        } else {
            $message = '⚠️ ' . $error;
        }
    } elseif ($action === 'test_push') {
        /* ارقام فارسی/عربی و فاصله‌ها هم پذیرفته می‌شوند */
        $phone = trim((string) ($_POST['test_phone'] ?? ''));
        $phone = str_replace(
            ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩',' ','-','(',')'],
            ['0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','','','',''],
            $phone
        );
        $subs   = eplakPushSubscriptions($pdo, [$phone]);
        if ($phone === '') {
            $message = '⚠️ شماره موبایل را وارد کنید.';
        } elseif (!$subs) {
            $message = '⚠️ برای شماره‌ی ' . htmlspecialchars($phone) . ' هیچ دستگاهی ثبت نشده است. '
                     . 'کاربر باید یک‌بار سایت را در مرورگر کروم گوشی باز کند، از منو «افزودن به صفحه اصلی» را بزند و اجازه‌ی اعلان را تأیید کند. '
                     . '(داخل اپ اندروید، سیستم‌عامل به WebView اجازه‌ی اعلان پس‌زمینه نمی‌دهد.)';
        } else {
            $pushTestResult = eplakWebPushSend(
                $pdo,
                $subs,
                'اعلان آزمایشی — ای‌پلاک',
                'اگر این پیام را روی گوشی می‌بینید، اعلان پس‌زمینه درست کار می‌کند.',
                ['url' => 'index.html', 'tag' => 'eplak-test-' . time()]
            );
            $message = $pushTestResult['sent'] > 0
                ? '✅ اعلان آزمایشی برای ' . (int) $pushTestResult['sent'] . ' دستگاه ارسال شد.'
                : '⚠️ ارسال آزمایشی ناموفق بود. جزئیات خطا در پایین همین صفحه آمده است.';
            $messageType = $pushTestResult['sent'] > 0 ? 'success' : 'danger';
        }
    } elseif ($action === 'regen_vapid') {
        eplakSetAppSetting($pdo, 'vapid_pem', '');
        eplakSetAppSetting($pdo, 'vapid_public', '');
        $vapid = eplakVapidKeys($pdo);
        $message = $vapid['ready']
            ? '✅ کلیدهای تازه‌ی اعلان ساخته شد. کاربران باید یک‌بار اپلیکیشن را باز کنند تا اشتراک‌شان دوباره ثبت شود.'
            : '⚠️ ساخت کلید ناموفق بود: ' . $vapid['error'];
        $messageType = $vapid['ready'] ? 'success' : 'danger';
    } elseif ($action === 'save_fcm') {
        /* کلید سرویس فایربیس (JSON) — از Firebase Console → Project settings →
           Service accounts → Generate new private key */
        $raw = trim((string) ($_POST['fcm_service_account'] ?? ''));
        /* راه ساده‌تر (به‌خصوص روی گوشی): انتخاب خودِ فایل JSON به‌جای کپی/چسباندن متن.
           اگر فایلی انتخاب شده باشد، همان مبنا است. */
        $upload = $_FILES['fcm_service_account_file'] ?? null;
        $uploadError = '';
        if (is_array($upload) && (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            if ((int) $upload['error'] !== UPLOAD_ERR_OK) {
                $uploadError = 'آپلود فایل کلید ناموفق بود (کد ' . (int) $upload['error'] . ').';
            } elseif ((int) ($upload['size'] ?? 0) > 64 * 1024 || (int) ($upload['size'] ?? 0) <= 0) {
                $uploadError = 'اندازه‌ی فایل کلید غیرعادی است (فایل کلید سرویس چند کیلوبایت است).';
            } elseif (!is_uploaded_file((string) $upload['tmp_name'])) {
                $uploadError = 'فایل کلید دریافت نشد.';
            } else {
                $raw = trim((string) file_get_contents((string) $upload['tmp_name']));
                /* BOM احتمالی ویرایشگرهای ویندوز */
                $raw = ltrim($raw, "\xEF\xBB\xBF");
            }
        }
        if ($uploadError !== '') {
            $message = '⚠️ ' . $uploadError;
            $messageType = 'danger';
        } elseif ($raw === '') {
            eplakSetAppSetting($pdo, 'fcm_service_account', '');
            $message = '✅ کلید سرویس فایربیس پاک شد. اعلان اپ اندروید غیرفعال می‌شود.';
            $messageType = 'success';
        } else {
            $decoded = json_decode($raw, true);
            if (is_array($decoded) && (isset($decoded['project_info']) || (isset($decoded['type']) && $decoded['type'] !== 'service_account'))) {
                /* اشتباه رایج: به‌جای کلید سرویس، فایل google-services.json (مخصوص داخل APK) داده می‌شود */
                $message = '⚠️ این فایل «کلید سرویس» نیست (به نظر google-services.json یا فایل دیگری است). کلید سرویس از Firebase Console → Project settings → Service accounts → Generate new private key دانلود می‌شود و فیلد "type":"service_account" دارد.';
                $messageType = 'danger';
            } elseif (!is_array($decoded) || empty($decoded['project_id']) || empty($decoded['client_email']) || empty($decoded['private_key'])) {
                $message = '⚠️ محتوای کلید سرویس نامعتبر است. کل فایل JSON را (از { تا }) کپی کنید یا خودِ فایل را انتخاب کنید.';
                $messageType = 'danger';
            } else {
                eplakSetAppSetting($pdo, 'fcm_service_account', (string) json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
                /* توکن دسترسی قبلی باطل می‌شود تا با کلید تازه ساخته شود */
                eplakSetAppSetting($pdo, 'fcm_access_token', '');
                eplakSetAppSetting($pdo, 'fcm_access_token_exp', '0');

                $cfg = eplakFcmConfig($pdo);
                $auth = eplakFcmAccessToken($pdo, true);
                if ($cfg['ready'] && $auth['token'] !== '' && $cfg['project_match'] === false) {
                    /* کلید سالم است ولی به APK این مخزن نمی‌رسد — همین‌جا، نه بعد از اولین ارسالِ ناموفق */
                    $message = '⛔ کلید ذخیره شد و گوگل آن را می‌پذیرد، ولی ' . htmlspecialchars((string) $cfg['warning']);
                    $messageType = 'danger';
                } elseif ($cfg['ready'] && $auth['token'] !== '') {
                    $message = '✅ کلید سرویس فایربیس ذخیره شد و اتصال به گوگل برقرار است (پروژه: ' . htmlspecialchars($cfg['project_id']) . ' — همان پروژه‌ی اپ اندروید).';
                    $messageType = 'success';
                } else {
                    $message = '⚠️ کلید ذخیره شد ولی اتصال به گوگل برقرار نشد: ' . htmlspecialchars($auth['error'] !== '' ? $auth['error'] : $cfg['error']);
                    $messageType = 'danger';
                }
            }
        }
    } elseif ($action === 'diagnose_fcm') {
        /* عیب‌یابی زنجیره‌ی اعلان (کلید ← گوگل ← سرویس ارسال ← گوشی‌ها) */
        $fcmDiag = eplakFcmDiagnose($pdo);
        $allOk = true;
        foreach ($fcmDiag as $step) {
            $allOk = $allOk && $step['ok'];
        }
        $message = $allOk
            ? '✅ همه‌ی گام‌های زنجیره‌ی اعلان سالم است.'
            : '⚠️ یکی از گام‌های زنجیره‌ی اعلان مشکل دارد؛ جزئیات را در بخش «بررسی زنجیره‌ی اعلان» ببینید.';
        $messageType = $allOk ? 'success' : 'danger';
    } elseif ($action === 'test_fcm') {
        /* همان قالبی که گوشی با آن ثبت می‌شود: 09xxxxxxxxx (رقم فارسی، فاصله و +98 هم درست می‌شود) */
        $phone = eplakNotifyNormalizePhone((string) ($_POST['fcm_test_phone'] ?? ''));
        if ($phone === '') {
            $message = '⚠️ شماره موبایل را وارد کنید.';
            $messageType = 'danger';
        } else {
            $tokens = eplakFcmTokens($pdo, [$phone]);
            $title  = 'اعلان آزمایشی — ای‌پلاک';
            $result = eplakFcmSend(
                $pdo,
                $tokens,
                $title,
                'این پیام از پنل مدیریت برای بررسی اعلان اپ اندروید فرستاده شده است.',
                ['url' => 'index.html', 'tag' => 'eplak-fcm-test-' . time()]
            );
            $sum = eplakFcmSummarize($result, count($tokens));
            eplakPushLogAdd($pdo, [
                'user_phone' => $phone, 'kind' => 'admin_test', 'title' => $title, 'channel' => 'fcm',
                'devices' => $sum['devices'], 'sent' => $sum['sent'], 'failed' => $sum['failed'],
                'outcome' => $sum['outcome'], 'error' => $sum['error'],
            ]);
            if ($sum['outcome'] === 'sent') {
                $message = '✅ اعلان آزمایشی فایربیس برای ' . (int) $sum['sent'] . ' دستگاه از ' . count($tokens) . ' دستگاه ارسال شد. اگر روی گوشی نیامد، اجازه‌ی اعلان و «صرفه‌جویی باتری» گوشی را بررسی کنید.';
                $messageType = 'success';
            } elseif ($sum['outcome'] === 'no_device') {
                $message = '⚠️ برای شماره‌ی ' . $phone . ' هیچ دستگاهی از اپ اندروید ثبت نشده است. اپ (آخرین نسخه) باید یک‌بار با این شماره باز شود و ورود انجام شود تا توکن دستگاه ثبت گردد.';
                $messageType = 'danger';
            } else {
                $message = '⚠️ ارسال ناموفق بود: ' . trim($sum['error']) . ($sum['hint'] !== '' ? ' — ' . $sum['hint'] : '');
                $messageType = 'danger';
            }
        }
    } elseif ($action === 'repair_schema') {
        $report = eplakRunSchemaSync($pdo, true);

        /* ساختار «جدول اعلان‌ها» هم اجباری ترمیم می‌شود: ستون send_id، کلید
           خارجیِ مزاحمِ user_phone و نویسه‌گان utf8mb4 — ریشه‌ی «اعلان در اپ
           نمی‌آید» و «Unknown column 'send_id'» در پنل. این ترمیم مستقل از
           نسخه‌ی اسکیما است، پس حتی وقتی درِ همگام‌سازی بسته است انجام می‌شود. */
        $notif = function_exists('eplakNotificationsSchema') ? eplakNotificationsSchema($pdo, true) : [];

        /* ساختار «جدول اخبار و دانستنی‌ها» هم ترمیم می‌شود: اگر جدول news در
           دیتابیس نباشد ساخته می‌شود، ستون‌های نبوده (badge/image_url/…) اضافه
           می‌شوند و جدول به utf8mb4 می‌رود تا ایموجیِ آیکون‌ها ذخیره شود.
           ریشه‌ی «اخبار و اطلاعیه‌ها در اپ و پنل خالی است» همین است. */
        $news = function_exists('eplakNewsSchema') ? eplakNewsSchema($pdo, true) : [];
        $newsSeeded = 0;
        if (function_exists('eplakSeedDefaultNews')) {
            eplakSetAppSetting($pdo, 'news_seeded', '');
            $newsSeedReport = null;
            $newsSeeded = eplakSeedDefaultNews($pdo, $newsSeedReport);
        }

        $problems = array_merge(
            array_slice((array) ($report['failed'] ?? []), 0, 3),
            array_slice((array) ($notif['failed'] ?? []), 0, 3),
            array_slice((array) ($news['failed'] ?? []), 0, 3)
        );
        $done = array_merge(
            (array) ($report['added'] ?? []),
            (array) ($notif['repaired'] ?? []),
            (array) ($news['repaired'] ?? [])
        );
        if ($newsSeeded > 0) {
            $done[] = 'درج ' . $newsSeeded . ' مطلب پیش‌فرض در جدول اخبار';
        }

        if ($problems) {
            $message = '⚠️ برخی ترمیم‌ها انجام نشد: ' . implode(' | ', $problems)
                . ' — اعلان‌ها همچنان در «حالت سازگار» ذخیره و نمایش داده می‌شوند؛'
                . ' برای ترمیم قطعی، backend/fix-notifications-db.sql را یک‌بار در phpMyAdmin اجرا کنید.';
            $messageType = 'danger';
        } elseif ($done) {
            $message = '✅ ساختار دیتابیس ترمیم شد: ' . implode('، ', array_slice($done, 0, 6));
            $messageType = 'success';
        } else {
            $message = '✅ ساختار دیتابیس کامل است؛ چیزی برای ترمیم نبود.';
            $messageType = 'success';
        }
    } elseif ($action === 'save_push_subject') {
        $subject = trim((string) ($_POST['vapid_subject'] ?? ''));
        if ($subject !== '' && strpos($subject, 'mailto:') !== 0 && strpos($subject, 'https://') !== 0) {
            $subject = 'mailto:' . $subject;
        }
        eplakSetAppSetting($pdo, 'vapid_subject', $subject);
        $message = '✅ نشانی تماس اعلان‌ها ذخیره شد.';
        $messageType = 'success';
    } elseif ($action === 'save_app_version') {
        /* ── «نسخه‌ی اپ و آپدیت اجباری» ────────────────────────────────────
           تنظیمات در shared/app_version.json ذخیره می‌شوند (نه دیتابیس) تا
           api/ping.php — که اپ هنگام باز شدن صدا می‌زند — بدونِ لمسِ دیتابیس
           آن‌ها را بخواند و همچنان «زنده» بماند. این فایل در گیت و در بسته‌ی
           آپدیت نیست (مثلِ shared/config.php) تا آپدیتِ هاست تنظیمِ مدیر را
           بازنویسی نکند. کدِ نسخه یک عددِ صحیحِ نامنفی است (همان versionCodeِ
           اندروید/iOS) و لینکِ دانلود فقط اگر http(s) باشد مؤثر است. */
        $minCode = max(0, (int) ($_POST['min_app_version_code'] ?? 0));
        $latestCode = max(0, (int) ($_POST['latest_app_version_code'] ?? 0));
        $latestName = trim((string) ($_POST['latest_app_version_name'] ?? ''));
        $updateUrl = trim((string) ($_POST['app_update_url'] ?? ''));
        $updateMsg = trim((string) ($_POST['app_update_message'] ?? ''));
        $versionData = [
            'min_version_code'    => $minCode,
            'latest_version_code' => $latestCode,
            'latest_version_name' => $latestName,
            'update_url'          => $updateUrl,
            'message'             => $updateMsg,
        ];
        $versionFile = __DIR__ . '/../shared/app_version.json';
        $written = @file_put_contents(
            $versionFile,
            json_encode($versionData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "\n",
            LOCK_EX
        );
        if ($written === false) {
            $message = '⚠️ ذخیره نشد: پوشه‌ی shared نوشتنی نیست. اجازه‌ی پوشه را 775 کنید و دوباره تلاش کنید.';
            $messageType = 'danger';
        } else {
            $message = '✅ تنظیماتِ نسخه‌ی اپ ذخیره شد.';
            $messageType = 'success';
        }
    } elseif ($action === 'test_sms') {
        /* ── «ارسال پیامک آزمایشی» ───────────────────────────────────────────
           چرا این‌جا؟ ریشه‌ی بیشترِ «کد تایید نمی‌آید»ها تنظیمِ پیامک است و تا
           امروز راهی نبود که مدیر بدون ورودِ یک کاربرِ واقعی بفهمد کلید درست است
           یا نه. این دکمه دقیقاً همان مسیری را می‌رود که «کد تایید» می‌رود
           (shared/payamak.php → eplakPayamakSendCode) و پاسخِ ملی پیامک را به
           فارسی ترجمه می‌کند (مثلاً -110 = «باید کلید API بفرستید»، -4 = «شناسه‌ی
           متن تأیید نشده»).
           دسترسی: فقط مدیرِ کل (مجوز settings، بالای همین فایل) + توکن CSRF
           (eplakRequireCsrf در ابتدای بلوک POST) — پس بیرون از پنل قابلِ صدا
           زدن نیست و اعتبارِ پیامکِ سایت هدر نمی‌رود. */
        $smsCfg = eplakConfigArray();
        $phone = eplakNotifyNormalizePhone((string) ($_POST['sms_test_phone'] ?? ''));
        if (!preg_match('/^09\d{9}$/', $phone)) {
            $message = '⚠️ شماره‌ی موبایل معتبر نیست؛ باید با 09 شروع شود و ۱۱ رقم باشد (مثلاً 09121234567).';
            $messageType = 'danger';
        } elseif (!function_exists('curl_init')) {
            $message = '⚠️ ماژول cURL در PHP این سرور فعال نیست؛ بدون آن هیچ پیامکی ارسال نمی‌شود.';
            $messageType = 'danger';
        } elseif (!eplakPayamakReady($smsCfg)) {
            $message = '⚠️ پنل ملی پیامک آماده نیست: «نام کاربری» و «کلید API» هر دو در shared/config.php لازم‌اند'
                . ' (کلیدهای payamak_username و payamak_api_key). کلید API از «پنل ملی پیامک ← توسعه‌دهندگان ←'
                . ' تنظیمات وب‌سرویس ← API Key» کپی می‌شود؛ از setup.php هم می‌توانید وارد کنید.';
            $messageType = 'danger';
        } else {
            /* ضدِ هدر رفتنِ اعتبارِ پیامک: بین دو آزمایش دستِ‌کم ۳۰ ثانیه فاصله */
            $nowTs = time();
            $lastAt = (int) eplakAppSetting($pdo, 'sms_test_last_at', '0');
            $wait = 30 - ($nowTs - $lastAt);
            if ($lastAt > 0 && $wait > 0) {
                $message = '⚠️ برای هدر نرفتنِ اعتبارِ پیامک، ' . $wait . ' ثانیه دیگر دوباره آزمایش کنید.';
                $messageType = 'danger';
            } else {
                eplakSetAppSetting($pdo, 'sms_test_last_at', (string) $nowTs);
                /* متنِ الگوی تأییدشده همان «کدِ چهاررقمی» است؛ پس عددِ تصادفی
                   می‌فرستیم تا مطابقتِ متن با الگو (خطای -5) هم آزمایش شود. */
                $smsTestCode = (string) random_int(1000, 9999);
                $sms = eplakPayamakSendCode($smsCfg, $phone, $smsTestCode);
                error_log('[eplak-sms-test] admin_id=' . $adminId . ' ' . $sms['log']);
                $smsTestResult = $sms;
                $smsTestResult['phone'] = $phone;
                $smsTestResult['sent_code'] = $smsTestCode;
                if ($sms['ok']) {
                    $message = '✅ پیامک آزمایشی برای ' . $phone . ' ارسال شد'
                        . ($sms['rec_id'] !== '' ? ' (شناسه‌ی رکورد: ' . $sms['rec_id'] . ')' : '')
                        . ' — کدِ داخل پیامک باید ' . $smsTestCode . ' باشد. اگر تا یک دقیقه نرسید،'
                        . ' «وضعیت ارسال» را در پنل ملی پیامک ببینید (کد ۳۵ = لیست سیاه مخابرات).';
                    $messageType = 'success';
                } else {
                    $message = '⚠️ ارسال ناموفق بود: ' . $sms['fa']
                        . ($sms['hint'] !== '' ? ' — ' . $sms['hint'] : '');
                    $messageType = 'danger';
                }
            }
        }
    }

    $admin = getAdminById($pdo, $adminId);
}

$schemaReport  = eplakSchemaSyncReport();
$schemaVersion = (string) eplakAppSetting($pdo, 'schema_version', '');
/* وضعیت «جدول اعلان‌ها» برای نمایش در همین صفحه (ارزان: یک نشانگر + یک کاوش ستون) */
$notifSchema = function_exists('eplakNotificationsSchema') ? eplakNotificationsSchema($pdo) : null;
$newsSchema  = function_exists('eplakNewsSchema') ? eplakNewsSchema($pdo) : null;

$vapid        = eplakVapidKeys($pdo, false);
$vapidReady   = $vapid['ready'];
$pushPossible = eplakPushEnabled();
$pushStats    = getPushStats($pdo);
$pushErrors   = getPushLastErrors($pdo, 5);
$vapidSubject = (string) eplakAppSetting($pdo, 'vapid_subject', '');

/* ── تنظیماتِ «نسخه‌ی اپ و آپدیت اجباری» (shared/app_version.json) ─────────
   پیش‌فرض‌ها دقیقاً همان‌هایی هستند که api/ping.php برمی‌گرداند (آخرین نسخه‌ی
   منتشرشده: ۲.۱۰ / کدِ ۱۲) تا این‌جا هم همان دیده شود که اپ می‌بیند. */
$appVerMin        = 12;
$appVerLatestCode = 12;
$appVerLatestName = '2.10';
$appVerUrl        = '';
$appVerMessage    = '';
try {
    $appVerFile = __DIR__ . '/../shared/app_version.json';
    if (is_file($appVerFile)) {
        $appVerDecoded = json_decode((string) file_get_contents($appVerFile), true);
        if (is_array($appVerDecoded)) {
            $appVerMin        = max(0, (int) ($appVerDecoded['min_version_code'] ?? 0));
            $appVerLatestCode = max(0, (int) ($appVerDecoded['latest_version_code'] ?? 0));
            $appVerLatestName = trim((string) ($appVerDecoded['latest_version_name'] ?? ''));
            $appVerUrl        = trim((string) ($appVerDecoded['update_url'] ?? ''));
            $appVerMessage    = trim((string) ($appVerDecoded['message'] ?? ''));
        }
    }
} catch (Throwable $e) {
    /* خرابیِ فایل نباید صفحه‌ی تنظیمات را خراب کند؛ پیش‌فرض می‌ماند */
}

/* ── وضعیتِ پیامک (ملی پیامک) برای بخشِ «ارسال پیامک آزمایشی» ───────────────
   مقدارِ کلید هرگز نمایش داده نمی‌شود؛ فقط «هست/نیست» و «از کدام تنظیم خوانده
   شده». ترتیبِ خواندن یک‌جا در shared/payamak.php است:
   PAYAMAK_API_KEY ← payamak_api_key ← PAYAMAK_PASSWORD ← payamak_password */
$smsCfg   = eplakConfigArray();
$smsState = [
    'username'         => eplakPayamakUsername($smsCfg),
    'source'           => eplakPayamakSecretSource($smsCfg),
    'secret_label'     => eplakPayamakSecretLabel($smsCfg),
    'template'         => eplakPayamakTemplateId($smsCfg),
    'template_raw'     => eplakPayamakTemplateRaw($smsCfg),
    'template_default' => eplakPayamakDefaultTemplate(),
    'ready'            => eplakPayamakReady($smsCfg),
    'partial'          => eplakPayamakPartial($smsCfg),
    'curl'             => function_exists('curl_init'),
    'endpoint'         => EPLAK_PAYAMAK_ENDPOINT,
];

/* وضعیت اعلان اپ اندروید (فایربیس/FCM) */
$fcmConfig  = eplakFcmConfig($pdo);
$fcmDevices = eplakFcmCount($pdo);
$fcmTokensTotal = eplakFcmCount($pdo, false);
$fcmDiag    = $fcmDiag ?? null;
$fcmDeviceRows = [];
try {
    /* ستون app_project (پروژه‌ای که خودِ گوشی گزارش می‌دهد) روی دیتابیس قدیمی ممکن است نباشد */
    $fcmProjectCol = eplakFcmProjectColumnReady($pdo) ? ', app_project' : '';
    $fcmDeviceRows = $pdo->query('SELECT user_phone, platform, is_active, fail_count, last_error, last_seen_at' . $fcmProjectCol . ' FROM device_tokens ORDER BY id DESC LIMIT 10')->fetchAll() ?: [];
} catch (Throwable $e) {
}
$fcmLogRows = eplakPushLogRecent($pdo, [], 12);
/* «ضربان اپ‌ها»: آخرین دریافت فهرست اعلان‌ها توسط هر اپ (APK / IPA / PWA) */
$appHeartbeats = eplakHeartbeatList($pdo, 30);
$pushOutcomeLabels = [
    'sent' => ['ارسال شد', 'ok'], 'partial' => ['بخشی رسید', 'warn'], 'failed' => ['گوگل نپذیرفت', 'bad'],
    'no_device' => ['گوشی ثبت نیست', 'warn'], 'fcm_off' => ['کلید فایربیس نیست', 'warn'],
    'google_error' => ['عدم دسترسی به گوگل', 'bad'], 'sent_web' => ['ارسال شد (مرورگر)', 'ok'],
];
$maskPhone = static function (string $p): string {
    return $p === '' ? 'مهمان (بدون شماره)' : $p;
};

/* وضعیت فنی سرور */
$uploadRoot = EPLAK_ROOT . '/uploads';
$uploadRootWritable = is_dir($uploadRoot) ? is_writable($uploadRoot) : is_writable(EPLAK_ROOT);
$driver = 'MySQL/MariaDB';
try {
    if (eplakIsSqlite($pdo)) {
        $driver = 'SQLite (حالت توسعه/پیش‌نمایش)';
    }
} catch (Throwable $e) {
}
$httpsOn = eplakIsHttpsRequest();
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>تنظیمات پنل</title>
  <link rel="stylesheet" href="assets/style.css?v=10">
  <link rel="stylesheet" href="assets/fontawesome/css/all.min.css">
  <script src="assets/theme.js?v=7"></script>
  <script src="assets/persian-digits.js?v=6"></script>
  <style>
    .settings-grid { display: grid; gap: 20px; }
    .field-hint { font-size: 12px; color: var(--dark-500); margin-top: 6px; line-height: 1.9; }
    .kv-list { display: grid; gap: 10px; margin-top: 12px; }
    .kv-row { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; justify-content: space-between;
              padding: 10px 14px; border: 1px solid var(--dark-200); border-radius: 12px; background: var(--dark-50); }
    .kv-key { font-size: 13px; font-weight: 600; color: var(--dark-600); }
    .kv-val { font-size: 13px; color: var(--dark-700); }
    .pill { display:inline-flex; align-items:center; gap:6px; padding: 3px 10px; border-radius: 999px; font-size: 12px; font-weight: 600; }
    .pill-ok { background: var(--success-bg, #ecfdf5); color: var(--success, #047857); }
    .pill-bad { background: var(--danger-bg, #fef2f2); color: var(--danger, #b91c1c); }
    .pill-warn { background: var(--warning-bg, #fffbeb); color: var(--warning, #b45309); }
    .diag-list { display: grid; gap: 8px; margin-top: 12px; }
    .diag-row { display: grid; gap: 4px; padding: 10px 14px; border: 1px solid var(--dark-200); border-radius: 12px; background: var(--dark-50); font-size: 13px; }
    .diag-row .diag-hint { color: var(--dark-600); line-height: 1.9; }
    .tbl-mini { width: 100%; border-collapse: collapse; font-size: 12.5px; margin-top: 8px; }
    .tbl-mini th { text-align: right; color: var(--dark-500); padding: 6px 4px; font-weight: 600; }
    .tbl-mini td { padding: 6px 4px; border-top: 1px dashed var(--dark-200); vertical-align: top; }
    .key-box { direction: ltr; text-align: left; font-family: monospace; font-size: 12px; word-break: break-all;
               background: var(--dark-50); border: 1px dashed var(--dark-300); border-radius: 10px; padding: 10px 12px; }
    .two-col { display: grid; gap: 20px; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); }
    .steps { padding-right: 18px; line-height: 2.2; font-size: 13px; color: var(--dark-600); }
  </style>
</head>
<body>
  <div class="layout">
    <aside class="sidebar">
      <div class="brand">
        <img class="logo-light" src="assets/img/logo.png" alt="ای‌پلاک">
        <img class="logo-dark" src="assets/img/logo-light.png" alt="ای‌پلاک">
      </div>
      <nav data-testid="admin-sidebar">
<?php /* منوی آگاه از دسترسی — admin/includes/acl.php */ ?>
<?= eplakAdminSidebar('settings') ?>      </nav>
    </aside>
    <main class="main">
      <header class="topbar">
        <div class="topbar-left">
          <h1><i class="fas fa-cog" style="color: var(--primary-500); margin-left: 12px;"></i> تنظیمات پنل</h1>
          <p>حساب مدیر، اعلان پس‌زمینه (نوتیفیکیشن گوشی) و وضعیت فنی سرور</p>
        </div>
      </header>

      <?php if ($message): ?>
        <div class="alert alert-<?= $messageType === 'success' ? 'success' : 'danger' ?>">
          <?= htmlspecialchars($message) ?>
        </div>
      <?php endif; ?>

      <section class="panel">
        <h2><i class="fas fa-user-shield"></i> حساب مدیر</h2>
        <div class="kv-list">
          <div class="kv-row">
            <span class="kv-key">نام کاربری فعلی</span>
            <span class="kv-val"><strong><?= htmlspecialchars((string) ($admin['username'] ?? '')) ?></strong></span>
          </div>
          <div class="kv-row">
            <span class="kv-key">نقش</span>
            <span class="kv-val"><?= htmlspecialchars((string) ($admin['role'] ?? 'admin')) ?></span>
          </div>
          <div class="kv-row">
            <span class="kv-key">تاریخ ایجاد حساب</span>
            <span class="kv-val"><?= htmlspecialchars(eplakFaDateTimeOf($admin['created_at'] ?? null, '—')) ?></span>
          </div>
        </div>

        <div class="two-col" style="margin-top: 20px;">
          <!-- تغییر نام کاربری -->
          <form method="post" class="settings-grid">
            <?= eplakCsrfField() ?>
            <input type="hidden" name="action" value="update_username">
            <div class="form-group">
              <label for="username"><i class="fas fa-at" style="color: var(--primary-500); margin-left: 6px;"></i> نام کاربری جدید</label>
              <input class="form-control" type="text" id="username" name="username"
                     value="<?= htmlspecialchars((string) ($admin['username'] ?? '')) ?>" required autocomplete="username">
              <p class="field-hint">حداقل ۳ کاراکتر؛ حروف فارسی/انگلیسی، عدد و علامت‌های . _ - @ مجاز است.</p>
            </div>
            <div>
              <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> ذخیره نام کاربری</button>
            </div>
          </form>

          <!-- تغییر رمز عبور -->
          <form method="post" class="settings-grid">
            <?= eplakCsrfField() ?>
            <input type="hidden" name="action" value="update_password">
            <div class="form-group">
              <label for="current_password"><i class="fas fa-lock" style="color: var(--primary-500); margin-left: 6px;"></i> رمز عبور فعلی</label>
              <input class="form-control" type="password" id="current_password" name="current_password" required autocomplete="current-password">
            </div>
            <div class="form-group">
              <label for="new_password"><i class="fas fa-key" style="color: var(--primary-500); margin-left: 6px;"></i> رمز عبور جدید</label>
              <input class="form-control" type="password" id="new_password" name="new_password" required autocomplete="new-password" minlength="8">
              <p class="field-hint">حداقل ۸ کاراکتر و ترکیبی از حرف و عدد.</p>
            </div>
            <div class="form-group">
              <label for="confirm_password"><i class="fas fa-key" style="color: var(--primary-500); margin-left: 6px;"></i> تکرار رمز عبور جدید</label>
              <input class="form-control" type="password" id="confirm_password" name="confirm_password" required autocomplete="new-password" minlength="8">
            </div>
            <div>
              <button type="submit" class="btn btn-primary"><i class="fas fa-shield-halved"></i> تغییر رمز عبور</button>
            </div>
          </form>
        </div>
      </section>

      <section class="panel">
        <h2><i class="fas fa-bell"></i> اعلان پس‌زمینه (نوتیفیکیشن گوشی در حالت قفل)</h2>
        <p class="field-hint">
          این بخش، اعلان‌های پنل را به‌صورت «نوتیفیکیشن سیستمی گوشی» ارسال می‌کند؛ حتی وقتی صفحه قفل است
          یا شهروند برنامه را بسته است. برای فعال بودن این قابلیت، سایت باید با <strong>HTTPS</strong> باز شود،
          افزونه‌ی <strong>OpenSSL</strong> روی سرور فعال باشد و شهروند یک‌بار در اپلیکیشن اجازه‌ی اعلان را تأیید کند.
        </p>

        <div class="kv-list">
          <div class="kv-row">
            <span class="kv-key">وضعیت قابلیت روی سرور</span>
            <span class="kv-val">
              <?php if ($pushPossible && $vapidReady): ?>
                <span class="pill pill-ok"><i class="fas fa-circle-check"></i> آماده</span>
              <?php else: ?>
                <span class="pill pill-bad"><i class="fas fa-triangle-exclamation"></i> نیازمند بررسی</span>
              <?php endif; ?>
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">کلیدهای VAPID</span>
            <span class="kv-val">
              <?php if ($vapidReady): ?>
                ساخته شده <span class="pill pill-ok">فعال</span>
              <?php else: ?>
                ساخته نشده <span class="pill pill-bad">غیرفعال</span>
              <?php endif; ?>
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">دستگاه‌های ثبت‌شده (کل / فعال)</span>
            <span class="kv-val"><?= (int) $pushStats['subscribers_all'] ?> / <?= (int) $pushStats['subscribers'] ?></span>
          </div>
          <div class="kv-row">
            <span class="kv-key">آخرین ارسال گروهی (موفق / ناموفق)</span>
            <span class="kv-val">
              <?php if ($pushStats['last_send_title'] === ''): ?>
                —
              <?php else: ?>
                «<?= htmlspecialchars($pushStats['last_send_title']) ?>» —
                <?= (int) $pushStats['last_sent'] ?> موفق، <?= (int) $pushStats['last_failed'] ?> ناموفق
                <span style="color: var(--dark-400); font-size: 12px;">(<?= htmlspecialchars(eplakFaDateTimeOf($pushStats['last_send_at'] ?? null, '—')) ?>)</span>
              <?php endif; ?>
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">باز بودن سایت روی HTTPS</span>
            <span class="kv-val">
              <?php if ($httpsOn): ?>
                <span class="pill pill-ok">بله</span>
              <?php else: ?>
                <span class="pill pill-bad">خیر — اعلان پس‌زمینه فقط روی HTTPS (یا localhost) کار می‌کند</span>
              <?php endif; ?>
            </span>
          </div>
        </div>

        <?php if ($vapidReady): ?>
          <p class="field-hint" style="margin-top: 16px;">کلید عمومی VAPID (اپلیکیشن این را خودکار از سرور می‌خواند؛ نیازی به کار دستی نیست):</p>
          <div class="key-box"><?= htmlspecialchars((string) $vapid['public']) ?></div>
        <?php elseif (!$pushPossible): ?>
          <div class="alert alert-warning" style="margin-top: 16px;">
            افزونه‌های لازم روی سرور فعال نیستند. برای اعلان پس‌زمینه باید <code>openssl</code> و یکی از
            <code>curl</code> یا <code>allow_url_fopen</code> فعال باشند. اعلان‌های داخل برنامه بدون این‌ها هم کار می‌کنند.
          </div>
        <?php endif; ?>

        <?php if ($pushErrors): ?>
          <p class="field-hint" style="margin-top: 16px;">آخرین خطاهای ثبت‌شده (برای عیب‌یابی):</p>
          <div class="table-wrapper">
            <table>
              <thead><tr><th>شماره</th><th>تعداد خطا</th><th>آخرین پیام</th><th>زمان</th></tr></thead>
              <tbody>
                <?php foreach ($pushErrors as $err): ?>
                  <tr>
                    <td><?= htmlspecialchars((string) ($err['user_phone'] !== '' ? $err['user_phone'] : 'مهمان')) ?></td>
                    <td><?= (int) $err['fail_count'] ?></td>
                    <td style="font-size: 12px; direction: ltr; text-align: left;"><?= htmlspecialchars(mb_substr((string) $err['last_error'], 0, 160)) ?></td>
                    <td style="font-size: 12px;"><?= htmlspecialchars(eplakFaDateTimeOf($err['updated_at'] ?? null, '—')) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>

        <div class="two-col" style="margin-top: 20px;">
          <form method="post" class="settings-grid">
            <?= eplakCsrfField() ?>
            <input type="hidden" name="action" value="test_push">
            <div class="form-group">
              <label for="test_phone"><i class="fas fa-mobile-screen" style="color: var(--primary-500); margin-left: 6px;"></i> ارسال اعلان آزمایشی</label>
              <input class="form-control" type="tel" id="test_phone" name="test_phone" placeholder="09xxxxxxxxx" required>
              <p class="field-hint">شماره‌ای که در اپلیکیشن اجازه‌ی اعلان داده است. بهترین روش بررسی: گوشی را قفل کنید و ببینید اعلان می‌رسد.</p>
            </div>
            <div>
              <button type="submit" class="btn btn-success"><i class="fas fa-paper-plane"></i> ارسال آزمایشی</button>
            </div>
          </form>

          <form method="post" class="settings-grid">
            <?= eplakCsrfField() ?>
            <input type="hidden" name="action" value="save_push_subject">
            <div class="form-group">
              <label for="vapid_subject"><i class="fas fa-envelope" style="color: var(--primary-500); margin-left: 6px;"></i> نشانی تماس برای سرویس‌های پوش</label>
              <input class="form-control" type="text" id="vapid_subject" name="vapid_subject"
                     value="<?= htmlspecialchars($vapidSubject) ?>" placeholder="mailto:admin@example.com" style="direction: ltr; text-align: left;">
              <p class="field-hint">استاندارد VAPID این نشانی را الزامی می‌کند (mailto: یا https:).</p>
            </div>
            <div>
              <button type="submit" class="btn btn-secondary"><i class="fas fa-save"></i> ذخیره</button>
            </div>
          </form>
        </div>

        <form method="post" style="margin-top: 18px;" onsubmit="return confirm('با ساخت کلید تازه، همه‌ی اشتراک‌های فعلی باطل می‌شوند و کاربران باید یک‌بار اپلیکیشن را باز کنند. ادامه می‌دهید؟');">
          <?= eplakCsrfField() ?>
          <input type="hidden" name="action" value="regen_vapid">
          <button type="submit" class="btn btn-outline"><i class="fas fa-rotate"></i> ساخت مجدد کلیدهای اعلان</button>
        </form>
      </section>

      <section class="panel" id="fcm-section">
        <h2><i class="fas fa-mobile-screen-button"></i> اعلان گوشی برای اپ اندروید (فایربیس)</h2>
        <p class="field-hint" style="line-height:2; margin-bottom:14px;">
          اپ اندروید سایت را داخل WebView نشان می‌دهد و اندروید در WebView اجازه‌ی «اعلان پس‌زمینه‌ی مرورگر»
          نمی‌دهد. برای رسیدن اعلان وقتی <strong>اپ کاملاً بسته است</strong>، از سرویس فایربیس گوگل استفاده می‌شود.
          <br>
          <span style="display:inline-block; background:#eef2ff; border:1px solid #c7d2fe; border-radius:10px; padding:8px 12px; margin:6px 0;">
            📘 آموزش گام‌به‌گام کامل، همراه با عیب‌یابی:
            <code dir="ltr">docs/FIREBASE_SETUP_FA.md</code> (فارسی) و
            <code dir="ltr">docs/FIREBASE_SETUP_EN.md</code> (انگلیسی) —
            همین دو فایل داخل بسته‌ی آپلود سایت هستند.
          </span>
          <br>
          <strong>راه‌اندازی یک‌باره (۵ دقیقه):</strong>
          <ol style="margin:6px 0 0; padding-inline-start:20px; font-size:13px;">
            <li>در <a href="https://console.firebase.google.com" target="_blank" rel="noopener">console.firebase.google.com</a>
                یک پروژه بسازید (رایگان).</li>
            <li>در همان پروژه، یک اپ اندروید با نام بسته‌ی
                <code dir="ltr"><?= htmlspecialchars((string) ($fcmConfig['package'] ?? 'com.eplak'), ENT_QUOTES, 'UTF-8') ?></code> اضافه کنید و فایل
                <code dir="ltr">google-services.json</code> را دانلود و در پوشه‌ی
                <code dir="ltr">android-app/app/</code> قرار دهید (قبل از ساخت APK).
                APK فعلی با پروژه‌ی <code dir="ltr"><?= htmlspecialchars((string) ($fcmConfig['app_project'] ?? ''), ENT_QUOTES, 'UTF-8') ?></code> ساخته شده است.</li>
            <li>در Firebase: ⚙️ Project settings → <strong>Service accounts</strong> →
                دکمه‌ی <strong>Generate new private key</strong> → فایل JSON دانلود می‌شود.</li>
            <li>همان فایل را پایین انتخاب کنید (یا محتوایش را در کادر بچسبانید) و ذخیره کنید.</li>
          </ol>
        </p>

        <div class="kv-list" style="margin-bottom:16px;">
          <div class="kv-row">
            <span class="kv-key">وضعیت کلید سرویس</span>
            <span class="kv-val">
              <?php if ($fcmConfig['ready'] && $fcmConfig['project_match'] === false): ?>
                <span class="pill pill-bad" data-testid="fcm-project-mismatch">کلید از پروژه‌ی دیگری است</span>
                <span style="font-size:12px; color:var(--dark-500);" dir="ltr"><?= htmlspecialchars($fcmConfig['project_id']) ?></span>
              <?php elseif ($fcmConfig['ready']): ?>
                <span class="pill pill-ok">آماده</span>
                <span style="font-size:12px; color:var(--dark-500);" dir="ltr"><?= htmlspecialchars($fcmConfig['project_id']) ?></span>
              <?php else: ?>
                <span class="pill pill-bad">تنظیم نشده</span>
                <span style="font-size:12px; color:var(--dark-500);"><?= htmlspecialchars($fcmConfig['error']) ?></span>
              <?php endif; ?>
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">پروژه‌ی فایربیس اپ اندروید (APK)</span>
            <span class="kv-val" data-testid="fcm-app-project">
              <span dir="ltr" style="font-size:12px;"><?= htmlspecialchars((string) $fcmConfig['app_project']) ?></span>
              <?php if (trim((string) ($fcmConfig['app_sender'] ?? '')) !== ''): ?>
                <span dir="ltr" style="font-size:11px; color:var(--dark-500);" data-testid="fcm-app-sender">(Project number: <?= htmlspecialchars((string) $fcmConfig['app_sender']) ?>)</span>
              <?php endif; ?>
              <?php if ($fcmConfig['ready']): ?>
                <?= $fcmConfig['project_match'] === false
                    ? '<span class="pill pill-bad">✖ با کلید سرویس یکی نیست</span>'
                    : '<span class="pill pill-ok">✔ با کلید سرویس یکی است</span>' ?>
              <?php endif; ?>
            </span>
          </div>
          <?php if ($fcmConfig['ready'] && $fcmConfig['project_match'] === false): ?>
            <div class="kv-row" style="display:block;">
              <div class="diag-hint" data-testid="fcm-project-mismatch-text" style="background:#fef2f2; border:1px solid #fecaca; color:#991b1b; border-radius:10px; padding:10px 12px; line-height:2;">
                ⛔ <?= htmlspecialchars((string) $fcmConfig['warning']) ?>
              </div>
            </div>
          <?php endif; ?>
          <div class="kv-row">
            <span class="kv-key">دستگاه‌های ثبت‌شده‌ی اپ</span>
            <span class="kv-val">
              <strong><?= (int) $fcmDevices ?></strong> دستگاه فعال
              <?php if ($fcmTokensTotal > $fcmDevices): ?>
                <span style="font-size:12px; color:var(--dark-500);">(از <?= (int) $fcmTokensTotal ?> دستگاه ثبت‌شده)</span>
              <?php endif; ?>
            </span>
          </div>
        </div>

        <form method="post" enctype="multipart/form-data" style="display:grid; gap:14px;">
          <?= eplakCsrfField() ?>
          <input type="hidden" name="action" value="save_fcm">
          <div class="form-group">
            <label for="fcm_service_account_file"><i class="fas fa-file-arrow-up" style="color: var(--primary-500); margin-left: 6px;"></i> فایل کلید سرویس فایربیس (ساده‌ترین راه: خودِ فایل JSON را انتخاب کنید)</label>
            <input class="form-control" type="file" id="fcm_service_account_file" name="fcm_service_account_file" accept=".json,application/json" data-testid="fcm-key-file">
            <p class="field-hint">فایلی با نامی شبیه <code dir="ltr">&lt;پروژه&gt;-firebase-adminsdk-xxxxx.json</code> که از Firebase Console → Project settings → Service accounts → Generate new private key دانلود شده. اگر فایل انتخاب شود، کادر متنی زیر نادیده گرفته می‌شود.</p>
          </div>
          <div class="form-group">
            <label for="fcm_service_account"><i class="fas fa-key" style="color: var(--primary-500); margin-left: 6px;"></i> یا محتوای فایل JSON را این‌جا بچسبانید</label>
            <textarea class="form-control" id="fcm_service_account" name="fcm_service_account" rows="6"
                      dir="ltr" style="text-align:left; font-family:monospace; font-size:12px;"
                      placeholder='{"type":"service_account","project_id":"...","private_key":"-----BEGIN PRIVATE KEY-----
...","client_email":"..."}'><?= htmlspecialchars((string) eplakAppSetting($pdo, 'fcm_service_account', '')) ?></textarea>
            <p class="field-hint">این کلید محرمانه است؛ فقط روی سرور شما ذخیره می‌شود و در گیت‌هاب قرار نمی‌گیرد. برای پاک کردن، کادر را خالی کنید (و فایلی انتخاب نکنید) و ذخیره بزنید.
              کلید باید از پروژه‌ی <code dir="ltr"><?= htmlspecialchars((string) $fcmConfig['app_project']) ?></code> (پروژه‌ی خودِ APK) باشد.</p>
          </div>
          <div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> ذخیره و بررسی اتصال</button>
          </div>
        </form>

        <form method="post" class="settings-grid" style="margin-top:18px;">
          <?= eplakCsrfField() ?>
          <input type="hidden" name="action" value="test_fcm">
          <div class="form-group">
            <label for="fcm_test_phone"><i class="fas fa-paper-plane" style="color: var(--primary-500); margin-left: 6px;"></i> ارسال آزمایشی به اپ اندروید</label>
            <input class="form-control" type="tel" id="fcm_test_phone" name="fcm_test_phone" placeholder="09xxxxxxxxx" required>
            <p class="field-hint">شماره‌ای که کاربر با آن در اپ وارد شده است. گوشی را ببندید و ببینید اعلان می‌رسد.</p>
          </div>
          <div>
            <button type="submit" class="btn btn-success"><i class="fas fa-mobile-screen"></i> ارسال آزمایشی فایربیس</button>
          </div>
        </form>

        <h3 style="margin-top: 26px; font-size: 15px;"><i class="fas fa-stethoscope" style="color: var(--primary-500); margin-left:6px;"></i> بررسی زنجیره‌ی اعلان</h3>
        <p class="field-hint">
          اگر اعلانِ «در حال رسیدگی / انجام شد» به گوشی کاربر نمی‌رسد، این دکمه گام‌به‌گام نشان می‌دهد مشکل
          کجاست: کلید فایربیس، دسترسی سرور سایت به گوگل، یا ثبت نبودن گوشی‌ها. (هیچ پیامی به کاربر ارسال نمی‌شود.)
        </p>
        <form method="post" style="margin-top:10px;">
          <?= eplakCsrfField() ?>
          <input type="hidden" name="action" value="diagnose_fcm">
          <button type="submit" class="btn btn-outline"><i class="fas fa-vial"></i> بررسی اتصال به گوگل و فایربیس</button>
        </form>
        <?php if (is_array($fcmDiag)): ?>
          <div class="diag-list" data-testid="fcm-diagnose">
            <?php foreach ($fcmDiag as $step): ?>
              <div class="diag-row">
                <div>
                  <span class="pill <?= $step['ok'] ? 'pill-ok' : 'pill-bad' ?>"><?= $step['ok'] ? '✔ سالم' : '✖ مشکل' ?></span>
                  <strong><?= htmlspecialchars($step['name']) ?></strong>
                </div>
                <?php if ($step['detail'] !== ''): ?><div dir="auto" style="color:var(--dark-500); word-break:break-word;"><?= htmlspecialchars($step['detail']) ?></div><?php endif; ?>
                <?php if ($step['hint'] !== ''): ?><div class="diag-hint">💡 <?= htmlspecialchars($step['hint']) ?></div><?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <h3 style="margin-top: 26px; font-size: 15px;"><i class="fas fa-mobile-screen" style="color: var(--primary-500); margin-left:6px;"></i> گوشی‌های ثبت‌شده (۱۰ مورد آخر)</h3>
        <?php if ($fcmDeviceRows): ?>
          <table class="tbl-mini" data-testid="fcm-devices">
            <thead><tr><th>کاربر</th><th>وضعیت</th><th>آخرین ثبت</th><th>پروژه‌ی اپ</th><th>آخرین خطا</th></tr></thead>
            <tbody>
              <?php foreach ($fcmDeviceRows as $d): ?>
                <?php $devProject = (string) ($d['app_project'] ?? ''); ?>
                <tr>
                  <td dir="ltr" style="text-align:right;"><?= htmlspecialchars($maskPhone((string) $d['user_phone'])) ?></td>
                  <td><?= (int) $d['is_active'] === 1 ? '<span class="pill pill-ok">فعال</span>' : '<span class="pill pill-bad">غیرفعال</span>' ?></td>
                  <td dir="rtl" style="text-align:right;"><?= htmlspecialchars(eplakFaDateTimeOf($d['last_seen_at'] ?? null, '—')) ?></td>
                  <td dir="ltr" style="text-align:right; font-size:12px;">
                    <?php if ($devProject === ''): ?>—<?php else: ?>
                      <?= htmlspecialchars($devProject) ?>
                      <?php if ($fcmConfig['ready'] && $devProject !== (string) $fcmConfig['project_id']): ?><span class="pill pill-bad">≠ کلید</span><?php endif; ?>
                    <?php endif; ?>
                  </td>
                  <td style="color:var(--dark-500); word-break:break-word;"><?= htmlspecialchars((string) ($d['last_error'] ?? '')) ?: '—' ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php else: ?>
          <p class="field-hint" data-testid="fcm-devices-empty">
            ⚠️ هنوز هیچ گوشی‌ای ثبت نشده است. گوشی‌ها وقتی ثبت می‌شوند که کاربر اپ (آخرین نسخه) را باز کند و با شماره‌اش وارد شود.
          </p>
        <?php endif; ?>

        <h3 style="margin-top: 26px; font-size: 15px;"><i class="fas fa-clock-rotate-left" style="color: var(--primary-500); margin-left:6px;"></i> آخرین ارسال‌های اعلان به گوشی</h3>
        <?php if ($fcmLogRows): ?>
          <table class="tbl-mini" data-testid="fcm-log">
            <thead><tr><th>زمان</th><th>کاربر</th><th>موضوع</th><th>نتیجه</th><th>توضیح</th></tr></thead>
            <tbody>
              <?php foreach ($fcmLogRows as $r): ?>
                <?php $lab = $pushOutcomeLabels[(string) $r['outcome']] ?? [(string) $r['outcome'], 'warn']; ?>
                <tr>
                  <td dir="rtl" style="text-align:right;"><?= htmlspecialchars(eplakFaDateTimeOf($r['created_at'] ?? null, '—')) ?></td>
                  <td dir="ltr" style="text-align:right;"><?= htmlspecialchars($maskPhone((string) $r['user_phone'])) ?></td>
                  <td><?= htmlspecialchars(($r['code'] ?? '') !== '' ? (string) $r['code'] : (string) $r['kind']) ?></td>
                  <td><span class="pill pill-<?= htmlspecialchars($lab[1]) ?>"><?= htmlspecialchars($lab[0]) ?></span>
                      <?php if ((int) $r['devices'] > 0): ?><span style="color:var(--dark-500);"><?= (int) $r['sent'] ?>/<?= (int) $r['devices'] ?></span><?php endif; ?></td>
                  <td style="color:var(--dark-500); word-break:break-word;"><?= htmlspecialchars(mb_substr((string) ($r['error'] ?? ''), 0, 140, 'UTF-8')) ?: '—' ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php else: ?>
          <p class="field-hint">هنوز اعلانی برای هیچ کاربری ارسال نشده است.</p>
        <?php endif; ?>

        <h3 style="margin-top: 26px; font-size: 15px;"><i class="fas fa-heart-pulse" style="color: var(--primary-500); margin-left:6px;"></i> ضربان اپ‌ها: آخرین دریافت فهرست اعلان‌ها</h3>
        <p class="field-hint" style="line-height:2;">
          هر اپ (APK / IPA / PWA) وقتی باز است، هر چند ثانیه فهرست اعلان‌ها را از سرور می‌گیرد. این جدول نشان می‌دهد
          هر اپ با <strong>کدام شماره</strong> و <strong>چند ثانیه پیش</strong> آخرین بار پرسیده و سرور برایش
          <strong>چند اعلان</strong> برگردانده است. اگر اپی این‌جا نیست یعنی اصلاً به سرور نمی‌رسد؛ اگر هست ولی
          «۰ اعلان» می‌گیرد، مشکل از شماره/دیتابیس است نه از گوشی.
        </p>
        <?php if ($appHeartbeats): ?>
          <table class="tbl-mini" data-testid="app-heartbeats">
            <thead><tr><th>اپ</th><th>کاربر</th><th>آخرین درخواست</th><th>اعلان‌ها</th><th>نسخه</th><th>پاسخ قبلی از نگاه اپ</th></tr></thead>
            <tbody>
              <?php foreach ($appHeartbeats as $hb): ?>
                <tr>
                  <td><?= htmlspecialchars(eplakHeartbeatPlatformLabel($hb['platform'])) ?></td>
                  <td dir="ltr" style="text-align:right;"><?= htmlspecialchars($hb['phone'] !== '' ? $maskPhone($hb['phone']) : 'مهمان (' . mb_substr($hb['device'], 0, 10, 'UTF-8') . '…)') ?></td>
                  <td dir="rtl" style="text-align:right;">
                    <?= htmlspecialchars($hb['age_text']) ?>
                    <?php if ($hb['age'] >= 0 && $hb['age'] <= 60): ?><span class="pill pill-ok">زنده</span><?php endif; ?>
                  </td>
                  <td>
                    <strong><?= (int) $hb['count'] ?></strong> اعلان
                    <span style="color:var(--dark-500); font-size:12px;">(<?= (int) $hb['unread'] ?> نخوانده<?= (int) $hb['hidden'] > 0 ? '، ' . (int) $hb['hidden'] . ' حذف‌شده' : '' ?>)</span>
                    <?php if ($hb['degraded']): ?><span class="pill pill-warn">دیتابیس قدیمی</span><?php endif; ?>
                  </td>
                  <td dir="ltr" style="text-align:right; font-size:12px;"><?= htmlspecialchars($hb['v'] !== '' ? $hb['v'] : '—') ?></td>
                  <td style="color:var(--dark-500); word-break:break-word; font-size:12px;"><?= htmlspecialchars(eplakHeartbeatPrevText($hb['prev'])) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php else: ?>
          <p class="field-hint" data-testid="app-heartbeats-empty">هنوز هیچ اپی (با نسخه‌ی جدید) فهرست اعلان‌ها را نگرفته است.</p>
        <?php endif; ?>
      </section>

      <section class="panel" id="sms">
        <h2><i class="fas fa-comment-sms"></i> پیامکِ «کد تایید» (ملی پیامک)</h2>
        <p class="field-hint">
          ورودِ کاربران با «کد تاییدِ پیامکی» انجام می‌شود و تنها سرویسِ پیامکیِ پروژه
          <strong>ملی پیامک</strong> (<code dir="ltr">rest.payamak-panel.com</code>) است.
          این‌جا وضعیتِ واقعیِ همان تنظیمات دیده می‌شود و می‌توانید یک <strong>پیامکِ آزمایشی</strong>
          بفرستید تا مطمئن شوید «کلید API» و «شناسه‌ی متن» درست‌اند.
          <br>مهم‌ترین نکته: ملی پیامک در وب‌سرویس به‌جای «رمز عبورِ پنل»، <strong>«کلید API»</strong> می‌خواهد؛
          اگر رمزِ پنل فرستاده شود پاسخِ <code dir="ltr">RetStatus=-110</code> می‌آید و کد تایید ارسال نمی‌شود.
        </p>

        <div class="kv-list" data-testid="sms-state">
          <div class="kv-row">
            <span class="kv-key">آماده‌ی ارسال؟</span>
            <span class="kv-val">
              <?= $smsState['ready'] ? '<span class="pill pill-ok" data-testid="sms-state-ready">بله</span>' : '<span class="pill pill-bad" data-testid="sms-state-notready">خیر — کد تایید ارسال نمی‌شود</span>' ?>
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">نام کاربریِ پنل</span>
            <span class="kv-val" dir="ltr" style="text-align:right">
              <?= $smsState['username'] !== '' ? '<code>' . htmlspecialchars($smsState['username']) . '</code>' : '<span class="pill pill-bad">تنظیم نشده</span>' ?>
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">کلیدِ دسترسی</span>
            <span class="kv-val" data-testid="sms-state-secret">
              <?php if ($smsState['source'] === 'api_key'): ?>
                <span class="pill pill-ok">کلید API (payamak_api_key)</span>
              <?php elseif ($smsState['source'] === 'password'): ?>
                <span class="pill pill-warn">از payamak_password خوانده می‌شود (قدیمی)</span>
                <div class="field-hint">کار می‌کند، ولی جایِ درستش <code dir="ltr">payamak_api_key</code> است؛
                  اگر ملی پیامک خطای <code dir="ltr">-110</code> داد یعنی مقدارِ فعلی «رمز عبورِ پنل» است نه «کلید API».</div>
              <?php else: ?>
                <span class="pill pill-bad">تنظیم نشده</span>
                <div class="field-hint">کلید API از «پنل ملی پیامک ← توسعه‌دهندگان ← تنظیمات وب‌سرویس ← API Key» کپی
                  و در <code dir="ltr">shared/config.php</code> (یا از <code dir="ltr">setup.php</code>) وارد می‌شود.</div>
              <?php endif; ?>
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">شناسه‌ی متنِ تأییدشده (bodyId)</span>
            <span class="kv-val" dir="ltr" style="text-align:right">
              <code data-testid="sms-state-body"><?= htmlspecialchars($smsState['template']) ?></code>
              <?= $smsState['template_raw'] === '' ? '<span class="pill pill-warn">پیش‌فرضِ پروژه</span>' : '' ?>
            </span>
          </div>
          <div class="kv-row">
            <span class="kv-key">ماژول cURL سرور</span>
            <span class="kv-val"><?= $smsState['curl'] ? '<span class="pill pill-ok">فعال</span>' : '<span class="pill pill-bad">غیرفعال — بدون آن پیامک ارسال نمی‌شود</span>' ?></span>
          </div>
          <div class="kv-row">
            <span class="kv-key">نشانیِ سرویس</span>
            <span class="kv-val" dir="ltr" style="text-align:right"><code><?= htmlspecialchars($smsState['endpoint']) ?></code></span>
          </div>
        </div>

        <?php if ($smsTestResult !== null): ?>
          <div class="alert alert-<?= $smsTestResult['ok'] ? 'success' : 'danger' ?>" data-testid="sms-test-result" style="margin-top:18px;">
            <strong><?= $smsTestResult['ok'] ? '✅ ارسال شد' : '⚠️ ارسال نشد' ?></strong>
            — شماره: <span dir="ltr"><?= htmlspecialchars((string) $smsTestResult['phone']) ?></span>
            · کدِ فرستاده‌شده: <strong dir="ltr"><?= htmlspecialchars((string) $smsTestResult['sent_code']) ?></strong>
            <div class="kv-list" style="margin-top:10px;">
              <div class="kv-row"><span class="kv-key">RetStatus</span>
                <span class="kv-val" dir="ltr" style="text-align:right"><code data-testid="sms-test-ret"><?= htmlspecialchars($smsTestResult['status'] !== '' ? $smsTestResult['status'] : '—') ?></code></span></div>
              <?php if ($smsTestResult['str'] !== ''): ?>
                <div class="kv-row"><span class="kv-key">StrRetStatus</span>
                  <span class="kv-val" dir="ltr" style="text-align:right"><code><?= htmlspecialchars($smsTestResult['str']) ?></code></span></div>
              <?php endif; ?>
              <?php if ($smsTestResult['ok'] && $smsTestResult['rec_id'] !== ''): ?>
                <div class="kv-row"><span class="kv-key">شناسه‌ی رکورد ارسال</span>
                  <span class="kv-val" dir="ltr" style="text-align:right"><code data-testid="sms-test-recid"><?= htmlspecialchars($smsTestResult['rec_id']) ?></code></span></div>
              <?php endif; ?>
              <div class="kv-row"><span class="kv-key">ترجمه‌ی فارسی</span>
                <span class="kv-val" data-testid="sms-test-fa"><?= htmlspecialchars($smsTestResult['text'] !== '' ? $smsTestResult['text'] : ($smsTestResult['fa'] ?? '—')) ?></span></div>
              <?php if (!empty($smsTestResult['hint'])): ?>
                <div class="kv-row"><span class="kv-key">چه‌کار باید کرد</span>
                  <span class="kv-val" data-testid="sms-test-hint"><?= htmlspecialchars($smsTestResult['hint']) ?></span></div>
              <?php endif; ?>
              <div class="kv-row"><span class="kv-key">HTTP</span>
                <span class="kv-val" dir="ltr" style="text-align:right"><code><?= (int) $smsTestResult['http'] ?></code></span></div>
            </div>
            <p class="field-hint" style="margin-top:10px;">یک خطِ گزارش هم در <code dir="ltr">error_log</code> هاست نوشته شد
              (با برچسب <code dir="ltr">[eplak-sms]</code> و بدونِ کلید/رمز) تا اگر باز هم «کد تایید نیامد»،
              دلیلش از همان‌جا خوانده شود.</p>
          </div>
        <?php endif; ?>

        <form method="post" class="settings-grid" style="margin-top:18px;" data-testid="sms-test-form">
          <?= eplakCsrfField() ?>
          <input type="hidden" name="action" value="test_sms">
          <div class="form-group">
            <label for="sms_test_phone">شماره‌ی موبایل برای پیامکِ آزمایشی</label>
            <input type="text" id="sms_test_phone" name="sms_test_phone" inputmode="numeric"
                   maxlength="11" placeholder="09xxxxxxxxx" data-testid="sms-test-phone">
            <span class="field-hint">یک پیامکِ <strong>واقعی</strong> با الگوی «کد تایید» ارسال می‌شود و از اعتبارِ
              پنل کم می‌کند؛ بین دو آزمایش ۳۰ ثانیه فاصله لازم است. نتیجه (کدِ وضعیت و ترجمه‌ی فارسی‌اش)
              همین‌جا نمایش داده می‌شود.</span>
          </div>
          <div>
            <button type="submit" class="btn btn-primary" data-testid="sms-test-send"
              <?= $smsState['ready'] && $smsState['curl'] ? '' : 'disabled' ?>>
              <i class="fas fa-paper-plane"></i> ارسال پیامک آزمایشی
            </button>
            <?php if (!$smsState['ready']): ?>
              <div class="field-hint" data-testid="sms-test-disabled">تا «نام کاربری» و «کلید API» در
                <code dir="ltr">shared/config.php</code> تنظیم نشود، دکمه غیرفعال است.</div>
            <?php endif; ?>
          </div>
        </form>
      </section>


      <section class="panel" id="app-version">
        <h2><i class="fas fa-mobile-screen-button"></i> نسخه‌ی اپ و آپدیت اجباری</h2>
        <p class="field-hint">
          اپ هنگام باز شدن، «حداقل نسخه‌ی مجاز» را از سرور می‌خواند. اگر نسخه‌ی گوشیِ شهروند
          <strong>پایین‌تر</strong> از این عدد باشد، وارد اپ نمی‌شود و پرده‌ی
          «نسخه‌ی اپ قدیمی است — لطفاً به‌روزرسانی کنید» با دکمه‌ی دانلود دیده می‌شود.
          <br>پیش‌فرضِ این‌جا <strong>آخرین نسخه‌ی منتشرشده</strong> است؛ یعنی با هر انتشارِ تازه و آپدیتِ
          هاست، نسخه‌های قدیمی‌تر <strong>خودکار</strong> مسدود می‌شوند و نیازی به تنظیمِ دستی نیست.
          این‌جا فقط وقتی چیزی را عوض کنید که بخواهید اجبار را <strong>عقب بیندازید</strong> (مثلاً حداقل را
          کمتر بگذارید) یا پیام/لینکِ دانلود را سفارشی کنید.
          «آخرین نسخه» فقط برای پیشنهادِ آپدیتِ اختیاری است و کسی را بیرون نمی‌اندازد.
          <br>کدِ نسخه همان <code dir="ltr">versionCode</code> اندروید و <code dir="ltr">CURRENT_PROJECT_VERSION</code> آیفون است
          (در فایل‌های <code dir="ltr">android-app/app/build.gradle</code> و <code dir="ltr">ios-app/Eplak.xcodeproj/project.pbxproj</code>).
        </p>

        <div class="kv-list" data-testid="app-version-state">
          <div class="kv-row">
            <span class="kv-key">حداقل نسخه‌ی مجاز (کد)</span>
            <span class="kv-val"><?= (int) $appVerMin ?></span>
          </div>
          <div class="kv-row">
            <span class="kv-key">آخرین نسخه‌ی منتشرشده</span>
            <span class="kv-val"><?= $appVerLatestCode > 0 ? (int) $appVerLatestCode . ($appVerLatestName !== '' ? ' (' . htmlspecialchars($appVerLatestName) . ')' : '') : '—' ?></span>
          </div>
          <div class="kv-row">
            <span class="kv-key">لینک دانلود نسخه‌ی تازه</span>
            <span class="kv-val"><?= $appVerUrl !== '' ? '<span dir="ltr">' . htmlspecialchars($appVerUrl) . '</span>' : 'پیش‌فرض (APK رسمی گیت‌هاب)' ?></span>
          </div>
        </div>

        <form method="post" class="settings-grid" style="margin-top: 16px;">
          <?= eplakCsrfField() ?>
          <input type="hidden" name="action" value="save_app_version">
          <div class="form-group">
            <label for="min_app_version_code"><i class="fas fa-ban" style="color: var(--primary-500); margin-left: 6px;"></i> حداقل نسخه‌ی مجاز (کد)</label>
            <input class="form-control" type="number" id="min_app_version_code" name="min_app_version_code"
                   value="<?= (int) $appVerMin ?>" min="0" step="1" inputmode="numeric">
            <p class="field-hint">نسخه‌های پایین‌تر از این کد وارد اپ نمی‌شوند. پیش‌فرض = کدِ آخرین نسخه (خودکار). ۰ یعنی «هیچ‌کس مسدود نیست» (فقط برای عقب انداختنِ اجبار).</p>
          </div>
          <div class="form-group">
            <label for="latest_app_version_code"><i class="fas fa-arrow-up-from-bracket" style="color: var(--primary-500); margin-left: 6px;"></i> کدِ آخرین نسخه‌ی منتشرشده</label>
            <input class="form-control" type="number" id="latest_app_version_code" name="latest_app_version_code"
                   value="<?= (int) $appVerLatestCode ?>" min="0" step="1" inputmode="numeric">
            <p class="field-hint">اگر کدِ گوشیِ شهروند از این عدد کمتر باشد (ولی از حداقل بالاتر)، فقط پیشنهادِ آپدیت می‌بیند.</p>
          </div>
          <div class="form-group">
            <label for="latest_app_version_name"><i class="fas fa-tag" style="color: var(--primary-500); margin-left: 6px;"></i> نامِ آخرین نسخه (مثلاً 2.10)</label>
            <input class="form-control" type="text" id="latest_app_version_name" name="latest_app_version_name"
                   value="<?= htmlspecialchars($appVerLatestName) ?>" dir="ltr" style="text-align:left;">
          </div>
          <div class="form-group">
            <label for="app_update_url"><i class="fas fa-download" style="color: var(--primary-500); margin-left: 6px;"></i> لینک دانلود نسخه‌ی تازه (APK)</label>
            <input class="form-control" type="url" id="app_update_url" name="app_update_url"
                   value="<?= htmlspecialchars($appVerUrl) ?>" dir="ltr" style="text-align:left;" placeholder="https://…">
            <p class="field-hint">خالی یعنی لینکِ پیش‌فرضِ APK رسمی گیت‌هاب. فقط لینک‌های http(s) پذیرفته می‌شوند.</p>
          </div>
          <div class="form-group">
            <label for="app_update_message"><i class="fas fa-message" style="color: var(--primary-500); margin-left: 6px;"></i> پیامِ سفارشیِ پرده‌ی آپدیت (اختیاری)</label>
            <textarea class="form-control" id="app_update_message" name="app_update_message" rows="2"><?= htmlspecialchars($appVerMessage) ?></textarea>
            <p class="field-hint">خالی یعنی پیامِ پیش‌فرضِ اپ («نسخه‌ی اپ شما قدیمی است…»).</p>
          </div>
          <div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> ذخیره تنظیمات نسخه</button>
          </div>
        </form>
      </section>

      <section class="panel">
        <h2><i class="fas fa-circle-info"></i> وضعیت فنی سرور</h2>
        <div class="kv-list">
          <div class="kv-row"><span class="kv-key">درایور دیتابیس</span><span class="kv-val"><?= htmlspecialchars($driver) ?></span></div>
          <div class="kv-row"><span class="kv-key">نسخه PHP</span><span class="kv-val" style="direction:ltr"><?= htmlspecialchars(PHP_VERSION) ?></span></div>
          <div class="kv-row">
            <span class="kv-key">افزونه OpenSSL</span>
            <span class="kv-val"><?= function_exists('openssl_pkey_new') ? '<span class="pill pill-ok">فعال</span>' : '<span class="pill pill-bad">غیرفعال</span>' ?></span>
          </div>
          <div class="kv-row">
            <span class="kv-key">curl</span>
            <span class="kv-val"><?= function_exists('curl_init') ? '<span class="pill pill-ok">فعال</span>' : '<span class="pill pill-bad">غیرفعال</span>' ?></span>
          </div>
          <div class="kv-row"><span class="kv-key">سقف حجم هر فایل آپلود</span><span class="kv-val" style="direction:ltr"><?= htmlspecialchars((string) ini_get('upload_max_filesize')) ?></span></div>
          <div class="kv-row"><span class="kv-key">سقف کل ارسال فرم</span><span class="kv-val" style="direction:ltr"><?= htmlspecialchars((string) ini_get('post_max_size')) ?></span></div>
          <div class="kv-row">
            <span class="kv-key">پوشه‌ی فایل‌های پیوست (uploads)</span>
            <span class="kv-val"><?= $uploadRootWritable ? '<span class="pill pill-ok">قابل نوشتن</span>' : '<span class="pill pill-bad">غیرقابل نوشتن — دسترسی ۷۵۵ بدهید</span>' ?></span>
          </div>
          <div class="kv-row"><span class="kv-key">تعداد مطالب اخبار/دانستنی‌ها</span><span class="kv-val"><?= (int) getDashboardStats($pdo)['news_count'] ?> مورد</span></div>
          <div class="kv-row"><span class="kv-key">گزارش‌های دارای عکس/فیلم</span><span class="kv-val"><?= (int) getDashboardStats($pdo)['reports_with_media'] ?> مورد</span></div>
        </div>

        <h3 id="schema" style="margin-top: 22px; font-size: 15px;">ساختار دیتابیس (جدول‌ها و ستون‌ها)</h3>
        <p class="field-hint">
          اگر نسخه‌ی جدید به ستون تازه‌ای نیاز داشته باشد، هنگام باز شدن پنل خودکار به دیتابیس اضافه می‌شود.
          در صورت دیدن خطای «Unknown column» یا «اعلان در اپ نمی‌آید»، دکمه‌ی ترمیم را بزنید:
          ستون <code>notifications.send_id</code> را اضافه می‌کند، کلید خارجیِ مزاحم را برمی‌دارد و
          نویسه‌گان جدول اعلان‌ها را به <code>utf8mb4</code> (برای ایموجی) تبدیل می‌کند.
          همین دکمه جدول <code>news</code> را هم تعمیر می‌کند (ساخت جدول اگر در دامپ قدیمی نبود،
          افزودن ستون <code>badge</code>/<code>image_url</code> و تبدیل به <code>utf8mb4</code>)؛
          اگر جدول اخبار خالی باشد، مطالب پیش‌فرض یک‌بار درج می‌شوند.
          اگر کاربر دیتابیس اجازه‌ی <code>ALTER</code> ندارد، <code>backend/fix-notifications-db.sql</code>
          را یک‌بار در phpMyAdmin اجرا کنید (جزئیات: <code>docs/NOTIFICATIONS_FA.md</code>).
        </p>
        <div class="kv-list">
          <div class="kv-row">
            <span class="kv-key">نسخه‌ی ساختار دیتابیس</span>
            <span class="kv-val" style="direction:ltr"><?= htmlspecialchars($schemaVersion !== '' ? $schemaVersion : '—') ?></span>
          </div>
          <?php if ($notifSchema): ?>
            <div class="kv-row">
              <span class="kv-key">جدول اعلان‌ها</span>
              <span class="kv-val">
                <?php if (!empty($notifSchema['send_id'])): ?>
                  <span class="pill pill-ok">send_id دارد</span>
                <?php else: ?>
                  <span class="pill pill-bad">send_id ندارد (اعلان در حالت سازگار)</span>
                <?php endif; ?>
                <?php if (!empty($notifSchema['fk'])): ?>
                  <span class="pill pill-bad">کلید خارجی مزاحم هست</span>
                <?php else: ?>
                  <span class="pill pill-ok">کلید خارجی مزاحم ندارد</span>
                <?php endif; ?>
                <?php if (empty($notifSchema['emoji'])): ?>
                  <span class="pill pill-bad">نویسه‌گان سه‌بایتی (ایموجی حذف می‌شود)</span>
                <?php else: ?>
                  <span class="pill pill-ok">utf8mb4 (ایموجی ذخیره می‌شود)</span>
                <?php endif; ?>
              </span>
            </div>
            <?php if (!empty($notifSchema['failed'])): ?>
              <div class="kv-row">
                <span class="kv-key">ترمیمِ ناموفق</span>
                <span class="kv-val"><?= htmlspecialchars(implode(' | ', (array) $notifSchema['failed'])) ?></span>
              </div>
              <div class="kv-row">
                <span class="kv-key">راه جایگزین</span>
                <span class="kv-val" style="direction:ltr; text-align:left;"><code>backend/fix-notifications-db.sql</code></span>
              </div>
            <?php endif; ?>
          <?php endif; ?>
          <?php if ($newsSchema): ?>
            <div class="kv-row">
              <span class="kv-key">جدول اخبار و دانستنی‌ها</span>
              <span class="kv-val">
                <?php if (!empty($newsSchema['table'])): ?>
                  <span class="pill pill-ok">جدول news هست</span>
                <?php else: ?>
                  <span class="pill pill-bad">جدول news نیست (فهرست اخبار خالی)</span>
                <?php endif; ?>
                <?php if (!empty($newsSchema['columns']['badge']) && !empty($newsSchema['columns']['image_url'])): ?>
                  <span class="pill pill-ok">badge و image_url دارد</span>
                <?php else: ?>
                  <span class="pill pill-bad">ستون badge یا image_url ندارد (مطالب «سازگار» ذخیره می‌شوند)</span>
                <?php endif; ?>
                <?php if (empty($newsSchema['emoji'])): ?>
                  <span class="pill pill-bad">نویسه‌گان سه‌بایتی (ایموجی حذف می‌شود)</span>
                <?php else: ?>
                  <span class="pill pill-ok">utf8mb4 (ایموجی ذخیره می‌شود)</span>
                <?php endif; ?>
              </span>
            </div>
            <?php if (!empty($newsSchema['failed'])): ?>
              <div class="kv-row">
                <span class="kv-key">ترمیمِ ناموفق (اخبار)</span>
                <span class="kv-val"><?= htmlspecialchars(implode(' | ', (array) $newsSchema['failed'])) ?></span>
              </div>
            <?php endif; ?>
          <?php endif; ?>
          <?php if ($schemaReport['ran']): ?>
            <div class="kv-row">
              <span class="kv-key">آخرین همگام‌سازی</span>
              <span class="kv-val">
                <?php if ($schemaReport['failed']): ?>
                  <span class="pill pill-bad"><?= count($schemaReport['failed']) ?> مورد ناموفق</span>
                <?php else: ?>
                  <span class="pill pill-ok"><?= count($schemaReport['added']) ?> ستون اضافه شد</span>
                <?php endif; ?>
              </span>
            </div>
            <?php if ($schemaReport['added']): ?>
              <div class="kv-row">
                <span class="kv-key">ستون‌های تازه</span>
                <span class="kv-val" style="direction:ltr; text-align:left; word-break:break-all;"><?= htmlspecialchars(implode('، ', $schemaReport['added'])) ?></span>
              </div>
            <?php endif; ?>
          <?php endif; ?>
        </div>
        <form method="post" style="margin-top: 12px;">
          <?= eplakCsrfField() ?>
          <input type="hidden" name="action" value="repair_schema">
          <button type="submit" class="btn btn-outline"><i class="fas fa-screwdriver-wrench"></i> بررسی و ترمیم ساختار دیتابیس</button>
        </form>

        <h3 style="margin-top: 22px; font-size: 15px;">چطور مطمئن شوم اعلان در حالت قفل می‌رسد؟</h3>
        <ol class="steps">
          <li>گوشی شهروند یک‌بار اپلیکیشن را باز کند و پیام «اجازه‌ی اعلان» را تأیید کند (در iOS باید اپ به صفحه‌ی اصلی اضافه شده باشد).</li>
          <li>در پنل → «ارسال اعلان» یک پیام بفرستید، یا در همین صفحه «ارسال آزمایشی» را برای همان شماره بزنید.</li>
          <li>صفحه‌ی گوشی را قفل کنید؛ اعلان باید روی صفحه‌ی قفل ظاهر شود.</li>
          <li>اگر نرسید: وضعیت HTTPS و خطاهای بالا را بررسی کنید. TTL اعلان‌ها ۲۸ روز است؛ اگر گوشی آفلاین باشد، به‌محض آنلاین شدن تحویل داده می‌شود.</li>
        </ol>
      </section>
    </main>
  </div>
</body>
</html>
